package com.spz.demo.security.common;

/**
 * 请求或响应参数常量
 */
public class WebConst {
    public static final String TOKEN = "token";
    public static final String REFLUSH_TOKEN = "reflushToken";
}
