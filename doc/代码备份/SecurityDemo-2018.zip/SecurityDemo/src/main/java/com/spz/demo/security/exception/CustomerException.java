package com.spz.demo.security.exception;

/**
 * 自定义异常基类
 */
public class CustomerException extends Exception {
    public CustomerException(String message){
        super(message);
    }
}
