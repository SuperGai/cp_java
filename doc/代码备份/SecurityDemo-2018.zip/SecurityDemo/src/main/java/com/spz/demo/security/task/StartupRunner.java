package com.spz.demo.security.task;

import com.spz.demo.security.common.RedisConst;
import com.spz.demo.security.util.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 项目启动时执行的方法
 */
@Slf4j(topic = "USER_LOG")
@Component
@Order(1)
public class StartupRunner implements CommandLineRunner {

    @Autowired
    private RedisUtil redisUtil;

    @CacheEvict(value = RedisConst.PROJECT)
    @Override
    public void run(String... args) throws Exception {
        redisUtil.delete(redisUtil.keys(RedisConst.PROJECT + "*"));
        log.info("清空本项目的所有缓存");
    }


}

