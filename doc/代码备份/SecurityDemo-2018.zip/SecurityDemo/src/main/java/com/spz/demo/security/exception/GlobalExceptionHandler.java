package com.spz.demo.security.exception;

import com.spz.demo.security.bean.Message;
import com.spz.demo.security.common.MessageCode;
import com.spz.demo.security.exception.custom.RoleException;
import com.spz.demo.security.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import javax.smartcardio.CommandAPDU;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.ValidationException;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.Set;

/**
 * 一些自定义的异常处理
 *
 * @author spz
 */
@Slf4j(topic = "SYSTEM_LOG")
@ControllerAdvice//拦截异常
@Component
public class GlobalExceptionHandler {

    /**
     * hibernate 参数校验出错会抛出 ConstraintViolationException 异常
     * 在此方法中处理，将错误信息输出
     * @param exception
     * @return
     */
    @ExceptionHandler(ConstraintViolationException.class)//指定是哪个异常
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public Message hibernateViolationExceptionHandle(ValidationException exception) {
        String errorInfo = "";
        ConstraintViolationException exs = (ConstraintViolationException) exception;
        Set<ConstraintViolation<?>> violations = exs.getConstraintViolations();
        for (ConstraintViolation<?> item : violations) {
            errorInfo = errorInfo + "[" + item.getMessage() + "]";
        }
        return new Message().setErrorMessage(errorInfo);
    }

    /**
     * 拦截 Shiro 的 AuthenticationException 异常
     * @param e
     * @return
     */
    @ExceptionHandler(AuthenticationException.class)//指定是哪个异常
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public Message shiroAuthException(AuthenticationException e) {

        // 账号不存在 或 密码错误 异常
        // 两个异常放一起是为了防止暴力破解
        if(e instanceof IncorrectCredentialsException || e instanceof UnknownAccountException){
            return new Message().setLoginFailMessage("账号或密码错误");
        }

        return new Message().setErrorMessage(e.getCause().getMessage());
    }

    /**
     * 拦截自定义的 RoleException 异常
     * 一般在登录时出现此异常
     * @param e
     * @return
     */
    @ExceptionHandler(RoleException.class)//指定是哪个异常
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public Message roleException(RoleException e) {
        return new Message().setErrorMessage(e.getCause().getMessage());
    }

    /**
     * 拦截 CustomerException 异常
     * @param e
     * @return
     */
    @ExceptionHandler(CustomerException.class)//指定是哪个异常
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public Message customerException(CustomerException e) {
        log.error("捕获异常：" + CommonUtil.getDetailExceptionMsg(e));//具体异常打印到日志
        return new Message().setErrorMessage(e.getMessage());// 返回基本报错信息回前台
    }

    /**
     * 拦截 Exception 异常
     * @param e
     * @return
     */
    @ExceptionHandler(Exception.class)//指定是哪个异常
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public Message exception(Exception e) {
        log.error("捕获异常：" + CommonUtil.getDetailExceptionMsg(e));//具体异常打印到日志
        return new Message().setErrorMessage(
                "捕获异常：" + e.getMessage());// 返回基本报错信息回前台
    }
}
