package com.spz.demo.security.controller;

import com.alibaba.fastjson.JSONArray;
import com.spz.demo.security.bean.Message;
import com.spz.demo.security.common.MessageKeyConst;
import com.spz.demo.security.common.RedisConst;
import com.spz.demo.security.common.RequestMappingConst;
import com.spz.demo.security.common.WebConst;
import com.spz.demo.security.entity.Permission;
import com.spz.demo.security.entity.User;
import com.spz.demo.security.service.UserService;
import com.spz.demo.security.shiro.token.UserAuthenticationToken;
import com.spz.demo.security.util.CommonUtil;
import com.spz.demo.security.util.JwtUtil;
import com.spz.demo.security.util.RedisUtil;
import com.spz.demo.security.util.WebUtil;
import com.spz.demo.security.vo.JwtToken;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 用户控制器
 *
 * @author spz
 */
@Slf4j(topic = "USER_LOG")
@RestController
@Validated
public class UserController {

    @Value("${jwt.period}")
    private Long period;//token有效时间（毫秒）
    @Value(("${jwt.issuer}"))
    private String issuer;//jwt token 签发人

    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private UserService userService;
    @Autowired
    private RedisUtil redisUtil;
//    @Autowired
//    private UserPermissionService userPermissionService;

    /**
     * 用户登录
     * @return
     */
    @PostMapping(value = RequestMappingConst.LOGIN)
    public Message login(@NotEmpty(message = "账号不能为空") String account,
                         @NotEmpty(message = "密码不能为空") String password,
                         @NotEmpty(message = "验证码不能为空") String verifyCode,
                         @NotEmpty(message = "用户机器标识不能为空") String keyCode,
                         HttpServletRequest request,
                         HttpServletResponse response)throws Exception{
        // 验证码
        String redisVCode = redisUtil.get(RedisConst.VERIFY_CODE + keyCode);
        if(redisVCode == null){
            return new Message().setErrorMessage("请先获取验证码");
        }
        if(!redisVCode.equalsIgnoreCase(verifyCode)){
            return new Message().setErrorMessage("验证码错误");
        }

        // 使用 Shiro 进行登录
        Subject subject = SecurityUtils.getSubject();
        UserAuthenticationToken token = new UserAuthenticationToken(account,password);
        subject.login(token);

        // 登录成功后，获取userid，查询该用户拥有的权限
        List<String> permissions =  userService.getUserPermissions(token.getUserId());

        // 制作JWT Token
        String jwtToken = jwtUtil.issueJWT(
                CommonUtil.getRandomString(20),//令牌id
                token.getUserId() + "",//用户id
                (issuer == null ? JwtUtil.DEFAULT_ISSUER : issuer),//签发人
                null,//访问角色
                JSONArray.toJSONString(permissions),//用户权限集合，json格式
                (period == null ? JwtUtil.DEFAULT_PERIOD : period),//token有效时间
                SignatureAlgorithm.HS512
        );

        //token存入 response里的Header
        response.setHeader(WebConst.TOKEN,jwtToken);

        // 返回json
        Message message = new Message().setSuccessMessage("登录成功，token已存入header");
        message.getData().put("account",account);
        message.getData().put(MessageKeyConst.LOGIN_TIME,new Date().getTime());

        log.info("用户登录成功 ip=" + WebUtil.getIpAdrress(request));

        // 删除验证码存储
        redisUtil.delete(RedisConst.VERIFY_CODE + keyCode);

        return message;
    }

}
