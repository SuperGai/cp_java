package com.spz.demo.security.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.oracle.tools.packager.Log;
import com.spz.demo.security.common.DatabaseConst;
import com.spz.demo.security.common.RedisConst;
import com.spz.demo.security.entity.Permission;
import com.spz.demo.security.entity.RolePermission;
import com.spz.demo.security.entity.User;
import com.spz.demo.security.mapper.PermissionMapper;
import com.spz.demo.security.mapper.RoleMapper;
import com.spz.demo.security.mapper.UserMapper;
import com.spz.demo.security.service.UserService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.spz.demo.security.util.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
@Slf4j(topic = "SYSTEM_LOG")
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>  implements UserService{//

    @Autowired
    private PermissionMapper permissionMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private RedisUtil redisUtil;

    public User getUserByAccount(String account,int status,int isDeleted) {

        // 检查缓存，存在则读取
        if(redisUtil.get(RedisConst.USER_INFO + account) != null){
            return JSONObject.parseObject(redisUtil.get(RedisConst.USER_INFO + account),User.class);
        }

        // 从数据库中查询数据
        User param = new User();
        param.setAccount(account);
        param.setStatus(status);
        param.setIsDeleted(isDeleted);
        User user = userMapper.selectOne(param);
        if(user == null){
            return null;
        }
//        log.info("从数据库中查询用户数据");

        // 存入缓存
        redisUtil.set(RedisConst.USER_INFO + account,
                JSONObject.toJSONString(user));

        return user;
    }

    public List<String> getUserPermissions(long userId) {
        //获取用户所属角色
        User user = userMapper.selectById(userId);
        if(user == null){
            return new ArrayList<>();
        }

        // 查询角色所拥有权限
        List<Permission> permissions = permissionMapper.selectList(
                new EntityWrapper<Permission>().eq("role_id",user.getRoleId())
        );
        if(permissions == null || permissions.size() == 0){
            return new ArrayList<>();
        }

        //返回
        List<String> rest = new ArrayList<>();
        for(Permission permission : permissions){
            rest.add(permission.getUrl());
        }

        return rest;
    }
}
