package com.spz.demo.security.service;

import com.spz.demo.security.entity.Permission;
import com.baomidou.mybatisplus.service.IService;

import java.util.List;

/**
 * <p>
 * 权限表 服务类
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
public interface PermissionService extends IService<Permission> {

    /**
     * 获取指定角色的权限集合
     * @param roleId
     * @return
     */
    List<String> getPermissionsByRoleId(long roleId);

}
