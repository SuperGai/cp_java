package com.spz.demo.security.controller;

import com.google.code.kaptcha.Producer;
import com.spz.demo.security.bean.Message;
import com.spz.demo.security.common.RedisConst;
import com.spz.demo.security.common.RequestMappingConst;
import com.spz.demo.security.exception.CustomerException;
import com.spz.demo.security.exception.custom.RequestVariableException;
import com.spz.demo.security.util.CommonUtil;
import com.spz.demo.security.util.RedisUtil;
import com.spz.demo.security.util.WebUtil;
import com.sun.xml.internal.ws.resources.HttpserverMessages;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import sun.util.resources.cldr.sg.CurrencyNames_sg;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * 公用Controller接口
 * 此类中的接口均不需要身份验证
 */
@Slf4j(topic = "SYSTEM_LOG")
@RestController
@RequestMapping("/")
public class PublicController {

    @Autowired
    private Producer captchaProducer;//验证码工具
    @Autowired
    private RedisUtil redisUtil;

    /**
     * 生成图片验证码
     *
     * 关于keyCode：前端需要获取用户机器的唯一标识，如果无法获取，则需要前端生成一个随机不重复的字符串
     *              后台在生成验证码后，将以keyCode为key将验证码文字存储在缓存里
     *              前端在发起一次存在验证码参数的请求时，需要将keyCode再次作为请求参数发送，因为后台需要以此为key从缓存里获取验证码文字
     *              这样可以规避不同机器的验证码标识问题。
     *
     * @param keyCode 唯一机器标识
     * @return
     */
    @RequestMapping(value = RequestMappingConst.V_CODE + "/{keyCode}",method = RequestMethod.GET)
    public void getVerifyCode(@PathVariable String keyCode,
                              HttpServletRequest request,
                              HttpServletResponse response)throws Exception {
        if(CommonUtil.isBlank(keyCode)){
            throw new RequestVariableException("keyCode","缺少参数");
        }

        response.setDateHeader("Expires", 0);
        // Set standard HTTP/1.1 no-cache headers.
        response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
        // Set IE extended HTTP/1.1 no-cache headers (use addHeader).
        response.addHeader("Cache-Control", "post-check=0, pre-check=0");
        // Set standard HTTP/1.0 no-cache header.
        response.setHeader("Pragma", "no-cache");
        // return a jpeg
        response.setContentType("image/jpeg");

        // 建立验证码
        String capText = captchaProducer.createText();
        // 将指定验证码转为图片
        BufferedImage bi = captchaProducer.createImage(capText);
        ServletOutputStream out = null;
        try{
            out = response.getOutputStream();
            ImageIO.write(bi, "jpg", out);// write the data out
            out.flush();
        }catch (IOException ioe){
            log.error("出现异常：" + ioe);
        }finally {
            try {
                if(out != null){
                    out.close();
                }
            } catch (IOException ioe2){
                log.error("关闭资源时出现异常：" + ioe2);
            }
        }

        // 将验证码存入Redis
        redisUtil.delete(RedisConst.VERIFY_CODE + keyCode);//删除原来的
        redisUtil.set(RedisConst.VERIFY_CODE + keyCode,capText);
    }

    /**
     * 获取字符串对应的MD5字符串
     * @param str
     * @return
     */
    @GetMapping("/md5")
    public Message getMd5(String str){
        if(CommonUtil.isBlank(str)){
            return new Message().setErrorMessage("参数为空");
        }
        Message message = new Message().setSuccessMessage();
        message.getData().put("md5Str",CommonUtil.md5(str));
        return message;
    }


    /**
     * 欢迎页面
     * @return
     */
    @RequestMapping(value = "/index",method = {RequestMethod.POST,RequestMethod.GET})
    public String index(HttpServletRequest request,HttpServletResponse response){
        return "Hello! This is welcome page.";
    }

}
