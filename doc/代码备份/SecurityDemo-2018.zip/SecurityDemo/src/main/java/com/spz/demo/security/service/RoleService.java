package com.spz.demo.security.service;

import com.spz.demo.security.entity.Role;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 角色表 服务类
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
public interface RoleService extends IService<Role> {

}
