package com.spz.demo.security.common;

/**
 * Redis key 常量
 */
public class RedisConst {

    // ---- 全局常量 ----
    public static final String SPILT = ":";//分隔符
    public static final String PROJECT = "securityDemo";// 本项目

    //验证码
    public static final String VERIFY_CODE = PROJECT + SPILT + "verifyCode" + SPILT;

    //登录 jwt token
    public static final String LOGIN_TOKEN = PROJECT + SPILT + "loginToken" + SPILT;

    // 用户信息
    public static final String USER_INFO = PROJECT + SPILT + "userInfo" + SPILT;

}
