package com.spz.demo.security.shiro.filter;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.spz.demo.security.bean.Message;
import com.spz.demo.security.common.MessageCode;
import com.spz.demo.security.common.RequestMappingConst;
import com.spz.demo.security.common.WebConst;
import com.spz.demo.security.entity.Role;
import com.spz.demo.security.exception.custom.RoleException;
import com.spz.demo.security.util.CommonUtil;
import com.spz.demo.security.util.JwtUtil;
import com.spz.demo.security.util.WebUtil;
import com.spz.demo.security.vo.JwtToken;
import lombok.extern.slf4j.Slf4j;
import org.apache.shiro.web.filter.AccessControlFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 重写shiro拦截器
 * 所有请求由此拦截器拦截
 */
@Slf4j(topic = "USER_LOG")
@Component
public class ShiroLoginFilter extends AccessControlFilter {

    //由于项目启动时，Shiro加载比其他bean快，所以这里需要加入Lazy注解，在使用时再加载。否则会出现jwtUtil为null的情况
    @Autowired
    @Lazy
    private JwtUtil jwtUtil;

    @Override
    protected boolean isAccessAllowed(ServletRequest request,ServletResponse response, Object mappedValue) {
        // 判断请求是否是公共请求，通过请求的url判断
        if(WebUtil.isPublicRequest((HttpServletRequest) request)){
            return true;
        }
        return false;//  拒绝，统一交给 onAccessDenied 处理
    }

    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        HttpServletRequest httpServletRequest = (HttpServletRequest)request;
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;

        // ========== 判断是否是登录请求，是就放行，登录处理放在了controller层 ==========
        if(WebUtil.isLoginRequest(httpServletRequest)){
            return true;
        }

        // ========== 其他请求，都需要验证 ==========

        //验证是否登录（检查json token）
        if(CommonUtil.isBlank(httpServletRequest.getHeader(WebConst.TOKEN))){
            // 返回JSON给请求方
            WebUtil.writeJSONToResponse(httpServletResponse,JSON.toJSONString(
                    new Message()
                            .setErrorMessage("[" + WebConst.TOKEN +  "] 不能为空，请将token存入header")
            ));
            return false;
        }
        String token = httpServletRequest.getHeader(WebConst.TOKEN);
        JwtToken jwtToken;
        try {
            jwtToken = jwtUtil.parseJwt(token);
        }catch (RoleException re){//出现异常，说明验证失败
            Message message = new Message();
            if(re.getMessage().equals(RoleException.MSG_TOKEN_ERROR)){//token错误异常
                message.setMessage(MessageCode.TOKEN_ERROR,RoleException.MSG_TOKEN_ERROR);
            }else{//token过期异常
                message.setMessage(MessageCode.TOKEN_OVERDUE,RoleException.MSG_TOKEN_OVERDUE);
            }
            WebUtil.writeJSONToResponse((HttpServletResponse) response,JSON.toJSONString(message));//返回json
            return false;
        }
        if(jwtToken.getIsFlushed()){//需要刷新token
            httpServletResponse.setHeader(WebConst.TOKEN,jwtToken.getToken());// 更新response
        }

        // 检查用户是否具备权限
        if(!jwtToken.hasUrl(((HttpServletRequest) request).getRequestURI())){
            WebUtil.writeJSONToResponse((HttpServletResponse) response,JSON.toJSONString(
                    new Message()
                            .setPermissionDeniedMessage("没有权限")
            ));
            return false;
        }else{//登录验证通过
            return true;
        }
    }
}
