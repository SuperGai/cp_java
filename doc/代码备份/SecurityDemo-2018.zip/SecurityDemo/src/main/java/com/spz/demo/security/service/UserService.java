package com.spz.demo.security.service;

import com.spz.demo.security.entity.User;
import com.baomidou.mybatisplus.service.IService;

import java.util.List;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
public interface UserService extends IService<User> {//
    /**
     * 根据account获取用户信息
     * 启用redis，如果redis里有，则直接使用redis里的
     * @param account
     * @return
     */
    User getUserByAccount(String account,int status,int isDeleted);


    /**
     * 获取用户所拥有的权限
     * @param userId
     * @return
     */
    List<String> getUserPermissions(long userId);

}
