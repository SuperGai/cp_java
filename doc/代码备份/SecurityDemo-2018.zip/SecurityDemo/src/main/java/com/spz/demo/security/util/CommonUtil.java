package com.spz.demo.security.util;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/* *
 * @Author tomsun28
 * @Description 高频方法工具类
 * @Date 14:08 2018/3/12
 */
@Slf4j(topic = "SYSTEM_LOG")
public class CommonUtil {

    /**
     * 获取指定位数的随机数
     * @param length
     * @return
     */
    public static String getRandomString(int length) {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }

    /**
     * MD5加密
     * @param content
     * @return
     */
    public static String md5(String content) {
        // 用于加密的字符
        char[] md5String = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
        try {
            // 使用平台默认的字符集将md5String编码为byte序列,并将结果存储到一个新的byte数组中
            byte[] byteInput = content.getBytes();

            // 信息摘要是安全的单向哈希函数,它接收任意大小的数据,并输出固定长度的哈希值
            MessageDigest mdInst = MessageDigest.getInstance("MD5");

            // MessageDigest对象通过使用update方法处理数据,使用指定的byte数组更新摘要
            mdInst.update(byteInput);

            //摘要更新后通过调用digest() 执行哈希计算,获得密文
            byte[] md = mdInst.digest();

            //把密文转换成16进制的字符串形式
            int j = md.length;
            char[] str = new char[j*2];
            int k = 0;
            for (int i=0;i<j;i++) {
                byte byte0 = md[i];
                str[k++] = md5String[byte0 >>> 4 & 0xf];
                str[k++] = md5String[byte0 & 0xf];
            }
            // 返回加密后的字符串
            return new String(str);
        }catch (Exception e) {
            log.error("加密出现错误：" + e.toString());
            return null;
        }

    }

    /**
     * 分割字符串进SET
     */
    @SuppressWarnings("unchecked")
    public static Set<String> split(String str) {

        Set<String> set = new HashSet<>();
        if (StringUtils.isEmpty(str))
            return set;
        set.addAll(CollectionUtils.arrayToList(str.split(",")));
        return set;
    }

    /**
     * 检查字符串是否为空
     * @param str
     * @return
     */
    public static boolean isBlank(String str){
        return (str == null || str.equals("") ? true : false);
    }

    /**
     * 将异常详细详细提取到字符串返回，建议输出到日志
     * 返回字符串内含：异常信息、异常栈
     * 返回的异常栈包含：[异常文件名：行数] 类名.方法名
     * @param e
     * @return null 提取失败
     */
    public static String getDetailExceptionMsg(Throwable e){
        if(e == null || e.getStackTrace() == null ||
                e.getStackTrace().length <= 0){
            return null;
        }

        StackTraceElement[] stackTraces = e.getStackTrace();
        String msg = e.getMessage() + "\n";
        for(StackTraceElement s : stackTraces){
            msg += "\t[" + s.getFileName() + ":" + s.getLineNumber() + "] " +
                    s.getClassName() + "." + s.getMethodName() + "()" +
                    "\n";
        }
        return msg;
    }
}
