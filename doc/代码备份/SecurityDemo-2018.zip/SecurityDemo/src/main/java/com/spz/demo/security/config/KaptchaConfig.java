package com.spz.demo.security.config;

import com.google.code.kaptcha.impl.DefaultKaptcha;
import com.google.code.kaptcha.util.Config;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

/**
 * Kaptcha 验证码工具 bean 配置
 */
@Slf4j(topic = "SYSTEM_LOG")
@Configuration
@EnableAutoConfiguration
public class KaptchaConfig {

    @Bean
    public DefaultKaptcha configKaptcha(){//
        Properties prop = new Properties();
        prop.setProperty("kaptcha.border","no");
        prop.setProperty("kaptcha.border.color","105,179,90");
        prop.setProperty("kaptcha.textproducer.font.color","red");
        prop.setProperty("kaptcha.image.width","250");
        prop.setProperty("kaptcha.textproducer.font.size","80");
        prop.setProperty("kaptcha.image.height","90");
        prop.setProperty("kaptcha.session.key","code");
        prop.setProperty("kaptcha.textproducer.char.length","4");
        prop.setProperty("kaptcha.textproducer.font.names","宋体,楷体,微软雅黑");
        DefaultKaptcha defaultKaptcha = new DefaultKaptcha();
        defaultKaptcha.setConfig(new Config(prop));
        return defaultKaptcha;
    }
}
