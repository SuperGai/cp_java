package com.spz.demo.security.common;

public class MessageKeyConst {

    public static final String LOGIN_TIME = "loginTime";

    public static final String LOGOUT_TIME = "logoutTime";

}
