package com.spz.demo.security.mapper;

import com.spz.demo.security.entity.Role;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 * 角色表 Mapper 接口
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
public interface RoleMapper extends BaseMapper<Role> {

}
