package com.spz.demo.security.exception.custom;

import com.spz.demo.security.exception.CustomerException;

/**
 * 自定义异常类
 * 权限异常
 * 在登录异常、权限异常时可抛出
 */
public class RoleException extends CustomerException {

    public static final String MSG_TOKEN_ERROR = "token 不合法";//token 不合法
    public static final String MSG_TOKEN_OVERDUE = "token 已过期，需要重新登录";//token 已过期，需要重新登录
    public static final String MSG_UNKNOWN_ERROR = "未知错误";//token 不合法

    public RoleException(String message){
        super(message);
    }
}
