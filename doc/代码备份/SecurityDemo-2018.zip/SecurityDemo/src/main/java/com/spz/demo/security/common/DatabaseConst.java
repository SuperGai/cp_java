package com.spz.demo.security.common;

public class DatabaseConst {
    // 是否删除，对应数据库字段 is_deleted
    public static final int IS_DETETED_YES = 1;
    public static final int IS_DETETED_NO = 0;

    // 是否启用，对应数据库字段 status
    public static final int STATUS_ENABLE = 1;
    public static final int STATUS_DISABLE = 0;
}
