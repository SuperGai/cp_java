-- Sql
-- Mysql Version 5.7
-- author 1802226517@qq.com

drop database if exists `rb_demo`;
CREATE DATABASE rb_demo
  DEFAULT CHARACTER SET utf8
  COLLATE utf8_general_ci;
USE rb_demo;

-- ------------------------------ 用户部分 ------------------------------

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键',
  `account` VARCHAR(50) NOT NULL COMMENT '账号，唯一',
  `password` VARCHAR(100) NOT NULL COMMENT '密码',
  `name` VARCHAR(100) DEFAULT '默认用户名' COMMENT '昵称',
  `role_id` BIGINT UNSIGNED NOT NULL COMMENT '所属角色id',
  `status` TINYINT UNSIGNED NOT NULL COMMENT '是否启用',
  `is_deleted` TINYINT UNSIGNED NOT NULL COMMENT '是否删除',
  `version` BIGINT UNSIGNED NOT NULL COMMENT '版本',
  `gmt_create` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户表';

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` VARCHAR(200) NOT NULL COMMENT '角色名称',
  `version` BIGINT UNSIGNED NOT NULL COMMENT '版本',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色表';

DROP TABLE IF EXISTS `permission`;
CREATE TABLE `permission` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '主键',
  `role_id` BIGINT UNSIGNED NOT NULL COMMENT '所属角色id',
  `name` VARCHAR(200) NOT NULL COMMENT '权限名称',
  `url` VARCHAR(200) NOT NULL COMMENT '匹配url',
  `version` BIGINT UNSIGNED NOT NULL COMMENT '版本',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限表';

-- ------------------------------  ------------------------------