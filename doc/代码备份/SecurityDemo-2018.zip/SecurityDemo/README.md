## 2019-2-20
此项目已弃用，请移步 [SpringBoot单应用Demo](https://gitee.com/spzmmd/single-java-demo)

### SpringBoot小项目快速搭建
用于小Spring Boot项目的快速搭建与开发。 
包含了用户登录模块、权限模块（通过请求url来验证权限）、跨域处理、日志模块、Controller层参数校验、异常处理、redis缓存和其他一些小工具。

#### 环境
* Redis
* lombok IDEA 插件

#### 相关配置参考

* 常规配置 

server、Redis、JWT、database、Mybatis-plus都在application.yml内配置

* 配置日志 

开发阶段，将 *logback-spring.xml* 文件里输出到文件的 appender-ref 改为 consoleLog ，这样开发时日志不输出到文件而是输出到控制台。 
```
<logger name="SYSTEM_LOG" additivity="false" level="INFO">
    <appender-ref ref="consoleLog"/>
</logger>
<logger name="USER_LOG" additivity="false" level="INFO">
     <appender-ref ref="consoleLog"/>
</logger>
```

发布时，将输出到文件的 appender-ref 改成原有的logger名称即可，如 systemLog 和 userLog 

* 配置Mybatis sql输出(适用于开发环境) 
在 *logback-spring.xml* 文件里加入以下代码： 
```
<!-- Mybatis sql 输出 -->
<logger name="com.spz.demo.security.mapper" level="DEBUG">
    <appender-ref ref="consoleLog"/>
</logger>
```
com.spz.demo.security.mapper为存放mapper接口的包名。这样mybatis将输出sql语句到控制台，如果需要输出到文件，则更改appender-ref标签即可.


* 配置验证码 

验证码采用 *Kaptcha* 插件。配置类为 **KaptchaConfig** 。 
使用时，需要先注入bean: 
```
@Autowired
private Producer captchaProducer;//验证码工具
```
具体使用方法参考： **BaseController.getVerifyCode()** 方法。

* 使用 Mybatis-plus 代码生成器 

代码生成器类在 util 包里的 MpGenerator.java ，可根据数据库的表结构生成entity、Service、ServiceImpl、mapper、mapper-xml和controller类。
生成的文件存放在项目目录的temp文件夹下。

* 使用Redis缓存 

需要注入RedisUtil工具类，具体使用参考UserServiceImpl.getUserByAccount()。 

建议：需要存储对象时，使用fastjson转为json再存入redis 

注意，默认启动了缓存功能，项目开始运行时，会清空缓存. 

如果需要使用注解缓存，需参考此文：
[在Shiro框架内使用缓存注解失效的解决办法](https://www.jianshu.com/p/f0428af8e163)

* web层拦截器 

由ShiroLoginFilter.java拦截所有请求。 

不需要拦截的请求url，请使用 RequestMappingConst.BASIC_URL_PUBLIC 前缀 

建议：特殊的请求url配置在 RequestMappingConst 中 

* 项目部署到外部Tomcat 

[spring-boot项目在外部tomcat环境下部署](https://blog.csdn.net/james_wade63/article/details/51009423) 

推荐使用maven的package命令打包war 


#### 登录流程
1. 用户登录，系统验证用户成功后，签发JWT token，存入response里的Header 
2. 前端从response里取出 Header 里的token 
3. 在下一次请求中，前端将token存入request里的header。服务器接收到请求，在拦截器(ShiroLoginFilter.java)里检查token是否合法，并检查是否过期 
    
    注意：
    如果token超过有效期，服务器会负责刷新token，并设置到response的Header里
    如果token超过两倍有效期，则需要重新登录 
    
4. 前端接收到服务器请求返回后，检查header里有没有token，有则说明服务器刷新了token，前端需要将新token放在request的header里进行下一次请求
5. 用户点击注销后，前端删除token即可

#### 数据库
用户登录和权限需要3个数据表： *user* 、 *permission* 和 *role* 。 
_user表存储用户基本信息，permission 表存储权限信息(即请求url)，role存储角色信息，校验权限时，是通过请求url来校验的。
比如用户尝试请求携带/index的url接口，后台拿到用户id后，找到user表里的用户信息，得到用户角色，再去permission表里获取该角色拥有的url列表，检查里面是否有/index，有则说明该用户有访问权限  

#### 关于此Demo的解析
* [Shiro和SpringBoot简单集成](https://www.jianshu.com/p/96a7b509706f)
* [Redis 和 Springboot基础整合](https://www.jianshu.com/p/ffcacf078602)
* [Spring boot 和 mybatis-plus基础整合](https://www.jianshu.com/p/9d5e035054e6)


#### 完成此项目，参考了这些文章
* [Controller 层参数校验方案](https://www.jianshu.com/p/aa8b3163b30a)
* [日志处理方案](https://www.jianshu.com/p/ba54f27d4a24)
* [最全的Java操作Redis的工具类](https://github.com/whvcse/RedisUtil)
* [签发的用户认证token超时刷新策略](https://segmentfault.com/a/1190000014545422)
* [Mybatis-Plus](http://mp.baomidou.com/#/quick-start)
* [Mybatis-Plus代码生成器](https://blog.csdn.net/qq_26641781/article/details/80352150)
* [shiro实现手机验证码登录](https://blog.csdn.net/modjie/article/details/79221774)
* [SpringBoot 集成无状态的 Shiro](http://412887952-qq-com.iteye.com/blog/2359097)

#### 备注
* Spring Boot版本暂时只能使用1.5.15.RELEASE版