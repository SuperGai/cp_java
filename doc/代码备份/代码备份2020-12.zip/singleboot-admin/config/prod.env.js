'use strict'
module.exports = {
  NODE_ENV: '"production"',
  baseUrl: '"http://localhost:9093"', // 生产环境访问接口
}
