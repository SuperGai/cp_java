# singleboot-admin

## 配置&部署&运行
* API根路径
  分别修改 config\dev.env.js 里面各环境的baseUrl即可

* API接口路径
  在 src\config\api.js 里配置

* 新模块文件配置
  新添加的模块，均在 src\config\routes.js 里配置路由

* 全局配置
  src\constant\Global.js

* 运行&部署
```
yarn install

# 运行测试版
yarn run dev

# 打包
yarn run build
```

## 指南
* 网站标题、版权信息等配置在src/constant/Global.js
* 增删改查基本页面的编写可参考
  src\views\system-role\目录下的文件
* 时间格式处理
  $DateTimeFormat(time).format("YYYY-MM-DD HH:mm:ss")

* 权限校验 - 路由权限(菜单等)
src\router.js文件里配置
```javascript
route.beforeEach((to, from, next) => {
   if(to.path === '/login'){
     next();
   }else{
     let token = localStorage.getItem(global.localStoreKey.token);
     if(token === null || token === ''){
       next('/login');
     }else{
       next();
     }
   }
  next();
})
```

* 权限校验 - 接口jwt token处理
src\main.js文件里配置，使用localStorage存储token、登录用户信息
```javascript
// axios
import axios from 'axios'
Vue.prototype.$axios = axios
axios.defaults.withCredentials = true // 每次请求携带sessionid，不配置此项后台无法获取登录信息
// 请求拦截 在请求头中加token
axios.interceptors.request.use(config => {
    if(localStorage.getItem(global.localStoreKey.token)){
      config.headers.Authorization = localStorage.getItem(global.localStoreKey.token);
    }
    return config;
  },
error => {
  return Promise.reject(error);
})
// 响应拦截
axios.interceptors.response.use(function (response) {
  // 是否登录异常
  if(response.data.code === 4003 || // token为空
    response.data.code === 4004){// token错误
    console.log("登录信息已超时，请重新登录, code: " + response.data.code)
    localStorage.removeItem(global.localStoreKey.token)
    router.push('/login')
  }

  // 如果返回头里传入了新的token，则需要刷新
  if(response.headers.authorization != undefined){
    localStorage.setItem(global.localStoreKey.token,response.headers.authorization)
  }

  return response;
}, function (error) {
  return Promise.reject(error);
});
```

* 权限校验 - 根据权限显示按钮
  在要显示在标签上加上v-if，通过isUrlPermit方法检查是否有权限来决定是否显示按钮，例如
  ```vue
  <el-button v-if="this.$GLOBAL.isUrlPermit(this.$API.menu.add)">新增</el-button>
  ```

* 网络请求
```javascript
// ======= post请求 =======
let vm = this;
let query = vm.$qs.stringify(// 将多个对象参数组织起来
  Object.assign({}, this.table.pager,this.searchForm)
)
vm.$axios.post(vm.api.batchDelete, vm.$qs.stringify({ids: ids}, { indices: false })).then(response => {
  if(response.data.code == 2000) {
    vm.search()
    vm.$message.success(response.data.message)
  }else{
    vm.$message.error(response.data.message)
  }
}).catch(response => {
  console.log(response)
  vm.loginResult = "系统异常"
})
```
```javascript
// ======= post请求 - 请求列表 =======
let vm = this;
let query = vm.$qs.stringify(
  Object.assign({}, this.table.pager,this.searchForm)
)
vm.$axios.post(vm.api.listPage, vm.$qs.stringify()).then(response => {
  if(response.data.code == 2000) {
    vm.table.data = response.data.data.records
    vm.table.pager.size = response.data.data.size
    vm.table.pager.total = response.data.data.total
    vm.table.pager.current = response.data.data.current
  }else{
    vm.$message.error(response.data.message);
  }
}).catch(response => {
  console.log(response)
  vm.loginResult = "系统异常"
})
```

* 在删除等操作前需要弹窗提示用户确认
```javascript
this.$confirm('此操作将删除所选记录, 是否继续?', '提示', {
  confirmButtonText: '确定',
  cancelButtonText: '取消',
  type: 'warning'
}).then(() => {
  // 删除等操作....
})
```

* 页面跳转与传参
```javascript
// 页面跳转并传参
this.$router.push({
  path: '/system-role/edit',
  query: {id: 123}
})
// 新页面获取参数
this.$route.query.id
```

* 表格列按格式展示时间字段
```html
<el-table-column label="日志时间" width="180">
  <template slot-scope="scope">
    {{$DateTimeFormat(scope.row.createTime).format("YYYY-MM-DD HH:mm:ss")}}
  </template>
</el-table-column>
```

* 时间段查询请求案例
```vue
<template>
  <list-page :pager="table.pager">
<!-- 表格 表单 -->
    <div slot="table-body">
      <!-- 查询表单 -->
      <el-form :inline="true" size="mini" class="search-form" ref='form' :model="searchForm">

        <el-form-item class="search-form-item" label="设备编号" prop="code">
          <el-input v-model="searchForm.code" placeholder="设备编号"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="日志时间" prop="queryTimeList">
          <el-date-picker v-model="searchForm.queryTimeList" type="datetimerange"
            range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期">
          </el-date-picker>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="search" >查询</el-button>
        </el-form-item>

      </el-form>
      <!-- 表格 -->
      <el-table :data="table.data" @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="50"></el-table-column>
        <el-table-column type="index" width="50"></el-table-column>

        <el-table-column label="日志时间" width="180">
          <template slot-scope="scope">
            {{$DateTimeFormat(scope.row.createTime).format("YYYY-MM-DD HH:mm:ss")}}
          </template>
        </el-table-column>

        <el-table-column
          prop="temperature"
          label="温度">
        </el-table-column>

      </el-table>
    </div>

  </list-page>
</template>
<script>
  import ListPage from "../../components/ListPage";
  import ParentMenuSelect from '../../components/ParentMenuSelect'
  import DictSelect from "../../components/DictSelect";
  export default {
    name: 'IrrigateLogList',
    components: {DictSelect, ParentMenuSelect, ListPage},
    data(){
      return{
        searchForm: {
          queryTimeList: null,
          startTime: '',
          endTime: '',
          name: '',
          code: '',
        },
        // 表格数据
        table: {
          data: []
        },
      }
    },
    methods: {
      search(){
        let vm = this;

        // 对查询时间进行处理
        if(vm.searchForm.queryTimeList != null && vm.searchForm.queryTimeList.length == 2){
          vm.searchForm.startTime = vm.$DateTimeFormat(vm.searchForm.queryTimeList[0]).format("YYYY-MM-DD HH:mm:ss")
          vm.searchForm.endTime= vm.$DateTimeFormat(vm.searchForm.queryTimeList[1]).format("YYYY-MM-DD HH:mm:ss")
        }else{
          vm.searchForm.startTime = null
          vm.searchForm.endTime = null
        }

        // 请求接口完成查询
        let query = vm.$qs.stringify(
          Object.assign({}, vm.table.pager,vm.searchForm)
        )
        vm.$axios.post(vm.$API.xxx.ListPage, query).then(response => {
          if(response.data.code === 2000) {
            vm.table.data = response.data.data.records
          }else{
            vm.$message.error(response.data.message)
          }
        }).catch(response => {
          console.log(response)
          vm.loginResult = "系统异常"
        })
      }
    }
  }
</script>
<style scoped>
</style>
```
