import Vue from 'vue'
import App from './App.vue'
import router from './router'
import global from './constant/Global'

// 全局变量
Vue.prototype.$GLOBAL = global;

// element-ui
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
Vue.use(ElementUI)

// 时间格式化插件
import moment from 'moment'
Vue.prototype.$DateTimeFormat = moment;

// axios
import axios from 'axios'
Vue.prototype.$axios = axios
axios.defaults.withCredentials = true // 每次请求携带sessionid，不配置此项后台无法获取登录信息
// 请求拦截 在请求头中加token
axios.interceptors.request.use(config => {
    if(localStorage.getItem(global.localStoreKey.token)){
      config.headers.Authorization = localStorage.getItem(global.localStoreKey.token);
    }
    return config;
  },
error => {
  return Promise.reject(error);
})
// 响应拦截
axios.interceptors.response.use(function (response) {
  // 是否登录异常
  if(response.data.code === 4003 || // token为空
    response.data.code === 4004){// token错误
    console.log("登录信息已超时，请重新登录, code: " + response.data.code)
    localStorage.removeItem(global.localStoreKey.token)
    router.push('/login')
  }

  // 如果返回头里传入了新的token，则需要刷新
  if(response.headers.authorization != undefined){
    localStorage.setItem(global.localStoreKey.token,response.headers.authorization)
  }

  return response;
}, function (error) {
  return Promise.reject(error);
});

// qs
import qs from 'qs'
Vue.prototype.$qs = qs

// api
import api from './config/api'
Vue.prototype.$API = api

Vue.config.productionTip = false

let VueContext = new Vue({
  router,
  render: h => h(App)
}).$mount('#app')

// 将Vue实例导出
export default VueContext
