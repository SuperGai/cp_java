
// API 相关定义

const BASIC_URL = process.env.baseUrl

export default Object.assign(
  // API 根路径
  {
    BASIC_URL: process.env.baseUrl
  },
  // API 接口定义
  {
    // api 管理
    api: {
      dropdownList: `${BASIC_URL}/sys/api/dropdownList`,
      listPage: `${BASIC_URL}/sys/api/listPage`,
      batchDelete: `${BASIC_URL}/sys/api/deleteById`,
      delete: `${BASIC_URL}/sys/api/deleteById`,
      add: `${BASIC_URL}/sys/api/add`,
      update: `${BASIC_URL}/sys/api/update`,
      detail: `${BASIC_URL}/sys/api/detail`,
    },
    // 系统功能管理
    fun: {
      dropdownList: `${BASIC_URL}/sys/function/dropdownList`,
      listPage: `${BASIC_URL}/sys/function/listPage`,
      batchDelete: `${BASIC_URL}/sys/function/deleteById`,
      delete: `${BASIC_URL}/sys/function/deleteById`,
      add: `${BASIC_URL}/sys/function/add`,
      update: `${BASIC_URL}/sys/function/update`,
      detail: `${BASIC_URL}/sys/function/detail`,
      apiTree: `${BASIC_URL}/sys/function/api/tree`,
      treeUpdate: `${BASIC_URL}/sys/function/api/tree/update`
    },
    // 字典类型管理
    dictType: {
      dropdownList: `${BASIC_URL}/sys/dict/type/dropdownList`,
      listPage: `${BASIC_URL}/sys/dict/type/listPage`,
      batchDelete: `${BASIC_URL}/sys/dict/type/deleteById`,
      delete: `${BASIC_URL}/sys/dict/type/deleteById`,
      add: `${BASIC_URL}/sys/dict/type/add`,
      update: `${BASIC_URL}/sys/dict/type/update`,
      detail: `${BASIC_URL}/sys/dict/type/detail`,
    },
    // 字典管理
    dict: {
      dropdownList: `${BASIC_URL}/sys/dict/dropdownList`,
      listPage: `${BASIC_URL}/sys/dict/listPage`,
      batchDelete: `${BASIC_URL}/sys/dict/deleteById`,
      delete: `${BASIC_URL}/sys/dict/deleteById`,
      add: `${BASIC_URL}/sys/dict/add`,
      update: `${BASIC_URL}/sys/dict/update`,
      detail: `${BASIC_URL}/sys/dict/detail`,
    },
    // 角色管理
    role: {
      menuTree: `${BASIC_URL}/sys/role/menu/tree`,
      menuTreeUpdate: `${BASIC_URL}/sys/role/menu/tree/update`,
      dealPermit: `${BASIC_URL}/sys/role/dealPermit`,// 分配权限
      listPage: `${BASIC_URL}/sys/role/listPage`,
      batchDelete: `${BASIC_URL}/sys/role/deleteById`,
      delete: `${BASIC_URL}/sys/role/deleteById`,
      add: `${BASIC_URL}/sys/role/add`,
      update: `${BASIC_URL}/sys/role/update`,
      detail: `${BASIC_URL}/sys/role/detail`,
      apiTree: `${BASIC_URL}/sys/role/function/tree`,
      treeUpdate: `${BASIC_URL}/sys/role/function/tree/update`
    },
    // 菜单管理
    menu: {
      dropdownList: `${BASIC_URL}/sys/menu/dropdownList`,
      listPage: `${BASIC_URL}/sys/menu/listPage`,
      batchDelete: `${BASIC_URL}/sys/menu/deleteById`,
      delete: `${BASIC_URL}/sys/menu/deleteById`,
      add: `${BASIC_URL}/sys/menu/add`,
      update: `${BASIC_URL}/sys/menu/update`,
      detail: `${BASIC_URL}/sys/menu/detail`,
    },
    // 用户管理
    user: {
      list: `${BASIC_URL}/sys/user/list`,
      update: `${BASIC_URL}/sys/user/update`,
    },
    // 其他
    others: {
      menuTree: `${BASIC_URL}/auth/menu/tree`,
      permitApis: `${BASIC_URL}/auth/permit/apis`,
      login: `${BASIC_URL}/auth/login`,
      verifyCode: `${BASIC_URL}/verifyCode`,
      getLoginInfo: `${BASIC_URL}/auth/login/info`,
      updateLoginInfo: `${BASIC_URL}/auth/login/update`,
    }
  }
)
