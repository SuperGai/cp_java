
import index from '../views/index'

// 路由配置
export default [
  {
    path: '/',
    name: 'index',
    meta: {tab: false},
    component: index,
    children: [
      // 系统 - api管理
      {
        path: '/system-api/list',
        name: 'system-api-list',
        meta: {title: '接口管理', tab: true},
        component: () => import('../views/system-api/List'),
      },
      {
        path: '/system-api/add',
        name: 'system-api-add',
        meta: {title: '添加接口', tab: true},
        component: () => import('../views/system-api/Add'),
      },
      {
        path: '/system-api/edit',
        name: 'system-api-edit',
        meta: {title: '编辑接口', tab: true},
        component: () => import('../views/system-api/edit'),
      },
      // 系统 - 功能管理
      {
        path: '/system-function/list',
        name: 'system-function-list',
        meta: {title: '功能管理', tab: true},
        component: () => import('../views/system-function/List'),
      },
      {
        path: '/system-function/add',
        name: 'system-function-add',
        meta: {title: '添加功能', tab: true},
        component: () => import('../views/system-function/Add'),
      },
      {
        path: '/system-function/edit',
        name: 'system-function-edit',
        meta: {title: '编辑功能', tab: true},
        component: () => import('../views/system-function/edit'),
      },
      {
        path: '/system-function/apiConfig',
        name: 'system-function-apiConfig',
        meta: {title: '功能接口配置', tab: true},
        component: () => import('../views/system-function/apiConfig'),
      },
      // 系统 - 菜单管理
      {
        path: '/system-menu/list',
        name: 'system-menu-list',
        meta: {title: '菜单管理', tab: true},
        component: () => import('../views/system-menu/List'),
      },
      {
        path: '/system-menu/add',
        name: 'system-menu-add',
        meta: {title: '添加菜单', tab: true},
        component: () => import('../views/system-menu/Add'),
      },
      {
        path: '/system-menu/edit',
        name: 'system-menu-edit',
        meta: {title: '编辑菜单', tab: true},
        component: () => import('../views/system-menu/Edit'),
      },
      // 系统 - 角色管理
      {
        path: '/system-role/list',
        name: 'system-role-list',
        meta: {title: '角色管理', tab: true},
        component: () => import('../views/system-role/List'),
      },
      {
        path: '/system-role/add',
        name: 'system-role-add',
        meta: {title: '添加角色', tab: true},
        component: () => import('../views/system-role/Add'),
      },
      {
        path: '/system-role/edit',
        name: 'system-role-edit',
        meta: {title: '编辑角色', tab: true},
        component: () => import('../views/system-role/Edit'),
      },
      {
        path: '/system-role/menuConfig',
        name: 'system-role-menuConfig',
        meta: {title: '配置菜单', tab: true},
        component: () => import('../views/system-role/MenuConfig'),
      },
      {
        path: '/system-role/functionConfig',
        name: 'system-role-functionConfig',
        meta: {title: '配置功能', tab: true},
        component: () => import('../views/system-role/functionConfig'),
      },
      // 系统 - 字典类型管理
      {
        path: '/system-dictType/list',
        name: 'system-dictType-list',
        meta: {title: '字典类型管理', tab: true},
        component: () => import('../views/system-dictType/List'),
      },
      {
        path: '/system-dictType/add',
        name: 'system-dictType-add',
        meta: {title: '添加字典类型', tab: true},
        component: () => import('../views/system-dictType/Add'),
      },
      {
        path: '/system-dictType/edit',
        name: 'system-dictType-edit',
        meta: {title: '编辑字典类型', tab: true},
        component: () => import('../views/system-dictType/Edit'),
      },
      // 系统 - 字典管理
      {
        path: '/system-dict/list',
        name: 'system-dict-list',
        meta: {title: '字典管理', tab: true},
        component: () => import('../views/system-dict/List'),
      },
      {
        path: '/system-dict/add',
        name: 'system-dict-add',
        meta: {title: '添加字典', tab: true},
        component: () => import('../views/system-dict/Add'),
      },
      {
        path: '/system-dict/edit',
        name: 'system-dict-edit',
        meta: {title: '编辑字典', tab: true},
        component: () => import('../views/system-dict/Edit'),
      },
      // 系统 - 用户管理
      {
        path: '/system-user/editPassword',
        name: 'system-user-editPassword',
        meta: {title: '修改密码', tab: true},
        component: () => import('../views/system-user/EditPassword'),
      },
      {
        path: '/loginDetail',
        name: 'loginDetail-page',
        meta: {title: '登录用户详情', tab: true},
        component: () => import('../views/LoginDetail'),
      },
      // 杂项
      {
        path: '/home',
        name: 'home-page',
        meta: {title: '首页', tab: true},
        component: () => import('../views/info/Home'),
      },
      {
        path: '/about',
        name: 'about-page',
        meta: {title: '关于', tab: true},
        component: () => import('../views/info/About'),
      }
    ]
  },
  {
    path: '/login',
    name: 'login-page',
    meta: {title: '登录页', tab: true},
    component: () => import('../views/Login'),
  }
]

