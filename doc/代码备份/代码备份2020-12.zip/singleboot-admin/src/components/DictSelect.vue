<template>
    <span>
        <el-select v-model="selectValue" placeholder="请选择" clearable>
          <el-option v-for="item in items"
                     :key="item.id"
                     :label="item.name"
                     :value="item.value">
          </el-option>
        </el-select>
        <input v-model="value" style="display: none"></input>
    </span>
</template>

<script>
export default {
  name: "DictSelect",
  props:{
    // 字典类型标识
    typeCode: {
      type: String,
      default: function () {
        return ''
      }
    },
    // 字典值
    value: {
      type: String,
      default: function () {
        return ''
      }
    },
  },
  watch:{
    value:{
      deep:true,
      handler:function () {
        this.selectValue = this.value;
      }
    },
    selectValue:{
      deep:true,
      handler:function () {
        this.$emit('input',this.selectValue);
      }
    }
  },
  data(){
    return {
      items:[],
      selectValue:'',
    }
  },
  created() {
    let vm = this;
    vm.$axios.post(vm.$API.dict.dropdownList, vm.$qs.stringify({typeCode: vm.typeCode})).then(response => {
      if(response.data.code === 2000) {
        vm.items = response.data.data
      }else{
        vm.$message.error(response.data.message)
      }
    });
    vm.selectValue = vm.value
  }
}
</script>

<style scoped>

</style>
