<template>
  <div class="body-page" id="body_page_div">

    <!-- 返回按钮 -->
    <el-page-header @back="goBack" :content="$route.meta.title" class="body-page-header">
    </el-page-header>

    <!-- 内容主体 -->
    <div class="body-page-content" >
      <slot></slot>
    </div>

  </div>
</template>

<script>
  export default {
    name: 'BodyPage',
    components: {},
    data(){
      return {

      }
    },
    methods: {
      goBack(){
        this.$router.back();
      }
    }
  }
</script>

<style scoped>

  .body-page {
    /*height: calc((100% - 20px) - 20px);*/
    /*position: relative;*/
    /*overflow: auto;*/
    /*overflow-y:scroll;*/

  }

  .body-page-content {
    overflow: auto;
    /*width: calc((100% - 20px) - 2 0px);*/
    /*position: relative;*/
    /*position: absolute;*/
    margin-top: 20px;
    /*background: white;*/
    /*padding: 20px;*/
  }

  .body-page-header {
  }

</style>
