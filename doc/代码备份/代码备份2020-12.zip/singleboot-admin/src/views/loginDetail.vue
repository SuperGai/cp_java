<template>
  <body-page>
    <div class="body-page-child">
      <el-form style="width: 40%;" ref="form" :model="form" label-width="80px" :rules="rule">

        <el-form-item label="账号">
          <el-input v-model="form.account" readonly></el-input>
        </el-form-item>

        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name"></el-input>
        </el-form-item>

        <el-form-item label="手机号">
          <el-input v-model="form.phone"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="onSubmit">提交</el-button>
          <el-button @click="onCancel">取消</el-button>
        </el-form-item>

      </el-form>
    </div>
  </body-page>
</template>

<script>
  import BodyPage from '../components/BodyPage'
  export default {
    name: 'LoginDetail',
    components: {BodyPage},
    data(){
      return {
        form: {
          id: '',
          account: '',
          name: '',
          phone: ''
        },
        rule: {
          name: [
            { required: true, message: '姓名不能为空', trigger: 'blur' },
          ]
        }
      }
    },
    methods: {
      onSubmit(){
        let vm = this
        this.$axios.post(vm.$API.others.updateLoginInfo,vm.$qs.stringify(vm.form)).then(response => {
          if (response.data.code === 2000) {
            localStorage.setItem(vm.$GLOBAL.localStoreKey.loginUserInfo,JSON.stringify(response.data.data))
            for(let key in this.form){
              this.form[key] = response.data.data[key]
            }
            vm.$message.success(response.data.message)
            vm.$router.back()
          }else{
            vm.$message.error(response.data.message)
          }
        }).catch(response => {
          console.log(response)
          vm.loginResult = "系统异常"
        })
      },
      onCancel(){
        this.$router.back()
      }
    },
    created() {
      let loginInfo = JSON.parse(localStorage.getItem(this.$GLOBAL.localStoreKey.loginUserInfo))
      if(loginInfo == null) {
        this.$router.replace('/login')
      }

      for(let key in this.form){
        this.form[key] = loginInfo[key]
      }
    }
  }
</script>

<style scoped>

  .body-page-child {
    padding-top: 20px;
    padding-bottom: 30px;
    background-color: white;
  }

</style>
