<template>
  <body-page>
    <div class="body-page-add">
      <el-form class="search-form add-form" ref='form' :rules="rules" :model="submitData" label-width="100px">

        <el-form-item class="search-form-item" label="名称"  prop="name">
          <el-input v-model="submitData.name" placeholder="名称"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="路径"  prop="url">
          <el-input v-model="submitData.url" placeholder="路径"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="所属模块"  prop="module">
          <dict-select v-model="submitData.module" type-code="SYSTEM_MODULE"></dict-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="submit('form')" >确定</el-button>
          <el-button @click="cancel">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </body-page>
</template>

<script>
  import BodyPage from '../../components/BodyPage'
  import DictSelect from '../../components/DictSelect'
  export default {
    name: 'Add',
    components: {DictSelect, BodyPage},
    data(){
      return {
        submitData: {
          name: '',
          module: '',
          url: '',
        },
        rules: {
          name: [
            { required: true, message: '请输入名称', trigger: 'blur' },
          ],
          url: [
            { required: true, message: '请输入路径', trigger: 'blur' },
          ],
          module: [
            { required: true, message: '请选择模块', trigger: 'blur' },
          ]
        }
      }
    },
    methods:{
      submit(formName){
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let vm = this;
            this.$axios.post(vm.$API.api.add,vm.$qs.stringify(vm.submitData)).then(response => {
              if(response.data.code === 2000) {
                vm.$message.success(response.data.message)
                vm.cancel()
              }else{
                vm.$message.error(response.data.message)
              }
            }).catch(response => {
              console.log(response)
              vm.loginResult = "系统异常"
            })
          }
        })
      },
      cancel(){
        this.$router.back()
      }
    }
  }
</script>

<style scoped>

  .body-page-add {
    padding: 20px 10px;
    background-color: white;
  }

  .add-form {
    max-width: 500px;
  }

</style>
