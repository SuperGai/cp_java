<template>
  <div class="login-body">

    <el-form class="login-container" :model="submitform" :rules="rules" ref="form" status-icon label-position="left" label-width="0px">
      <h2 class="login_title">{{$GLOBAL.constant.title}}</h2>

      <el-form-item prop="account">
        <el-input type="text" v-model="submitform.account"
                  auto-complete="off" placeholder="账号" @keyup.enter.native="login('form')">
        </el-input>
      </el-form-item>

      <el-form-item prop="password">
        <el-input type="password" v-model="submitform.password"
                  auto-complete="off" placeholder="密码" @keyup.enter.native="login('form')">
        </el-input>
      </el-form-item>

      <el-form-item prop="verifyCode">
        <el-input style="width: 50%; vertical-align:middle" type="text" v-model="submitform.verifyCode"
                  auto-complete="off" placeholder="验证码" @keyup.enter.native="login('form')">
        </el-input>
        <img style="margin-left: 10px; width: calc(50% - 15px); height:40px; vertical-align:middle;" @click="createUrl" :src="verifyCodeImageSrc" />
      </el-form-item>

      <el-form-item>
        <el-button type="primary" style="width: 100%" @click="login('form')" >登 录</el-button>
      </el-form-item>
    </el-form>

    <!-- 版权声明 -->
    <div class="login-foot">
      <el-link icon="el-icon-trophy" :href="this.$GLOBAL.constant.copyright.gitee" target="_blank">码云</el-link>
      <el-divider direction="vertical"></el-divider>
      <el-link icon="el-icon-notebook-1" :href="this.$GLOBAL.constant.copyright.jianshu" target="_blank">简书</el-link>
      <el-divider direction="vertical"></el-divider>
      <el-tooltip class="item" effect="dark" :content="this.$GLOBAL.constant.copyright.email" placement="bottom">
        <el-link icon="el-icon-message">邮箱</el-link>
      </el-tooltip>
    </div>

  </div>
</template>

<script>
  export default {
    name: 'Login',
    data() {
      return {
        submitform: {
          account: '',
          password: '',
          verifyCode: '',
          keyCode: ''
        },
        verifyCodeImageSrc: '',
        rules: {
          account: [
            { required: true, message: '请输入账号', trigger: 'blur' },
          ],
          password: [
            { required: true, message: '请输入密码', trigger: 'blur' },
          ],
          verifyCode: [
            { required: true, message: '请输入验证码', trigger: 'blur' },
          ]
        }
      }
    },
    created () {
      this.createUrl();
    },
    methods: {
      login(formName) {
        let vm = this;
        this.$refs[formName].validate((valid) => {
          if (valid) {
            vm.$axios.post(vm.$API.others.login, vm.$qs.stringify(vm.submitform)).then(response => {
              if (response.data.code === 2000) {
                localStorage.setItem(vm.$GLOBAL.localStoreKey.permitAPIList, response.data.data)// 接口列表
                vm.$router.replace("/");
              }else if(response.data.code === 4005){// 验证码超时
                vm.createUrl();
                vm.$message.error("验证码超时，请重新输入验证码");
              }else{
                vm.$message.error(response.data.message);
              }
            }).catch(response => {
              console.log(response)
              vm.loginResult = "登录失败,系统异常"
            })
          }
        })
      },
      createUrl(){
        this.submitform.keyCode = new Date().getTime() + '' + Math.floor(Math.random() * 9);
        this.verifyCodeImageSrc = this.$API.others.verifyCode + '/' + this.submitform.keyCode;
      }
    }
  }
</script>

<style scoped>

  body{
    margin: 0px;
    padding: 0;
  }

  .login-body {
    position:fixed;
    left: 0;
    right: 0;
    margin:0 auto;
    top: 10%;
  }

  .login-foot {
    text-align: center;
    color: rgba(0,0,0,.65);
  }

  .login-container {
    border-radius: 15px;
    background-clip: padding-box;
    margin: 90px auto;
    margin-bottom: 12px;
    width: 350px;
    padding: 35px 35px 15px 35px;
    background: #fff;
    border: 1px solid #eaeaea;
    box-shadow: 0 0 25px #cac6c6;
  }

  .login_title {
    margin: 0px auto 40px auto;
    text-align: center;
    color: #1890ff;
    font-family: Avenir,Helvetica Neue,Arial,Helvetica,sans-serif;
  }

</style>
