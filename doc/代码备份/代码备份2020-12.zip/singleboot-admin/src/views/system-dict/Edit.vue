<template>
  <body-page>
    <div class="body-page-edit">
      <el-form  class="search-form edit-form" ref='form' :rules="rules" :model="submitData" label-width="100px">

        <el-form-item class="search-form-item" label="所属字典类型"  prop="typeId">
          <dict-type-select v-model="submitData.typeCode"></dict-type-select>
        </el-form-item>

        <el-form-item class="search-form-item" label="字典名称"  prop="name">
          <el-input v-model="submitData.name" placeholder="字典名称"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="字典值"  prop="value">
          <el-input v-model="submitData.value" placeholder="字典值"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="自定数据"  prop="data">
          <el-input type="text" v-model="submitData.data" placeholder="自定数据"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="描述"  prop="notes">
          <el-input type="text" v-model="submitData.notes" placeholder="描述"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="排序"  prop="sort">
          <el-input-number v-model="submitData.sort" controls-position="right"></el-input-number>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="submit('form')"
                     v-if="btnDisplay.update" >保存修改</el-button>
          <el-button @click="cancel">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </body-page>
</template>

<script>
  import BodyPage from '../../components/BodyPage'
  import DictTypeSelect from '../../components/DictTypeSelect'
  export default {
    name: 'Edit',
    components: {DictTypeSelect, BodyPage},
    data(){
      return {
        // 根据权限控制按钮显示隐藏
        btnDisplay: {
          update: this.$GLOBAL.isUrlPermit(this.$API.dict.update)
        },
        submitData: {
          id: '',
          typeId: '',
          name: '',
          value: '',
          data: '',
          notes: '',
          sort: '',
          typeCode: '',
        },
        rules: {
          typeCode: [
            { required: true, message: '请选择字典类型', trigger: 'blur' },
          ],
          name: [
            { required: true, message: '请输入字典名称', trigger: 'blur' },
          ],
          value: [
            { required: true, message: '请输入字典值', trigger: 'blur' },
          ],
          sort: [
            { required: true, message: '请输入排序', trigger: 'blur' },
          ]
        }
      }
    },
    methods:{
      submit(formName){
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let vm = this;
            this.$axios.post(vm.$API.dict.update,vm.$qs.stringify(vm.submitData)).then(response => {
              if(response.data.code === 2000) {
                vm.$message.success(response.data.message)
                vm.cancel()
              }else{
                vm.$message.error(response.data.message)
              }
            }).catch(response => {
              console.log(response)
              vm.loginResult = "系统异常"
            })
          }
        })
      },
      cancel(){
        this.$router.back()
      }
    },
    created () {
      let vm = this;

      // 获取详情
      this.$axios.post(vm.$API.dict.detail,vm.$qs.stringify({id: vm.$route.query.id})).then(response => {
        if(response.data.code === 2000) {

          for(let key in vm.submitData){
            vm.submitData[key] = response.data.data[key]
          }

        }else{
          vm.$message.error(response.data.message)
          vm.cancel()
        }
      }).catch(response => {
        console.log(response)
        vm.loginResult = "系统异常"
      })

    }
  }
</script>

<style scoped>

  .body-page-edit {
    padding: 20px 10px;
    background-color: white;
  }

  .edit-form {
    max-width: 500px;
  }

</style>
