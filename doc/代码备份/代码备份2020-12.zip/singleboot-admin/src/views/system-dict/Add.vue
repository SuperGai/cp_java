<template>
  <body-page>
    <div class="body-page-add">
      <el-form class="search-form add-form" ref='form' :rules="rules" :model="submitData" label-width="120px">

        <el-form-item class="search-form-item" label="所属字典类型"  prop="typeId">
          <dict-type-select v-model="submitData.typeCode"></dict-type-select>
        </el-form-item>

        <el-form-item class="search-form-item" label="字典名称"  prop="name">
          <el-input v-model="submitData.name" placeholder="字典名称"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="字典值"  prop="value">
          <el-input v-model="submitData.value" placeholder="字典值"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="自定数据"  prop="data">
          <el-input type="text" v-model="submitData.data" placeholder="自定数据"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="描述"  prop="notes">
          <el-input type="text" v-model="submitData.notes" placeholder="描述"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="排序"  prop="sort">
          <el-input-number v-model="submitData.sort" controls-position="right"></el-input-number>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="submit('form')" >确定</el-button>
          <el-button @click="cancel">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </body-page>
</template>

<script>
  import BodyPage from '../../components/BodyPage'
  import DictTypeSelect from '../../components/DictTypeSelect'
  export default {
    name: 'Add',
    components: {DictTypeSelect, BodyPage},
    data(){
      return {
        submitData: {
          typeId: '',
          name: '',
          value: '',
          data: '',
          notes: '',
          sort: '',
          typeCode: '',
        },
        rules: {
          typeCode: [
            { required: true, message: '请选择字典类型', trigger: 'blur' },
          ],
          name: [
            { required: true, message: '请输入字典名称', trigger: 'blur' },
          ],
          value: [
            { required: true, message: '请输入字典值', trigger: 'blur' },
          ],
          sort: [
            { required: true, message: '请输入排序', trigger: 'blur' },
          ]
        }
      }
    },
    methods:{
      submit(formName){
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let vm = this;
            this.$axios.post(vm.$API.dict.add,vm.$qs.stringify(vm.submitData)).then(response => {
              if(response.data.code === 2000) {
                vm.$message.success(response.data.message)
                vm.cancel()
              }else{
                vm.$message.error(response.data.message)
              }
            }).catch(response => {
              console.log(response)
              vm.loginResult = "系统异常"
            })
          }
        })
      },
      cancel(){
        this.$router.back()
      }
    }
  }
</script>

<style scoped>

  .body-page-add {
    padding: 20px 10px;
    background-color: white;
  }

  .add-form {
    max-width: 500px;
  }

</style>
