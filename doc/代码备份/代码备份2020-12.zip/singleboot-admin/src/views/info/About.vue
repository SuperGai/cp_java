<template>
    <h2>这是关于页</h2>
</template>

<script>
  export default {
    name: 'About'
  }
</script>

<style scoped>

</style>
