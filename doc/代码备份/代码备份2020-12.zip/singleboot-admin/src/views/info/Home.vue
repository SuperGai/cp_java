<template>
  <h2>这是首页</h2>
</template>

<script>
  export default {
    name: 'Home',
  }
</script>

<style scoped>

</style>
