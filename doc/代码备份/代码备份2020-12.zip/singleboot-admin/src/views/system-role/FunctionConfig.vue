<template>
  <body-page>
    <div class="body-page-edit">

      <el-tree ref="tree" :data="treeAllData" :default-checked-keys="treeData" node-key="id"
               :default-expand-all="true"
                :props="treeProps"
                show-checkbox
               @check="handleCheckChange">
      </el-tree>

      <div style="margin-top: 20px; margin-left: 20px;">
        <el-button type="primary" @click="submit"
                    v-if="btnDisplay.treeUpdate">保存</el-button>
        <el-button @click="cancel"
                    >取消</el-button>
      </div>

    </div>
  </body-page>
</template>

<script>
  import BodyPage from '../../components/BodyPage'
  import DictSelect from '../../components/DictSelect'
  export default {
    name: 'FunctionConfig',
    components: {DictSelect, BodyPage},
    data(){
      return {
        // 根据权限控制按钮显示隐藏
        btnDisplay: {
          treeUpdate: this.$GLOBAL.isUrlPermit(this.$API.role.treeUpdate)
        },
        treeProps: {
          label: 'name',
          children: 'children'
        },
        treeData: null,
        treeAllData: null,
        funIdList: null,
        roleId: null,
      }
    },
    methods:{
      handleCheckChange(data, allCheckData){
        // console.log(data)
        // console.log(allCheckData)
        this.funIdList = []
        for(let index in allCheckData.checkedKeys){
          if(allCheckData.checkedKeys[index].toString().indexOf('module_') < 0){
            this.funIdList.push(allCheckData.checkedKeys[index])
          }
        }
        // console.log( this.funIdList )
      },
      submit(){
        let vm = this;

        // null说明用户没有进行修改
        if(vm.funIdList == null){
          vm.$message.success("操作成功")
          vm.cancel()
          return
        }

        this.$axios.post(vm.$API.role.treeUpdate,vm.$qs.stringify({
          funIdList: vm.funIdList,
          roleId: vm.roleId,
        }, { indices: false })).then(response => {
          if(response.data.code === 2000) {
            vm.$message.success(response.data.message)
            vm.cancel()
          }else{
            vm.$message.error(response.data.message)
          }
        }).catch(response => {
          console.log(response)
          vm.loginResult = "系统异常"
        })
      },
      cancel(){
        this.$router.back()
      }
    },
    created () {
      let vm = this;

      vm.roleId = vm.$route.query.id

      // 获取接口树
      this.$axios.post(vm.$API.role.apiTree,vm.$qs.stringify({roleId: vm.$route.query.id})).then(response => {
        if(response.data.code === 2000) {
          vm.treeData = response.data.data.treeData
          vm.treeAllData = response.data.data.treeAllData
        }else{
          vm.$message.error(response.data.message)
          vm.cancel()
        }
      }).catch(response => {
        console.log(response)
        vm.loginResult = "系统异常"
      })

    }
  }
</script>

<style scoped>

  .body-page-edit {
    padding: 20px 10px;
    background-color: white;
  }

  .edit-form {
    max-width: 500px;
  }

</style>
