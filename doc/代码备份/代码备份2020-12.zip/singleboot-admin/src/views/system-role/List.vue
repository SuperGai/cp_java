<template>
  <list-page :pager="table.pager">
    <!-- 表头按钮 -->
    <div slot="table-header" v-if="btnDisplay.delete || btnDisplay.add">
      <el-button-group>
        <el-button icon="el-icon-plus" @click="addOne" v-if="btnDisplay.add">新增</el-button>
        <el-button icon="el-icon-delete" @click="batchDelete" v-if="btnDisplay.delete">删除</el-button>
      </el-button-group>
    </div>

    <!-- 表格 表单 -->
    <div slot="table-body">
      <!-- 查询表单 -->
      <el-form :inline="true" size="mini" class="search-form" ref='form'>
        <el-form-item class="search-form-item" label="角色名称" >
          <el-input v-model="searchForm.name" placeholder="角色名称"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="角色备注" >
          <el-input v-model="searchForm.notes" placeholder="角色备注"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button @click="search" >查询</el-button>
        </el-form-item>
      </el-form>
      <!-- 表格 -->
      <el-table :data="table.data" @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="50"></el-table-column>
        <el-table-column type="index" width="50"></el-table-column>

        <el-table-column
          prop="name"
          label="角色名称">
        </el-table-column>

        <el-table-column
          prop="notes"
          label="角色备注">
        </el-table-column>

        <el-table-column
          prop="createTime"
          label="创建时间">
          <template slot-scope="scope">
            {{$DateTimeFormat(scope.row.createTime).format("YYYY-MM-DD HH:mm:ss")}}
          </template>
        </el-table-column>

        <el-table-column label="操作" >
          <template slot-scope="scope">
            <el-link type="primary" @click="rowEdit(scope.row)" :underline="false"
                     v-if="btnDisplay.detail">详情</el-link>
            <el-link type="primary" @click="rowMenu(scope.row)" :underline="false" style="margin-left: 10px;"
                     v-if="btnDisplay.menuTreeUpdate">配置菜单</el-link>
            <el-link type="primary" @click="rowFunctionConfig(scope.row)" :underline="false" style="margin-left: 10px;"
                     v-if="btnDisplay.functionTreeUpdate">配置功能</el-link>
            <el-link type="danger" @click="rowDelete(scope.row)" :underline="false" style="margin-left: 10px;"
                     v-if="btnDisplay.delete">删除</el-link>
          </template>
        </el-table-column>

      </el-table>
    </div>

  </list-page>
</template>

<script>
  import ListPage from "../../components/ListPage";

  export default {
    name: 'SystemRoleList',
    components: {ListPage},
    data(){
      return{
        // 根据权限控制按钮显示隐藏
        btnDisplay: {
          add: this.$GLOBAL.isUrlPermit(this.$API.role.add),
          detail: this.$GLOBAL.isUrlPermit(this.$API.role.detail),
          delete: this.$GLOBAL.isUrlPermit(this.$API.role.delete),
          dealPermit: this.$GLOBAL.isUrlPermit(this.$API.role.dealPermit),
          menuTreeUpdate: this.$GLOBAL.isUrlPermit(this.$API.role.menuTreeUpdate),
          functionTreeUpdate: this.$GLOBAL.isUrlPermit(this.$API.role.treeUpdate)
        },
        // 查询参数
        searchForm: {
          name: '',
          notes: ''
        },
        // 表格数据
        table: {
          data: [],
          pager: {
            current: 1, // 当前页
            size: 10,   // 每页显示条数
            total: 0,  // 总数
            isSizeChangeCurrent: false // 是否由size修改的current值，是的话则不进行接口调用
          },
          selection: []
        }
      }
    },
    methods: {
      addOne(){
        this.$router.push('/system-role/add')
      },
      batchDelete(){
        let vm = this;

        if(!this.table.selection.length){
          vm.$message.error("请选择至少一条记录");
          return false;
        }

        this.$confirm('此操作将删除所选记录, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let ids = [];
          this.table.selection.forEach((e)=>{
            ids.push(e.id);
          });
          vm.$axios.post(vm.$API.role.batchDelete, vm.$qs.stringify({ids: ids}, { indices: false })).then(response => {
            if(response.data.code == 2000) {
              vm.search()
              vm.$message.success(response.data.message)
            }else{
              vm.$message.error(response.data.message)
            }
          }).catch(response => {
            console.log(response)
            vm.loginResult = "系统异常"
          })
        })
      },
      search(){
        let vm = this;
        let query = vm.$qs.stringify(
          Object.assign({}, this.table.pager,this.searchForm)
        )
        vm.$axios.post(vm.$API.role.listPage, query).then(response => {
          if(response.data.code === 2000) {
            vm.table.data = response.data.data.records
            vm.table.pager.size = response.data.data.size
            vm.table.pager.total = response.data.data.total
            vm.table.pager.current = response.data.data.current
          }else{
            vm.$message.error(response.data.message);
          }
        }).catch(response => {
          console.log(response)
          vm.loginResult = "系统异常"
        })
      },
      rowEdit(row){
        this.$router.push({
          path: '/system-role/edit',
          query: {id: row.id}
        })
      },
      rowMenu(row){
        this.$router.push({
          path: '/system-role/menuConfig',
          query: {id: row.id}
        })
      },
      rowFunctionConfig(row){
        this.$router.push({
          path: '/system-role/functionConfig',
          query: {id: row.id}
        })
      },
      rowDelete(row){
        let vm = this;
        this.$confirm('此操作将删除所选记录, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          vm.$axios.post(vm.$API.role.delete, vm.$qs.stringify({id: row.id})).then(response => {
            if(response.data.code === 2000) {
              vm.search()
              vm.$message.success(response.data.message)
            }else{
              vm.$message.error(response.data.message)
            }
          }).catch(response => {
            console.log(response)
            vm.loginResult = "系统异常"
          })
        })
      },
      handleSelectionChange(selection){
        this.table.selection = selection;
      },
    },
    created () {
      this.search();
    },
    watch: {
      // 监听分页数据
      'table.pager.current': {
        handler: function () {
          // 只有用户触发的current改变事件才需要执行后台数据获取逻辑
          if(this.table.pager.isSizeChangeCurrent){
            this.table.pager.isSizeChangeCurrent = false
            return
          }
          // 从后台获取数据
          this.search()
        }
      },
      'table.pager.size': { // pageSize改变，则设置current为1
        handler: function () {
          this.table.pager.current = 1
          this.table.pager.isSizeChangeCurrent = true // 表明不是用户改变的current
          this.search()
          this.table.pager.isSizeChangeCurrent = false
        }
      }
    },
  }
</script>

<style scoped>

</style>
