<template>
  <el-container style="height: 100%;">
    <el-aside width="auto">
      <el-menu class="el-menu-vertical-demo" text-color="#595959"
               :collapse='!showSidebar' :default-active="this.$route.path">
        <!-- logo -->
        <div style="color: #1890ff; height: 40px; text-align: center; ">
          <h1 v-if="showSidebar" style="font-size: 20px;">{{$GLOBAL.constant.title}}</h1>
          <h1 v-if="!showSidebar">{{$GLOBAL.constant.titleMin}}</h1>
        </div>

        <!-- 菜单树 -->
        <template v-for="item in menuList">
          <el-submenu v-if="item.children.length != 0" :key="item.id" :index="item.url">
            <template slot="title" >
              <i :class="item.icon"></i>
              <span slot="title">{{item.name}}</span>
            </template>
            <el-menu-item v-for="child in item.children" :index="child.url" :key="child.id" @click="menuAction(child.url)" style="margin-left: 10px;">
              {{child.name}}
            </el-menu-item>
          </el-submenu>
          <el-menu-item v-if="item.children.length == 0" :index="item.url" :key="item.id" @click="menuAction(item.url)">
            <i :class="item.icon"></i>
            <span slot="title" @click="menuAction(item.id)" >{{item.name}}</span>
          </el-menu-item>
        </template>

      </el-menu>
    </el-aside>
    <el-container>
      <el-header >

        <!-- 菜单树控制按钮 -->
        <span>
          <i :class="showSidebar ? 'el-icon-s-unfold' : 'el-icon-s-fold'" style="font-size: 25px;cursor:pointer;" @click.stop="switchSidebar"></i>
        </span>

        <!-- 右侧 -->
        <div class="header-right">
          <el-dropdown style="margin-left: 5px;">
            <span class="el-dropdown-link">
              <i class="el-icon-user-solid" style="font-size: 20px">
                <span style="font-size: 15px; margin-left: 5px; ">{{loginUser.name}}</span>
              </i>
              <i class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown" style="padding-bottom: 4px;">
              <el-dropdown-item
                @click.native="menuAction('/loginDetail',{userId: loginUser.id})">个人中心</el-dropdown-item>
              <el-dropdown-item
                @click.native="menuAction('/system-user/editPassword',{userId: loginUser.id})">修改密码</el-dropdown-item>
              <el-dropdown-item divided
                @click.native="logout">退出登录</el-dropdown-item>

            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </el-header>
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>
<script>
  export default {
    name: 'index',
    data(){
      return {
        showSidebar: true,// 左侧导航栏显示
        menuList: [],// 菜单列表
        permitAPIList: [],//有权限接口列表
        loginUser: { // 登录用户信息
          id: '',
          name: ''
        },
      }
    },
    methods:{
      logout(){
        localStorage.removeItem(this.$GLOBAL.localStoreKey.menuTree)
        localStorage.removeItem(this.$GLOBAL.localStoreKey.token)
        localStorage.removeItem(this.$GLOBAL.localStoreKey.loginUserInfo)
        this.replaceAction('/login')
      },
      switchSidebar(){
        this.showSidebar = !this.showSidebar;
      },
      menuAction(url,query){
        this.$router.push({path: url, query: query});
      },
      // replace 跳转
      replaceAction(url){
        this.$router.replace({path: url,query:{}})
      }
    },
    created () {
      let vm = this;

      // 登录校验
      let token = localStorage.getItem(this.$GLOBAL.localStoreKey.token);
      if(token == null || token === ''){
        this.$router.replace('/login')
      }

      // 获取登录用户信息
      if(localStorage.getItem(this.$GLOBAL.localStoreKey.loginUserInfo) == null){
        vm.$axios.get(this.$API.others.getLoginInfo).then(response => {
          if(response.data.code == '2000'){
            for(let key in this.loginUser){
              this.loginUser[key] = response.data.data[key]
            }
            localStorage.setItem(vm.$GLOBAL.localStoreKey.loginUserInfo,JSON.stringify(response.data.data))
          }else{
            vm.$router.replace('/login')
          }
        }).catch(error => {
          console.log(error)
        })
      }else{
        let localUserInfo = JSON.parse(localStorage.getItem(this.$GLOBAL.localStoreKey.loginUserInfo))
        for(let key in this.loginUser){
          this.loginUser[key] = localUserInfo[key]
        }
      }

      // 加载菜单树
      if(localStorage.getItem(this.$GLOBAL.localStoreKey.menuTree) == null){
        vm.$axios.get(this.$API.others.menuTree).then(response => {
          if(response.data.code == '2000'){
            vm.menuList = response.data.data;
            localStorage.setItem(vm.$GLOBAL.localStoreKey.menuTree,JSON.stringify(response.data.data))
          }
        }).catch(error => {
          console.log(error)
          vm.$message.error(error)
        })
      }else{
        let localTree = JSON.parse(localStorage.getItem(this.$GLOBAL.localStoreKey.menuTree))
        vm.menuList = localTree
      }

    },
    // 添加背景色 margin:0;padding:0是为了解决vue四周有白边的问题
    beforeRouteEnter(to, from, next) {
      document.querySelector('body').setAttribute('style', 'margin:0;padding:0')
      next()
    },
    // 去除背景色
    beforeRouteLeave(to, from, next) {
      document.querySelector('body').setAttribute('style', '')
      next()
    },
  }
</script>

<style scoped>

  * {
    font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
  }

  .header-right {
    display: inline-block;
    position: absolute;
    right: 50px;
    line-height: 64px;
  }

  .el-menu-vertical-demo:not(.el-menu--collapse) {
    width: 250px;
    min-height: 100%;
  }

  .el-menu-vertical-demo, .el-menu--collapse {
    min-height: 100%;
  }

  .el-header, .el-footer {
    background-color: #FFFFFF;
    color: #333;
    /*text-align: center;*/
    line-height: 70px;
  }

  .el-aside {
    background-color: #D3DCE6;
    color: #333;
    /*text-align: center;*/
    /*line-height: 200px;*/
  }

  .el-main {
    background-color: #F7F8FB;
    color: #333;
    padding-top: 20px;
    padding-left: 20px;
  }

</style>
