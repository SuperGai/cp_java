<template>
  <body-page>
    <div class="body-page-edit">
      <el-form  class="search-form edit-form" ref='form' :rules="rules" :model="submitData" label-width="100px">
        <el-form-item class="search-form-item" label="名称"  prop="name" style="width: 100%">
          <el-input v-model="submitData.name" placeholder="名称"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="路径"  prop="url">
          <el-input v-model="submitData.url" placeholder="路径"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="图标"  prop="icon">
          <el-input v-model="submitData.icon" placeholder="图标"></el-input>
        </el-form-item>

        <el-form-item label="顶层菜单">
          <el-switch v-model="submitData.isFather"></el-switch>
        </el-form-item>

        <el-form-item v-if="!submitData.isFather" class="search-form-item" label="父菜单"  prop="parentId">
          <parent-menu-select v-model="submitData.parentId"></parent-menu-select>
        </el-form-item>

        <el-form-item class="search-form-item" label="排序"  prop="sort">
          <el-input v-model="submitData.sort" placeholder="排序"></el-input>
        </el-form-item>

        <el-form-item class="search-form-item" label="备注"  prop="notes">
          <el-input v-model="submitData.notes" placeholder="备注"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="submit('form')"
                     v-if="btnDisplay.update">保存修改</el-button>
          <el-button @click="cancel">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </body-page>
</template>

<script>
  import BodyPage from '../../components/BodyPage'
  import ParentMenuSelect from '../../components/ParentMenuSelect'
  export default {
    name: 'Edit',
    components: {ParentMenuSelect, BodyPage},
    data(){
      return {
        // 根据权限控制按钮显示隐藏
        btnDisplay: {
          update: this.$GLOBAL.isUrlPermit(this.$API.menu.update)
        },
        submitData: {
          id: '',
          name: '',
          url: '',
          icon: '',
          parentId: '',
          sort: '',
          notes: '',
          isFather: null,// 是否父菜单
        },
        rules: {
          name: [
            { required: true, message: '名称不能为空', trigger: 'blur' },
          ]
        }
      }
    },
    methods:{
      submit(formName){
        let vm = this;

        this.$refs[formName].validate((valid) => {
          if (valid) {

            if(vm.submitData.isFather == true){
              vm.submitData.parentId = 0
            }

            this.$axios.post(vm.$API.menu.update,vm.$qs.stringify(vm.submitData)).then(response => {
              if(response.data.code === 2000) {
                vm.$message.success(response.data.message)
                localStorage.getItem(vm.$GLOBAL.localStoreKey.menuTree)
                vm.cancel()
              }else{
                vm.$message.error(response.data.message)
              }
            }).catch(response => {
              console.log(response)
              vm.loginResult = "系统异常"
            })
          }
        })
      },
      cancel(){
        this.$router.back()
      }
    },
    created () {
      let vm = this;

      // 获取详情
      this.$axios.post(vm.$API.menu.detail,vm.$qs.stringify({id: vm.$route.query.id})).then(response => {
        if(response.data.code === 2000) {

          for(let key in vm.submitData){
            vm.submitData[key] = response.data.data[key]
          }
          vm.submitData['parentId'] = vm.submitData['parentId'].toString()

          if(vm.submitData.parentId == '0'){
            vm.submitData.isFather = true
            vm.submitData.parentId = ''// 防止父id选择器出现0数据
          }else{
            vm.submitData.isFather = false
          }
        }else{
          vm.$message.error(response.data.message)
          vm.cancel()
        }
      }).catch(response => {
        console.log(response)
        vm.loginResult = "系统异常"
      })

    }
  }
</script>

<style scoped>

  .body-page-edit {
    padding: 20px 10px;
    background-color: white;
  }

  .edit-form {
    max-width: 500px;
  }

</style>
