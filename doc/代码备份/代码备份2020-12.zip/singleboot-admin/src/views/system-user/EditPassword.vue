<template>
    <h2>密码修改</h2>
</template>

<script>
  export default {
    name: 'EditPassword'
  }
</script>

<style scoped>

</style>
