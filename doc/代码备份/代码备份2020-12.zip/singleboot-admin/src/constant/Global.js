
import VueContext from '../main'

// 全局
export default {
  // 一些常量
  constant: {
    // 网站标题
    title: 'Single Boot',
    titleMin: 'Boot',
    // 版权信息
    copyright: {
      email: '1802226517@qq.com',
      gitee: 'https://gitee.com/spzmmd',
      jianshu: 'https://www.jianshu.com/u/efb71669e3f4'
    }
  },

  // 时间格式化
  timeFormat: {
    DAY: 'YYYY-MM-DD',
    TIME: 'YYYY-MM-DD HH:mm:ss',
  },

  // 本地缓存key
  localStoreKey : {
    loginUserInfo: 'LOGIN_USER_INFO',
    token: 'AUTH_TOKEN',
    menuTree: 'MENU_TREE',
    permitAPIList: 'permitAPIList'
  },

  /**
   * 检查是否有指定url的权限
   * @param url 待检查url
   * @returns {boolean}
   */
  isUrlPermit: function (url) {
    let vm = this

    /**
     * 检查url集合里是否有指定url
     * @param urlList 登录用户有权限的url集合
     * @returns {boolean}
     */
    let func_checkUrl = function (urlList) {
      if(urlList == null || urlList.length == 0) {
        return false
      }
      for(let index in urlList){
        if(url.indexOf(urlList[index]) >= 0){// 请求url内包含有权限的接口地址
          return true
        }
      }
      return false
    }

    // 获取登录用户有权限的url集合
    if(localStorage.getItem(vm.localStoreKey.permitAPIList) == null){
      VueContext.$axios.get(VueContext.$API.others.permitApis).then(response => {
        if(response.data.code == '2000'){
          localStorage.setItem(vm.localStoreKey.permitAPIList,JSON.stringify(response.data.data))
          return func_checkUrl(response.data.data)
        }
      }).catch(error => {
        console.log(error)
        VueContext.$message.error(error)
      })
    }else{
      // 存储格式： "/xxx/xxx,/aaa/dd/w,r/eww/x"
      let urlList = localStorage.getItem(vm.localStoreKey.permitAPIList).split(",")
      return func_checkUrl(urlList)
    }

    return false;
  },

}
