<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="less">

  html, body, #app {
    height: 100%;
    position: relative;
    overflow: hidden;
  }
</style>
