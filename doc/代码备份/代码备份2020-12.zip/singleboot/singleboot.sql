/*
 Navicat Premium Data Transfer

 Source Server         : 本机
 Source Server Type    : MySQL
 Source Server Version : 50727
 Source Host           : localhost:3306
 Source Schema         : singleboot

 Target Server Type    : MySQL
 Target Server Version : 50727
 File Encoding         : 65001

 Date: 28/07/2020 18:35:54
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for 模板
-- ----------------------------
DROP TABLE IF EXISTS `模板`;
CREATE TABLE `模板`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT NULL COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_dict
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict`;
CREATE TABLE `sys_dict`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT NULL COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '字典名称',
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '字典标识 用于查询',
  `value` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '字典值',
  `data` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL COMMENT '其他数据',
  `sort` bigint(20) NULL DEFAULT NULL COMMENT '字典排序',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统字典表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '图标',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '访问路径',
  `parent_id` bigint(20) NOT NULL DEFAULT 0 COMMENT '父菜单id',
  `sort` bigint(20) NULL DEFAULT NULL COMMENT '排序',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '菜单名称',
  `notes` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统菜单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES (1, 'el-icon-user', '/system-user/list', 2, 1, '用户管理', '系统内置', 1, '2020-07-22 10:14:36', '2020-07-22 17:06:43');
INSERT INTO `sys_menu` VALUES (2, 'el-icon-setting', '', 0, 2, '系统设置', '系统内置', 1, '2020-07-22 10:15:33', '2020-07-22 17:25:50');
INSERT INTO `sys_menu` VALUES (3, 'el-icon-collection', '/system-dict/list', 2, 1, '字典管理', '系统内置', 1, '2020-07-22 10:16:11', '2020-07-22 17:25:44');
INSERT INTO `sys_menu` VALUES (4, 'el-icon-s-home', '/home', 0, 1, '首页', '系统内置', 1, '2020-07-22 17:06:40', '2020-07-22 17:06:40');
INSERT INTO `sys_menu` VALUES (5, 'el-icon-info', '/about', 0, 3, '关于', '系统内置', 1, '2020-07-22 17:08:54', '2020-07-22 17:09:11');

-- ----------------------------
-- Table structure for sys_permission
-- ----------------------------
DROP TABLE IF EXISTS `sys_permission`;
CREATE TABLE `sys_permission`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '权限路径',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '权限名称',
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '权限类型',
  `menu_id` bigint(20) NULL DEFAULT NULL COMMENT '权限所属菜单id，权限类型为菜单权限时有效',
  `valid` tinyint(1) NULL DEFAULT NULL COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统权限表(包含接口和菜单的权限)' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_permission
-- ----------------------------
INSERT INTO `sys_permission` VALUES (1, '', '首页', 'MENU', 4, 1, '2020-07-24 16:31:30', '2020-07-24 16:31:33');

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '角色名称',
  `notes` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '角色备注',
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 18 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统角色表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, '超级管理员', NULL, 1, '2020-07-24 16:28:24', '2020-07-24 16:28:39');
INSERT INTO `sys_role` VALUES (2, 'name1', '1', 1, '2020-07-28 11:30:51', '2020-07-28 11:30:51');
INSERT INTO `sys_role` VALUES (3, 'name2', '2', 1, '2020-07-28 11:30:58', '2020-07-28 11:30:58');
INSERT INTO `sys_role` VALUES (4, 'name3', '3', 1, '2020-07-28 11:31:02', '2020-07-28 11:31:02');
INSERT INTO `sys_role` VALUES (5, 'name4', '4', 1, '2020-07-28 11:31:06', '2020-07-28 11:31:06');
INSERT INTO `sys_role` VALUES (6, 'name5', '5', 1, '2020-07-28 11:31:12', '2020-07-28 11:31:12');
INSERT INTO `sys_role` VALUES (7, 'name6', '6', 1, '2020-07-28 11:31:22', '2020-07-28 11:31:22');
INSERT INTO `sys_role` VALUES (8, '7', '7', 1, '2020-07-28 11:31:25', '2020-07-28 11:31:25');
INSERT INTO `sys_role` VALUES (9, '8', '8', 1, '2020-07-28 11:31:28', '2020-07-28 11:31:28');
INSERT INTO `sys_role` VALUES (10, '9', '9', 1, '2020-07-28 11:31:30', '2020-07-28 11:31:30');
INSERT INTO `sys_role` VALUES (11, '10', '10', 1, '2020-07-28 11:31:33', '2020-07-28 11:31:33');
INSERT INTO `sys_role` VALUES (12, '11', '11', 1, '2020-07-28 11:31:36', '2020-07-28 11:31:36');
INSERT INTO `sys_role` VALUES (13, '12', '12', 1, '2020-07-28 11:31:39', '2020-07-28 11:31:39');
INSERT INTO `sys_role` VALUES (14, '13', '13', 1, '2020-07-28 11:31:42', '2020-07-28 11:31:42');
INSERT INTO `sys_role` VALUES (15, '14', '14', 1, '2020-07-28 11:31:46', '2020-07-28 11:31:46');
INSERT INTO `sys_role` VALUES (16, '15', '15', 1, '2020-07-28 11:31:50', '2020-07-28 11:31:50');
INSERT INTO `sys_role` VALUES (17, '16', '16', 1, '2020-07-28 11:31:54', '2020-07-28 11:31:54');

-- ----------------------------
-- Table structure for sys_role_permission
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_permission`;
CREATE TABLE `sys_role_permission`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` bigint(20) NOT NULL COMMENT '角色id',
  `permission_id` bigint(20) NOT NULL COMMENT '权限id',
  `valid` tinyint(1) NULL DEFAULT NULL,
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统角色与权限对应表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role_permission
-- ----------------------------
INSERT INTO `sys_role_permission` VALUES (1, 1, 1, 1, '2020-07-24 16:32:41', '2020-07-24 16:32:41');

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `id` bigint(20) NOT NULL,
  `valid` tinyint(1) NOT NULL COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '记录创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '记录更新时间',
  `account` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '账号',
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '密码',
  `salt` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '用于加密密码的盐',
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '手机号',
  `status` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '状态',
  `approve_status` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '审核状态',
  `approve_result` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '审核结果',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 1, '2020-07-24 09:11:06', '2020-07-24 10:12:50', 'zhangsan', 'E10ADC3949BA59ABBE56E057F20F883E', 'zcuwe', '13016767656', '1', '2', '2');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT NULL COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `user_id` bigint(20) NOT NULL COMMENT '用户id',
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统用户与角色对应表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES (1, 1, '2020-07-24 16:28:56', '2020-07-24 16:28:56', 1, 1);

SET FOREIGN_KEY_CHECKS = 1;
