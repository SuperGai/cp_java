package com.spz.demo.singleboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.spz.demo.singleboot.bean.SysMenuBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.dao.SysMenuMapper;
import com.spz.demo.singleboot.entity.*;
import com.spz.demo.singleboot.service.SysMenuService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;

@Slf4j
@Service
public class SysMenuServiceImpl extends ServiceImpl<SysMenuMapper, SysMenu> implements SysMenuService {

    private final SysMenuMapper menuMapper;

    public SysMenuServiceImpl(SysMenuMapper menuMapper) {
        this.menuMapper = menuMapper;
    }

    @Override
    public List<SysMenuBean> tree(SysMenuBean bean) {
        if(bean == null || CollectionUtils.isEmpty(bean.getIds())){
            return new ArrayList<>();
        }
        List<SysMenuBean> allMenuList = findList(bean);
        return this.createTree(allMenuList);
    }

    @Override
    public LinkedList<SysMenuBean> createTree(List<SysMenuBean> list){
        if(CollectionUtils.isEmpty(list)) return new LinkedList<>();

        HashMap<Long, SysMenuBean> parentMap = new HashMap<>();// key: id
        HashMap<Long, LinkedList<SysMenuBean>> childrenMap = new HashMap<>();// key: parentId
        for (SysMenuBean item : list) {
            if(item.getParentId() == null || item.getParentId() == 0){
                parentMap.put(item.getId(), item);
            }else{
                if(childrenMap.get(item.getParentId()) == null){
                    childrenMap.put(item.getParentId(), new LinkedList<SysMenuBean>(){{
                        add(item);
                    }});
                }else {
                    childrenMap.get(item.getParentId()).add(item);
                }
            }
        }

        // 将子菜单设置进父菜单实例
        childrenMap.forEach((parentId, children) -> {
            if(parentMap.get(parentId) == null){
                SysMenuBean parentMenuBean = findOne(SysMenuBean.builder().id(parentId).build());
                parentMenuBean.setChildren(children);// 设置子菜单集合
                parentMap.put(parentId, parentMenuBean);
            }else{
                parentMap.get(parentId).setChildren(children);// 设置子菜单集合
            }
        });

        // 排序
        LinkedList<SysMenuBean> restList = new LinkedList<>(parentMap.values());
        Collections.sort(restList);
        restList.forEach(parent -> {
            if(CollectionUtils.isNotEmpty(parent.getChildren())){
                Collections.sort(parent.getChildren());
            }
        });

        return restList;
    }

    @Override
    public List<SysMenuBean> findList(SysMenuBean bean) {
        List<SysMenu> menus = menuMapper.selectList(createWrapper(bean));
        if(CollectionUtils.isEmpty(menus)) return Collections.EMPTY_LIST;

        List<SysMenuBean> beans = new ArrayList<>();
        menus.forEach(v->{
            SysMenuBean sysMenuBean = new SysMenuBean();
            BeanUtils.copyProperties(v,sysMenuBean);
            beans.add(sysMenuBean);
        });
        return beans;
    }

    @Override
    public Page<SysMenuBean> findPage(SysMenuBean bean, PageBean pageBean){
        LambdaQueryWrapper<SysMenu> wrapper = createWrapper(bean);

        // 分页查询
        Page<SysMenu> page = new Page<>(pageBean.getCurrent(),pageBean.getSize());
        page = menuMapper.selectPage(page,wrapper);

        if(CollectionUtils.isEmpty(page.getRecords())) return new Page<>();

        Page<SysMenuBean> beanPage = new Page<>();
        BeanUtils.copyProperties(page,beanPage,"records");
        beanPage.setRecords(new ArrayList<>());
        page.getRecords().forEach(v -> {
            SysMenuBean menuBean = new SysMenuBean();
            BeanUtils.copyProperties(v,menuBean);
            beanPage.getRecords().add(menuBean);
        });
        return beanPage;
    }

    @Transactional
    @Override
    public SysMenuBean add(SysMenuBean bean){
        SysMenu source = new SysMenu();
        BeanUtils.copyProperties(bean,source);

        menuMapper.insert(source);
        BeanUtils.copyProperties(source,bean);
        return bean;
    }

    @Transactional
    @Override
    public RestBean update(SysMenuBean bean) {
        SysMenu source = new SysMenu();
        BeanUtils.copyProperties(bean,source);
        return RestBean.ok(menuMapper.updateById(source));
    }

    @Transactional
    @Override
    public RestBean delete(SysMenuBean bean) {
        SysMenu updateSource = new SysMenu();
        updateSource.setValid(DataValid.INVALID);
        return RestBean.ok(
                menuMapper.update(updateSource, createWrapper(bean))
        );
    }

    @Override
    public SysMenuBean findOne(SysMenuBean bean) {
        List<SysMenu> sourceList = menuMapper.selectList(createWrapper(bean));
        if(CollectionUtils.isEmpty(sourceList)) return null;

        SysMenuBean restBean = new SysMenuBean();
        BeanUtils.copyProperties(sourceList.get(0),restBean);
        return restBean;
    }

    /**
     * 建立查询条件
     * 条件尽量都写在此方法
     * @param bean
     * @return
     */
    private LambdaQueryWrapper createWrapper(SysMenuBean bean){
        LambdaQueryWrapper<SysMenu> wrapper = Wrappers.lambdaQuery();
        if(bean == null || bean.getValid() == null){
            wrapper.eq(SysMenu::getValid,DataValid.VALID);
        }

        // 自定义条件
        if(bean != null) {
            if(bean.getId() != null){
                wrapper.eq(SysMenu::getId,bean.getId());
            }
            if(bean.getValid() != null){
                wrapper.eq(SysMenu::getValid,bean.getValid());
            }

            if(CollectionUtils.isNotEmpty(bean.getIds())){
                wrapper.in(SysMenu::getId,bean.getIds());
            }
            if(bean.getParentId() != null){
                wrapper.eq(SysMenu::getParentId,bean.getParentId());
            }
            if(StringUtils.isNotBlank(bean.getName())){
                wrapper.like(SysMenu::getName,bean.getName());
            }
            if(CollectionUtils.isNotEmpty(bean.getIds())){
                wrapper.in(SysMenu::getId, bean.getIds());
            }
        }

        return wrapper;
    }
}
