package com.spz.demo.singleboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.spz.demo.singleboot.bean.*;
import com.spz.demo.singleboot.constant.DictTypeCodeConstant;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.dao.SysRoleFunctionMapper;
import com.spz.demo.singleboot.entity.SysRoleFunction;
import com.spz.demo.singleboot.entity.SysRoleMenu;
import com.spz.demo.singleboot.service.*;
import com.spz.demo.singleboot.service.SysRoleFunctionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SysRoleFunctionServiceImpl extends ServiceImpl<SysRoleFunctionMapper, SysRoleFunction> implements SysRoleFunctionService {

    private final SysRoleFunctionMapper roleFunctionMapper;
    private final SysFunctionService functionService;
    private final SysRoleService roleService;
    private final SysDictService dictService;

    public SysRoleFunctionServiceImpl(SysRoleFunctionMapper roleFunctionMapper, SysFunctionService functionService, SysRoleService roleService, SysDictService dictService){
        this.roleFunctionMapper = roleFunctionMapper;
        this.functionService = functionService;
        this.roleService = roleService;
        this.dictService = dictService;
    }

    @Transactional
    @Override
    public RestBean treeUpdate(List<Long> funIdList,
                               Long roleId){
        // 删除原来的
        SysRoleFunction delFunApi = new SysRoleFunction();
        delFunApi.setValid(DataValid.INVALID);
        roleFunctionMapper.update(delFunApi, createWrapper(
                SysRoleFunctionBean.builder().roleId(roleId).build())
        );

        // 插入新的
        if(CollectionUtils.isEmpty(funIdList)) return RestBean.ok();
        funIdList.forEach(funId -> {
            SysRoleFunction roleFun = new SysRoleFunction();
            roleFun.setFunctionId(funId);
            roleFun.setRoleId(roleId);
            roleFunctionMapper.insert(roleFun);
        });

        return RestBean.ok();
    }

    @Override
    public HashMap roleFunctionTree(Long roleId){
        List<SysRoleFunctionBean> allRoleFunList = findList(null);

        HashMap<String, HashMap<String, Object>> allList = new HashMap<>();// key: roleId, value
        List<Object> checkedNameList = new ArrayList<>();//被选中的function id
        for (SysRoleFunctionBean roleFun : allRoleFunList) {
            SysFunctionBean fun = functionService.findOne(SysFunctionBean.builder().id(roleFun.getFunctionId()).build());
            if(fun == null) continue;

            // 设置被选中的
            if(roleId == roleFun.getRoleId()){
                checkedNameList.add(fun.getId());
            }
        }

        // 设置全部
        List<SysFunctionBean> allFunBeanList = functionService.findList(null);
        for (SysFunctionBean fun : allFunBeanList) {
            SysDictBean dictBean = dictService.findOne(SysDictBean.builder()
                    .value(fun.getModule()).typeCode(DictTypeCodeConstant.SYSTEM_MODULE).build()
            );
            if(dictBean == null) continue;

            if(CollectionUtils.isEmpty(allList.get("module_" + fun.getModule()))){
                allList.put("module_" + fun.getModule(), new HashMap<String, Object>(){{
                    put("id", "module_" + fun.getModule());
                    put("name", dictBean.getName());
                    put("children", new ArrayList<SysFunctionBean>(){{
                        add(fun);
                    }});
                }});
            }else{
                List tempList = ((List)(allList.get("module_" + fun.getModule()).get("children")));
                if(!tempList.contains(fun)) tempList.add(fun);
            }
        }
        List<HashMap<String, Object>> allRest = new ArrayList<>();
        for(HashMap<String, Object> item : allList.values()){
            allRest.add(item);
        }

        return new HashMap<String, Object>(){{
            put("treeAllData", allRest);
            put("treeData", checkedNameList);
        }};
    }

    @Override
    public List<SysRoleFunctionBean> findList(SysRoleFunctionBean bean){
        List<SysRoleFunction> list = roleFunctionMapper.selectList(createWrapper(bean));
        if(CollectionUtils.isEmpty(list)) return new ArrayList<>();
        List<SysRoleFunctionBean> beanList = list.stream().map(item -> {
            SysRoleFunctionBean restBean = new SysRoleFunctionBean();
            BeanUtils.copyProperties(item, restBean);
            return restBean;
        }).collect(Collectors.toList());
        return beanList;
    }

    @Override
    public List<SysFunctionBean> findFunctionListByRoleFunction(SysRoleFunctionBean bean){
        LambdaQueryWrapper<SysRoleFunction> wrapper = createWrapper(bean);
        List<SysRoleFunction> roleFunctionList = roleFunctionMapper.selectList(wrapper);
        if(CollectionUtils.isEmpty(roleFunctionList)) return Collections.EMPTY_LIST;
        List<Long> funtionIdList = roleFunctionList.stream()
                .filter(v->v.getFunctionId() != null)
                .map(v-> v.getFunctionId()).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(funtionIdList)) return Collections.EMPTY_LIST;
        return functionService.findList(SysFunctionBean.builder()
                .ids(funtionIdList).valid(DataValid.VALID)
                .build());
    }

    @Transactional
    @Override
    public RestBean delete(SysRoleFunctionBean bean) {
        LambdaQueryWrapper<SysRoleFunction> wrapper = createWrapper(bean);

        SysRoleFunction updateSource = new SysRoleFunction();
        updateSource.setValid(DataValid.INVALID);

        return RestBean.ok(
                roleFunctionMapper.update(updateSource, wrapper)
        );
    }

    /**
     * 建立查询条件
     * 条件尽量都写在此方法
     * @param bean
     * @return
     */
    private LambdaQueryWrapper createWrapper(SysRoleFunctionBean bean){
        LambdaQueryWrapper<SysRoleFunction> wrapper = Wrappers.lambdaQuery();
        if(bean == null || bean.getValid() == null){
            wrapper.eq(SysRoleFunction::getValid,DataValid.VALID);
        }

        // 自定义条件
        if(bean != null) {
            if(bean.getValid() != null){
                wrapper.eq(SysRoleFunction::getValid,bean.getValid());
            }
            if(bean.getId() != null){
                wrapper.eq(SysRoleFunction::getId,bean.getId());
            }

            if(bean.getFunctionId() != null){
                wrapper.eq(SysRoleFunction::getFunctionId,bean.getFunctionId());
            }
            if(CollectionUtils.isNotEmpty(bean.getFunctionIdList())){
                wrapper.in(SysRoleFunction::getFunctionId,bean.getFunctionIdList());
            }
            if(bean.getRoleId() != null){
                wrapper.eq(SysRoleFunction::getRoleId,bean.getRoleId());
            }
            if(CollectionUtils.isNotEmpty(bean.getRoleIdList())){
                wrapper.in(SysRoleFunction::getRoleId,bean.getRoleIdList());
            }
        }

        return wrapper;
    }
}
