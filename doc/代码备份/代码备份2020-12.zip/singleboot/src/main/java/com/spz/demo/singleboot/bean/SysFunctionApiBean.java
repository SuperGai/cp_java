package com.spz.demo.singleboot.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;
import java.util.List;

/**
 * 系统功能与接口url对应表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SysFunctionApiBean {

    // 系统功能id
    private Long functionId;

    // 系统接口url id
    private Long apiId;

    // 主键id
    private Long id;

    // 数据是否有效
    private Integer valid;

    // 记录创建时间
    private Date createTime;

    // 记录更新时间
    private Date updateTime;

    // 系统功能id集合
    private List<Long> functionIdList;

    // api接口id集合
    private List<Long> apiIdList;
}
