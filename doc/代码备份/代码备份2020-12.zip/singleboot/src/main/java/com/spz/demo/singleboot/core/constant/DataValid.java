package com.spz.demo.singleboot.core.constant;

/**
 * 数据是否有效
 */
public class DataValid {

    // 数据有效
    public static final Integer VALID = 1 ;

    // 数据无效 如被删除的数据
    public static final Integer INVALID = 0 ;

}
