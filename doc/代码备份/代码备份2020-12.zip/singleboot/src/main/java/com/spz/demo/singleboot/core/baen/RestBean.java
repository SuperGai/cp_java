package com.spz.demo.singleboot.core.baen;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.spz.demo.singleboot.core.constant.RestCode;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

/**
 * 通用控制层返回实体类
 * @see RestCode
 * @author zp
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RestBean {

    // 错误码
    private long code;
    // 错误信息
    private String message;
    // 数据
    private Object data;

    public static RestBean ok(){
        RestBean bean = new RestBean();
        bean.setCode(RestCode.DEFAULT_SUCCESS.getCode());
        bean.setMessage(RestCode.DEFAULT_SUCCESS.getMessage());
        return bean;
    }

    public static RestBean ok(Object data){
        RestBean bean = new RestBean();
        bean.setData(data);
        bean.setCode(RestCode.DEFAULT_SUCCESS.getCode());
        bean.setMessage(RestCode.DEFAULT_SUCCESS.getMessage());
        return bean;
    }

    public static RestBean ok(String msg){
        RestBean bean = new RestBean();
        bean.setCode(RestCode.DEFAULT_SUCCESS.getCode());
        bean.setMessage(msg);
        return bean;
    }

    public static RestBean error(){
        RestBean bean = new RestBean();
        bean.setCode(RestCode.DEFAULT_ERROR.getCode());
        bean.setMessage(RestCode.DEFAULT_ERROR.getMessage());
        return bean;
    }

    public static RestBean error(Object data){
        RestBean bean = new RestBean();
        bean.setData(data);
        bean.setCode(RestCode.DEFAULT_ERROR.getCode());
        bean.setMessage(RestCode.DEFAULT_ERROR.getMessage());
        return bean;
    }

    public static RestBean error(String msg){
        RestBean bean = new RestBean();
        bean.setCode(RestCode.DEFAULT_ERROR.getCode());
        bean.setMessage(msg);
        return bean;
    }

    public static RestBean error(RestCode code,String msg){
        RestBean bean = new RestBean();
        bean.setCode(code.getCode());
        bean.setMessage(msg);
        return bean;
    }

    public static RestBean error(RestCode code){
        RestBean bean = new RestBean();
        bean.setCode(code.getCode());
        bean.setMessage(code.getMessage());
        return bean;
    }
}