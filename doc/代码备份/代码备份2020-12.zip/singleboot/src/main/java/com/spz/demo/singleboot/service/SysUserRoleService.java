package com.spz.demo.singleboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.spz.demo.singleboot.bean.SysRoleBean;
import com.spz.demo.singleboot.bean.SysUserBean;
import com.spz.demo.singleboot.bean.SysUserRoleBean;
import com.spz.demo.singleboot.entity.SysRole;
import com.spz.demo.singleboot.entity.SysUserRole;

import java.util.List;

public interface SysUserRoleService extends IService<SysUserRole> {

    /**
     * 查询列表
     * @param bean
     * @return
     */
    List<SysUserRoleBean> findAll(SysUserRoleBean bean);

    /**
     * 查询记录数量
     * @param bean
     * @return
     */
    Integer count(SysUserRoleBean bean);
}
