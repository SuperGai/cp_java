package com.spz.demo.singleboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.spz.demo.singleboot.bean.SysApiBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.entity.SysApi;
import java.util.List;

public interface SysApiService extends IService<SysApi> {

    /**
     * 根据id获取列表
     * @param ids
     * @return
     */
    List<SysApiBean> findByIds(List<Long> ids);

    /**
     * 查询列表
     * @param bean
     * @return
     */
    List<SysApiBean> findList(SysApiBean bean);

    /**
     * 分页查询
     * @param bean
     * @param pageBean
     * @return
     */
    Page<SysApiBean> findPage(SysApiBean bean, PageBean pageBean);

    /**
     * 添加一条记录
     * @param bean
     * @return
     */
    SysApiBean add(SysApiBean bean);

    /**
     * 根据id更新一条记录
     * @param bean
     * @return
     */
    RestBean update(SysApiBean bean);

    /**
     * 删除多条记录
     * @param bean
     * @return
     */
    RestBean delete(SysApiBean bean);

    /**
     * 详情
     * @param bean
     * @return
     */
    SysApiBean findOne(SysApiBean bean);
}
