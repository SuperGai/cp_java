package com.spz.demo.singleboot.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;
import java.util.List;

/**
 * 系统字典表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SysDictBean {

    // 主键id
    private Long id;

    // 数据是否有效
    private Integer valid;

    // 记录创建时间
    private Date createTime;

    // 记录更新时间
    private Date updateTime;

    // 字典类型id
    private Long typeId;

    // 名称
    private String name;

    // 字典值
    private String value;

    // 自定数据
    private String data;

    // 字典描述
    private String notes;

    // 排序
    private Long sort;

    // 字典类型名称
    private String typeName;

    // 字典类型标识符
    private String typeCode;

    // id集合
    private List<Long> ids;

    // 字典类型id集合
    private List<Long> typeIdList;
}
