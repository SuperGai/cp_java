package com.spz.demo.singleboot.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.spz.demo.singleboot.core.entity.BasicEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 系统菜单表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("sys_menu")
public class SysMenu extends BasicEntity {

    // 菜单图标
    private String icon;

    // 访问路径
    private String url;

    // 父菜单id
    private Long parentId;

    // 排序
    private Long sort;

    // 菜单名称
    private String name;

    // 菜单备注
    private String notes;

}
