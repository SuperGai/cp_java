package com.spz.demo.singleboot.constant;

/**
 * 用户审核结果
 */
public class ApproveResults {

    //等待审核
    public static final String WAIT = "1";

    //已通过
    public static final String PASS = "2";

    //未通过
    public static final String UNPASS = "3";

}
