package com.spz.demo.singleboot.constant;

/**
 * 系统角色与菜单和权限对应表 常量
 */
public class SysRoleMenuPermissionConstant {

    // 权限类型 接口权限
    public static final String TYPE_API = "API";

    // 权限类型 菜单权限
    public static final String TYPE_MENU = "MENU";

}
