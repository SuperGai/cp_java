package com.spz.demo.singleboot.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.spz.demo.singleboot.core.entity.BasicEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 系统用户表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("sys_user")
public class SysUser extends BasicEntity {

    // 账号 唯一
    private String account;

    // 密码
    private String password;

    // 昵称
    private String name;

    // 用于加密密码的盐
    private String salt;

    // 手机号
    private String phone;

    // 状态
    private String status;

    // 审核状态
    private String approveStatus;

    // 审核结果
    private String approveResult;

}
