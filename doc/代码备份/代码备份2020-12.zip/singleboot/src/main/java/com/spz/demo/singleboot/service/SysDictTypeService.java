package com.spz.demo.singleboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.spz.demo.singleboot.bean.SysDictTypeBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.entity.SysDictType;

import java.util.List;

public interface SysDictTypeService extends IService<SysDictType> {

    /**
     * 根据id获取列表
     * @param ids
     * @return
     */
    List<SysDictTypeBean> findByIds(List<Long> ids);

    /**
     * 查询列表
     * @param bean
     * @return
     */
    List<SysDictTypeBean> findList(SysDictTypeBean bean);

    /**
     * 分页查询
     * @param bean
     * @param pageBean
     * @return
     */
    Page<SysDictTypeBean> findPage(SysDictTypeBean bean, PageBean pageBean);

    /**
     * 添加一条记录
     * @param bean
     * @return
     */
    RestBean add(SysDictTypeBean bean);

    /**
     * 根据id更新一条记录
     * @param bean
     * @return
     */
    RestBean update(SysDictTypeBean bean);

    /**
     * 删除多条记录
     * @param bean
     * @return
     */
    RestBean delete(SysDictTypeBean bean);

    /**
     * 详情
     * @param bean
     * @return
     */
    SysDictTypeBean findOne(SysDictTypeBean bean);
}
