package com.spz.demo.singleboot.controller.system;

import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.entity.SysRoleFunction;
import com.spz.demo.singleboot.service.SysFunctionApiService;
import com.spz.demo.singleboot.service.SysRoleFunctionService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 系统角色功能对应 控制器
 */
@RestController
@RequestMapping("/sys/role/function")
public class SysRoleFunctionController {

    private final SysRoleFunctionService roleFunctionService;

    public SysRoleFunctionController(SysRoleFunctionService roleFunctionService) {
        this.roleFunctionService = roleFunctionService;
    }

    /**
     * 角色功能树
     * @param roleId
     * @return
     */
    @RequestMapping("/tree")
    public RestBean tree(Long roleId){
        return RestBean.ok(
                roleFunctionService.roleFunctionTree(roleId)
        );
    }

    /**
     * 更新角色功能树
     * @param funIdList
     * @param roleId
     * @return
     */
    @RequestMapping("/tree/update")
    public RestBean treeUpdate(@RequestParam(value = "funIdList", required = false) List<Long> funIdList,
                               Long roleId){
        if(roleId == null) return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        return roleFunctionService.treeUpdate(funIdList, roleId);
    }

}
