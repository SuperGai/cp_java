package com.spz.demo.singleboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.spz.demo.singleboot.bean.SysFunctionBean;
import com.spz.demo.singleboot.bean.SysRoleBean;
import com.spz.demo.singleboot.bean.SysUserBean;
import com.spz.demo.singleboot.bean.SysUserRoleBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.dao.SysRoleMapper;
import com.spz.demo.singleboot.entity.SysRole;
import com.spz.demo.singleboot.entity.SysRoleMenu;
import com.spz.demo.singleboot.service.SysRoleService;
import com.spz.demo.singleboot.service.SysUserRoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SysRoleServiceImpl extends ServiceImpl<SysRoleMapper, SysRole> implements SysRoleService {

    private final SysRoleMapper roleMapper;
    private final SysUserRoleService userRoleService;

    public SysRoleServiceImpl(SysRoleMapper roleMapper, SysUserRoleService userRoleService) {
        this.roleMapper = roleMapper;
        this.userRoleService = userRoleService;
    }

    @Override
    public List<SysRoleBean> findByUser(SysUserBean bean) {
        List<SysUserRoleBean> sysUserRoleBeanList = userRoleService.findAll(SysUserRoleBean.builder()
                .userId(bean.getId()).valid(DataValid.VALID)
                .build());

        List<Long> roleIds = new ArrayList<>();
        sysUserRoleBeanList.forEach(v -> roleIds.add(v.getRoleId()));

        List<SysRoleBean> roleList = this.findByIds(roleIds);
        return roleList;
    }

    @Override
    public List<SysRoleBean> findByIds(List<Long> roleIds){
        if(CollectionUtils.isEmpty(roleIds)) return Collections.EMPTY_LIST;

        LambdaQueryWrapper<SysRole> wrapper = createWrapper(null);
        wrapper.in(SysRole::getId,roleIds);
        List<SysRole> roles = roleMapper.selectList(wrapper);

        List<SysRoleBean> roleBeans = new ArrayList<>();
        roles.forEach(v->{
            SysRoleBean item = new SysRoleBean();
            BeanUtils.copyProperties(v,item);
            roleBeans.add(item);
        });
        return roleBeans;
    }

    @Override
    public Page<SysRoleBean> findPage(SysRoleBean bean, PageBean pageBean){
        LambdaQueryWrapper<SysRole> wrapper = createWrapper(bean);

        // 分页查询
        Page<SysRole> page = new Page<>(pageBean.getCurrent(),pageBean.getSize());
        page = roleMapper.selectPage(page,wrapper);

        if(CollectionUtils.isEmpty(page.getRecords())) return new Page<>();

        Page<SysRoleBean> restPage = new Page<>();
        BeanUtils.copyProperties(page,restPage,"records");
        restPage.setRecords(new ArrayList<>());
        page.getRecords().forEach(v->{
            SysRoleBean itemBean = new SysRoleBean();
            BeanUtils.copyProperties(v, itemBean);
            restPage.getRecords().add(itemBean);
        });
        return restPage;
    }

    @Transactional
    @Override
    public SysRoleBean add(SysRoleBean bean){
        SysRole sysRole = new SysRole();
        BeanUtils.copyProperties(bean,sysRole);

        roleMapper.insert(sysRole);
        BeanUtils.copyProperties(sysRole,bean);
        return bean;
    }

    @Transactional
    @Override
    public RestBean update(SysRoleBean bean) {
        SysRole source = new SysRole();
        BeanUtils.copyProperties(bean,source);
        return RestBean.ok(roleMapper.updateById(source));
    }

    @Transactional
    @Override
    public RestBean delete(SysRoleBean bean){
        // 待删除记录
        List<SysRole> oldRoleList = roleMapper.selectList(createWrapper(bean));
        if(CollectionUtils.isEmpty(oldRoleList)) return RestBean.ok();
        List<Long> roleIdList = oldRoleList.stream().map(v->{return v.getId();}).collect(Collectors.toList());

        // 检查角色名下是否有未删除的用户
        Integer iCount = userRoleService.count(SysUserRoleBean.builder()
                .roleIdList(roleIdList)
                .build());
        if(iCount > 0){
            return RestBean.error("该角色名下存在用户，不可删除");
        }

        // 软删除
        SysRole updateSource = new SysRole();
        updateSource.setValid(DataValid.INVALID);
        return RestBean.ok(
                roleMapper.update(updateSource, createWrapper(SysRoleBean.builder().ids(roleIdList).build()))
        );
    }

    @Override
    public SysRoleBean findOne(SysRoleBean bean) {
        LambdaQueryWrapper<SysRole> wrapper = createWrapper(bean);

        SysRole role = roleMapper.selectOne(wrapper);
        if(role == null) return null;

        SysRoleBean restBean = new SysRoleBean();
        BeanUtils.copyProperties(role,restBean);
        return restBean;
    }

    /**
     * 建立查询条件
     * 条件尽量都写在此方法
     * @param bean
     * @return
     */
    private LambdaQueryWrapper createWrapper(SysRoleBean bean){
        LambdaQueryWrapper<SysRole> wrapper = Wrappers.lambdaQuery();
        if(bean == null || bean.getValid() == null){
            wrapper.eq(SysRole::getValid,DataValid.VALID);
        }

        // 自定义条件
        if(bean != null) {
            if(bean.getValid() != null){
                wrapper.eq(SysRole::getValid,bean.getValid());
            }
            if(bean.getId() != null){
                wrapper.eq(SysRole::getId,bean.getId());
            }

            if(StringUtils.isNotBlank(bean.getName())){
                wrapper.like(SysRole::getName,bean.getName());
            }
            if(StringUtils.isNotBlank(bean.getNotes())){
                wrapper.like(SysRole::getNotes,bean.getNotes());
            }
        }

        return wrapper;
    }
}
