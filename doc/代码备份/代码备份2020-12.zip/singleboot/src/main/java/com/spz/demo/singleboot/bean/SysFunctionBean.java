package com.spz.demo.singleboot.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;
import java.util.List;

/**
 * 系统功能表
 * 角色对一些功能有权限，每个功能内包含若干url接口资源
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SysFunctionBean {

    // 名称
    private String name;

    // 所属模块 从字典表取值
    private String module;

    // 主键id
    private Long id;

    // 数据是否有效
    private Integer valid;

    // 记录创建时间
    private Date createTime;

    // 记录更新时间
    private Date updateTime;

    // id 集合
    private List<Long> ids;

    // 所属模块描述
    private String moduleDesc;
}
