package com.spz.demo.singleboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.spz.demo.singleboot.bean.SysMenuBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.entity.SysMenu;

import java.util.LinkedList;
import java.util.List;

public interface SysMenuService extends IService<SysMenu> {

    /**
     * 获取菜单树
     * @param bean
     * @return
     */
    List<SysMenuBean> tree(SysMenuBean bean);

    /**
     * 构造菜单树
     * @param list
     * @return
     */
    LinkedList<SysMenuBean> createTree(List<SysMenuBean> list);

    /**
     * 列表查询
     * @param bean
     * @return
     */
    List<SysMenuBean> findList(SysMenuBean bean);

    /**
     * 分页查询
     * @param bean
     * @param pageBean
     * @return
     */
    Page<SysMenuBean> findPage(SysMenuBean bean, PageBean pageBean);

    /**
     * 添加一条记录
     * @param bean
     * @return
     */
    SysMenuBean add(SysMenuBean bean);

    /**
     * 更新一条记录
     * @param bean
     * @return
     */
    RestBean update(SysMenuBean bean);

    /**
     * 删除多条记录
     * @param bean
     * @return
     */
    RestBean delete(SysMenuBean bean);

    /**
     * 查询一条记录
     * @param bean
     * @return
     */
    SysMenuBean findOne(SysMenuBean bean);
}
