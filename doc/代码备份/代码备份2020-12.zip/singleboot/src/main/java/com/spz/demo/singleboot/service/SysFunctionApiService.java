package com.spz.demo.singleboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.spz.demo.singleboot.bean.SysApiBean;
import com.spz.demo.singleboot.bean.SysFunctionApiBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.entity.SysFunctionApi;

import java.util.HashMap;
import java.util.List;

public interface SysFunctionApiService extends IService<SysFunctionApi> {

    /**
     * 更新功能接口树
     * @param apiIdList
     * @param functionId
     * @return
     */
    RestBean treeUpdate(List<Long> apiIdList,
                        Long functionId);

    /**
     * 获取功能接口树
     * @param functionId
     * @return
     */
    HashMap treeFunctionApi(Long functionId);

    /**
     * 获取API列表
     * @param bean
     * @return
     */
    List<SysApiBean> findApiListByFunctionApi(SysFunctionApiBean bean);

    /**
     * 列表查询
     * @param bean
     * @return
     */
    List<SysFunctionApiBean> findList(SysFunctionApiBean bean);

    /**
     * 删除多条记录
     * @param bean
     * @return
     */
    RestBean delete(SysFunctionApiBean bean);
}
