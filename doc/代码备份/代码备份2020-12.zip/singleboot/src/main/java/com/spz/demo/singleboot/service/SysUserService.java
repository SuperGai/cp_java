package com.spz.demo.singleboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.spz.demo.singleboot.bean.SysApiBean;
import com.spz.demo.singleboot.bean.SysMenuBean;
import com.spz.demo.singleboot.bean.SysUserBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.entity.SysUser;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface SysUserService extends IService<SysUser> {

    /**
     * 查询用户拥有权限的菜单树
     * @param bean
     * @return
     */
    List<SysMenuBean> findMenuTreeByUser(SysUserBean bean);

    /**
     * 查询用户所拥有的所有有权限api接口集合
     * @param bean
     * @return
     */
    List<SysApiBean> findPermitUrlsByUser(SysUserBean bean);

    /**
     * 更新登录用户信息
     * 可修改密码
     * @param bean
     * @return
     */
    SysUserBean loginUpdateInfo(SysUserBean bean);

    /**
     * 根据用户信息获取用户
     * @param bean
     * @return
     */
    SysUserBean findOne(SysUserBean bean);

    /**
     * 查询列表
     * @param bean
     * @return
     */
    RestBean findList(SysUserBean bean);

    /**
     * 分页查询
     * @param bean
     * @return
     */
    Page<SysUserBean> findPage(SysUserBean bean, PageBean pageBean);

    /**
     * 添加记录
     * @param bean
     * @return
     */
    RestBean add(SysUserBean bean);

    /**
     * 根据id更新记录
     * @param bean
     * @return
     */
    RestBean updateById(SysUserBean bean);

    /**
     * 根据id删除记录
     * 软删除
     * @param bean
     * @return
     */
    RestBean delete(SysUserBean bean);

}
