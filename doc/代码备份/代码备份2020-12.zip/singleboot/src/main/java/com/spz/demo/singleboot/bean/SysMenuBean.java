package com.spz.demo.singleboot.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * 系统菜单表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SysMenuBean implements Comparable<SysMenuBean>{

    // 菜单图标
    private String icon;

    // 访问路径
    private String url;

    // 父菜单id
    private Long parentId;

    // 排序
    private Long sort;

    // 菜单名称
    private String name;

    // 菜单备注
    private String notes;

    // 主键id
    private Long id;

    // 数据是否有效
    private Integer valid;

    // 记录创建时间
    private Date createTime;

    // 记录更新时间
    private Date updateTime;

    // 子菜单
    @Builder.Default
    private List<SysMenuBean> children = new LinkedList<>();

    // 父菜单名称
    private String parentName;

    // id集合
    private List<Long> ids;

    @Override
    public int compareTo(SysMenuBean o) {
        Long me = (this.sort == null) ? 0 : this.sort;
        Long him = (o.getSort() == null) ? 0 : o.getSort();
        return new Long(me - him).intValue();
    }
}
