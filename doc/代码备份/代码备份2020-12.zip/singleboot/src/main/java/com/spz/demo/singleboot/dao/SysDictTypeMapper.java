package com.spz.demo.singleboot.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.spz.demo.singleboot.entity.SysDict;
import com.spz.demo.singleboot.entity.SysDictType;
import org.springframework.stereotype.Repository;

@Repository
public interface SysDictTypeMapper extends BaseMapper<SysDictType> {
}
