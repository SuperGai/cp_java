package com.spz.demo.singleboot.controller;

import com.alibaba.fastjson.JSONArray;
import com.spz.demo.singleboot.bean.SysMenuBean;
import com.spz.demo.singleboot.bean.SysUserBean;
import com.spz.demo.singleboot.core.annotation.NoPermission;
import com.spz.demo.singleboot.core.baen.JwtTokenBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.cache.EhcacheService;
import com.spz.demo.singleboot.core.constant.CacheConstant;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.core.constant.AuthConstant;
import com.spz.demo.singleboot.core.controller.BasicController;
import com.spz.demo.singleboot.core.jwt.JwtService;
import com.spz.demo.singleboot.core.utils.StrUtils;
import com.spz.demo.singleboot.service.SysUserService;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 身份验证相关接口
 */
@Slf4j
@RestController
@RequestMapping("/auth")
public class AuthController extends BasicController {

    //token有效时间（毫秒）
    private Long period;

    //jwt token 签发人
    private String issuer;

    private final JwtService jwtService;
    private final EhcacheService ehcacheService;
    private final SysUserService userService;

    public AuthController(JwtService jwtService, EhcacheService ehcacheService,
                          SysUserService userService, SysUserService sysUserService){
        super(jwtService, sysUserService);
        this.jwtService = jwtService;
        this.ehcacheService = ehcacheService;
        this.userService = userService;
    }

    @Value("${jwt.period}")
    public void setPeriod(Long period){
        this.period = period;
    }

    @Value(("${jwt.issuer}"))
    public void setIssuer(String issuer){
        this.issuer = issuer;
    }

    /**
     * 用户登录
     * @return
     */
    @PostMapping("/login")
    @NoPermission(noLogin = true)
    public RestBean login(SysUserBean bean, HttpServletResponse response) {
        // key
        String verifyCodeKey = ehcacheService.getAppName() + CacheConstant.IMAGE_CODE + bean.getKeyCode();
        log.debug("获取验证码缓存key：" + verifyCodeKey + "    请求验证码: " + bean.getVerifyCode());

        // 验证码
        String redisVCode = ehcacheService.get(verifyCodeKey);
        if(redisVCode == null){
            return RestBean.error(RestCode.EXPIRE_VCODE);// 需要重新刷新验证码
        }
        if(!redisVCode.equalsIgnoreCase(bean.getVerifyCode())){
            return RestBean.error("验证码错误");
        }

        // 校验账号密码
        bean.setPassword(StrUtils.md5(bean.getPassword()));
        SysUserBean loginUser = userService.findOne(bean);
        if(loginUser == null) return RestBean.error(RestCode.ACCOUNT_PASS_ERROR);

        // 登录成功后，获取userid，查询该用户拥有权限的接口url集合
        List<String> permissionApiList = userService.findPermitUrlsByUser(SysUserBean.builder()
                .id(loginUser.getId()).valid(DataValid.VALID)
                .build())
                .stream().map(v->v.getUrl()).collect(Collectors.toList());

        // 制作JWT Token
        String jwtToken = jwtService.issueJWT(
                StrUtils.getRandomString(20),//令牌id
                loginUser.getId().toString(),//用户id
                (issuer == null ? jwtService.DEFAULT_ISSUER : issuer),//签发人
                null,//访问角色
                JSONArray.toJSONString(permissionApiList),//用户权限集合，json格式 Auth拦截器需要此数据来校验请求是否有权限
                (period == null ? jwtService.DEFAULT_PERIOD : period),//token有效时间
                SignatureAlgorithm.HS512
        );

        //token存入 response里的Header
        response.setHeader(AuthConstant.TOKEN, JwtTokenBean.JWT_TOKEN_PREFIX + jwtToken);// jwt规定token需要加前缀
        response.setHeader("Access-Control-Expose-Headers", AuthConstant.TOKEN);// 让前端能读取token头

        // 删除验证码存储
        ehcacheService.delete(verifyCodeKey);

        return RestBean.ok(permissionApiList);
    }

    /**
     * 获取登录用户信息
     * @param request
     * @return
     */
    @NoPermission
    @GetMapping(value = "/login/info")
    public RestBean loginInfo(HttpServletRequest request){
        // 获取登录信息
        SysUserBean loginUser = getLoginUser(request.getHeader(AuthConstant.TOKEN));
        if(loginUser == null) return RestBean.error(RestCode.EXPIRE_TOKEN);

        loginUser.setPassword("");
        return RestBean.ok(loginUser);
    }

    /**
     * 获取登录用户可显示的菜单树
     * @param request
     * @return
     */
    @NoPermission
    @GetMapping("/menu/tree")
    public RestBean menuTree(HttpServletRequest request){
        // 获取登录信息
        SysUserBean loginUser = getLoginUser(request.getHeader(AuthConstant.TOKEN));
        if(loginUser == null) return RestBean.error(RestCode.EXPIRE_TOKEN);

        // 获取菜单权限数据
        List<SysMenuBean> tree = userService.findMenuTreeByUser(loginUser);

        return RestBean.ok(tree);
    }

    /**
     * 获取登录用户所拥有权限的接口集合
     * @param request
     * @return
     */
    @NoPermission
    @GetMapping("/permit/apis")
    public RestBean permitApis(HttpServletRequest request){

        // 获取登录信息
        SysUserBean loginUser = getLoginUser(request.getHeader(AuthConstant.TOKEN));
        if(loginUser == null) return RestBean.error(RestCode.EXPIRE_TOKEN);

        List<String> permissionApiList = userService.findPermitUrlsByUser(SysUserBean.builder()
                .id(loginUser.getId()).valid(DataValid.VALID)
                .build())
                .stream().map(v->v.getUrl()).collect(Collectors.toList());

        return RestBean.ok(permissionApiList);
    }

    /**
     * 更新登录用户的信息
     * 可修改密码
     * @return
     */
    @NoPermission
    @PostMapping(value = "/login/update")
    public RestBean loginUpdateInfo(SysUserBean userBean){
        if(userBean == null || userBean.getId() == null) return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        return RestBean.ok(
                userService.loginUpdateInfo(userBean)
        );
    }
}
