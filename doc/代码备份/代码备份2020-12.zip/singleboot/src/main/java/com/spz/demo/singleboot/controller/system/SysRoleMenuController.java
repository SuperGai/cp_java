package com.spz.demo.singleboot.controller.system;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.spz.demo.singleboot.bean.SysMenuBean;
import com.spz.demo.singleboot.bean.SysRoleBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.service.SysRoleMenuService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 角色菜单对应
 */
@RestController
@RequestMapping("/sys/role/menu")
public class SysRoleMenuController {

    private final SysRoleMenuService roleMenuService;

    public SysRoleMenuController(SysRoleMenuService roleMenuService) {
        this.roleMenuService = roleMenuService;
    }

    /**
     * 获取菜单树
     *
     * @return
     */
    @GetMapping("/tree")
    public RestBean menuTree(Long roleId) {
        return RestBean.ok(
                roleMenuService.findMenuTreeByRole(roleId)
        );
    }

    /**
     * 更新角色菜单树
     * @param menuIdList
     * @param roleId
     * @return
     */
    @RequestMapping("/tree/update")
    public RestBean treeUpdate(@RequestParam(value = "menuIdList", required = false) List<Long> menuIdList,
                               Long roleId){
        if(roleId == null) return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        return roleMenuService.roleMenuTreeUpdate(menuIdList, roleId);
    }
}
