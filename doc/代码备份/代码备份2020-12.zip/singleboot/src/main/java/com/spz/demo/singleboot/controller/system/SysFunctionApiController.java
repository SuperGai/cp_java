package com.spz.demo.singleboot.controller.system;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.spz.demo.singleboot.bean.SysApiBean;
import com.spz.demo.singleboot.bean.SysFunctionBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.entity.SysFunctionApi;
import com.spz.demo.singleboot.service.SysFunctionApiService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * 系统功能接口 控制器
 */
@RestController
@RequestMapping("/sys/function/api")
public class SysFunctionApiController {

    private final SysFunctionApiService functionApiService;

    public SysFunctionApiController(SysFunctionApiService functionApiService) {
        this.functionApiService = functionApiService;
    }

    /**
     * 查询指定功能的API接口列表树
     * @param functionId
     * @return
     */
    @RequestMapping("/tree")
    public RestBean tree(Long functionId){
        return RestBean.ok(
                functionApiService.treeFunctionApi(functionId)
        );
    }

    /**
     * 更新功能API树
     * @param apiIdList
     * @param functionId
     * @return
     */
    @RequestMapping("/tree/update")
    public RestBean treeUpdate(@RequestParam(value = "apiIdList", required = false) List<Long> apiIdList,
                               Long functionId){
        if(functionId == null) return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        return functionApiService.treeUpdate(apiIdList, functionId);
    }
}
