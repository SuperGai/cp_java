package com.spz.demo.singleboot.core.constant;

/**
 * Auth 请求常量
 */
public class AuthConstant {

    // 用于token，存储在header
    public static final String TOKEN = "Authorization";

    // 用于刷新token，存储在header
    public static final String REFLUSH_TOKEN = "reflushToken";

}
