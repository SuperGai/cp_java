package com.spz.demo.singleboot.controller.system;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.spz.demo.singleboot.bean.SysRoleBean;
import com.spz.demo.singleboot.bean.SysRoleFunctionBean;
import com.spz.demo.singleboot.bean.SysRoleMenuBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.entity.SysRoleFunction;
import com.spz.demo.singleboot.service.SysRoleFunctionService;
import com.spz.demo.singleboot.service.SysRoleMenuService;
import com.spz.demo.singleboot.service.SysRoleService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sys/role")
public class SysRoleController {

    private final SysRoleService sysRoleService;
    private final SysRoleMenuService roleMenuService;
    private final SysRoleFunctionService roleFunctionService;

    public SysRoleController(SysRoleService sysRoleService, SysRoleMenuService roleMenuService, SysRoleFunctionService roleFunctionService) {
        this.sysRoleService = sysRoleService;
        this.roleMenuService = roleMenuService;
        this.roleFunctionService = roleFunctionService;
    }

    /**
     * 分页查询
     * @param bean
     * @return
     */
    @RequestMapping("/listPage")
    public RestBean listPage(SysRoleBean bean, PageBean pageBean){
        return RestBean.ok(sysRoleService.findPage(bean,pageBean));
    }

    /**
     * 角色详情
     * @param bean
     * @return
     */
    @RequestMapping("/detail")
    public RestBean detail(SysRoleBean bean){
        return RestBean.ok(sysRoleService.findOne(bean));
    }

    /**
     * 新增一条记录
     * @param bean
     * @return
     */
    @RequestMapping("/add")
    public RestBean add(SysRoleBean bean){
        return RestBean.ok(sysRoleService.add(bean));
    }

    /**
     * 根据id更新一条记录
     * @param bean
     * @return
     */
    @RequestMapping("/update")
    public RestBean update(SysRoleBean bean){
        if(bean == null || bean.getId() == null) return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        return RestBean.ok(sysRoleService.update(bean));
    }

    /**
     * 根据id删除记录
     * @param bean 可传入id集合
     * @return
     */
    @RequestMapping("/deleteById")
    public RestBean deleteById(SysRoleBean bean){
        // 不传入id不允许删除
        if(bean == null || (bean.getId() == null && CollectionUtils.isEmpty(bean.getIds()))){
            return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        }

        // 删除角色
        RestBean delMenuRest = sysRoleService.delete(bean);

        if(delMenuRest.getCode() == RestCode.DEFAULT_SUCCESS.getCode()){
            // 删除角色菜单对应记录
            roleMenuService.delete(SysRoleMenuBean.builder()
                    .roleId(bean.getId()).roleIdList(bean.getIds())
                    .build());
            // 删除角色功能对应记录
            roleFunctionService.delete(SysRoleFunctionBean.builder()
                    .roleId(bean.getId()).roleIdList(bean.getIds())
                    .build());
        }

        return delMenuRest;
    }

}
