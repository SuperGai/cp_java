package com.spz.demo.singleboot.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.spz.demo.singleboot.core.entity.BasicEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 系统用户与角色对应表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("sys_user_role")
public class SysUserRole extends BasicEntity {

    // 角色名称
    private Long userId;

    // 角色备注
    private Long roleId;

}
