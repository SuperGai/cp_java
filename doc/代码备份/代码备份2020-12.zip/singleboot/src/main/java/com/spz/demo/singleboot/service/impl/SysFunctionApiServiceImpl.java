package com.spz.demo.singleboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.spz.demo.singleboot.bean.*;
import com.spz.demo.singleboot.constant.DictTypeCodeConstant;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.dao.SysFunctionApiMapper;
import com.spz.demo.singleboot.entity.SysFunction;
import com.spz.demo.singleboot.entity.SysFunctionApi;
import com.spz.demo.singleboot.entity.SysRoleFunction;
import com.spz.demo.singleboot.service.SysApiService;
import com.spz.demo.singleboot.service.SysDictService;
import com.spz.demo.singleboot.service.SysFunctionApiService;
import com.spz.demo.singleboot.service.SysFunctionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SysFunctionApiServiceImpl extends ServiceImpl<SysFunctionApiMapper, SysFunctionApi> implements SysFunctionApiService {

    private final SysFunctionApiMapper functionApiMapper;
    private final SysApiService apiService;
    private final SysDictService dictService;
    private final SysFunctionService functionService;

    public SysFunctionApiServiceImpl(SysFunctionApiMapper functionApiMapper, SysApiService apiService, SysDictService dictService, SysFunctionService functionService){
        this.functionApiMapper = functionApiMapper;
        this.apiService = apiService;
        this.dictService = dictService;
        this.functionService = functionService;
    }

    @Transactional
    @Override
    public RestBean treeUpdate(List<Long> apiIdList,
                               Long functionId){
        // 删除原来的
        SysFunctionApi delFunApi = new SysFunctionApi();
        delFunApi.setValid(DataValid.INVALID);
        functionApiMapper.update(delFunApi, createWrapper(SysFunctionApiBean.builder().functionId(functionId).build()));

        // 插入新的
        if(CollectionUtils.isEmpty(apiIdList)) return RestBean.ok();
        apiIdList.forEach(apiId -> {
            SysFunctionApi functionApi = new SysFunctionApi();
            functionApi.setApiId(apiId);
            functionApi.setFunctionId(functionId);
            functionApiMapper.insert(functionApi);
        });

        return RestBean.ok();
    }

    @Override
    public HashMap treeFunctionApi(Long functionId){
        List<SysFunctionApiBean> allfunApiList = findList(null);

        HashMap<String, HashMap<String, Object>> allList = new HashMap<>();// key: roleId, value
        List<Object> checkedNameList = new ArrayList<>();//被选中的function id
        for (SysFunctionApiBean funApi : allfunApiList) {
            SysApiBean api = apiService.findOne(SysApiBean.builder().id(funApi.getApiId()).build());
            if(api == null) continue;

            // 设置被选中的
            if(functionId == funApi.getFunctionId()){
                checkedNameList.add(api.getId());
            }
        }

        // 设置全部
        List<SysApiBean> allApiBeanList = apiService.findList(null);
        for (SysApiBean api : allApiBeanList) {
            SysDictBean dictBean = dictService.findOne(SysDictBean.builder()
                    .value(api.getModule()).typeCode(DictTypeCodeConstant.SYSTEM_MODULE).build()
            );
            if(dictBean == null) continue;
            if(CollectionUtils.isEmpty(allList.get("module_" + api.getModule()))){
                allList.put("module_" + api.getModule(), new HashMap<String, Object>(){{
                    put("id", "" + "module_" + dictBean.getId());
                    put("name", dictBean.getName());
                    put("children", new ArrayList<SysApiBean>(){{
                        add(api);
                    }});
                }});
            }else{
                List tempList = ((List)(allList.get("module_" + api.getModule()).get("children")));
                if(!tempList.contains(api)) tempList.add(api);
            }
        }
        List<HashMap<String, Object>> allRest = new ArrayList<>();
        for(HashMap<String, Object> item : allList.values()){
            allRest.add(item);
        }

        return new HashMap<String, Object>(){{
            put("treeAllData", allRest);
            put("treeData", checkedNameList);
        }};
    }

    @Override
    public List<SysApiBean> findApiListByFunctionApi(SysFunctionApiBean bean){
        LambdaQueryWrapper<SysFunctionApi> wrapper = createWrapper(bean);
        List<SysFunctionApi> funcApiList = functionApiMapper.selectList(wrapper);

        if(CollectionUtils.isEmpty(funcApiList)) return Collections.EMPTY_LIST;
        List<Long> apiIdList = funcApiList.stream().filter(v -> v.getApiId() != null)
                .map(v->v.getApiId()).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(apiIdList)) return Collections.EMPTY_LIST;
        List<SysApiBean> apiList = apiService.findList(SysApiBean.builder()
                .ids(apiIdList).valid(DataValid.VALID)
                .build());
        return apiList;
    }

    @Override
    public List<SysFunctionApiBean> findList(SysFunctionApiBean bean){
        List<SysFunctionApi> list = functionApiMapper.selectList(createWrapper(bean));
        if(CollectionUtils.isEmpty(list)) return new ArrayList<>();
        List<SysFunctionApiBean> beanList = list.stream().map(item -> {
            SysFunctionApiBean restBean = new SysFunctionApiBean();
            BeanUtils.copyProperties(item, restBean);
            return restBean;
        }).collect(Collectors.toList());
        return beanList;
    }

    @Transactional
    @Override
    public RestBean delete(SysFunctionApiBean bean) {
        LambdaQueryWrapper<SysFunctionApi> wrapper = createWrapper(bean);

        SysFunctionApi updateEntity = new SysFunctionApi();
        updateEntity.setValid(DataValid.INVALID);

        return RestBean.ok(
                functionApiMapper.update(updateEntity, wrapper)
        );
    }

    /**
     * 建立查询条件
     * 条件尽量都写在此方法
     * @param bean
     * @return
     */
    private LambdaQueryWrapper createWrapper(SysFunctionApiBean bean){
        LambdaQueryWrapper<SysFunctionApi> wrapper = Wrappers.lambdaQuery();
        if(bean == null || bean.getValid() == null){
            wrapper.eq(SysFunctionApi::getValid,DataValid.VALID);
        }

        // 自定义条件
        if(bean != null) {
            if(bean.getValid() != null){
                wrapper.eq(SysFunctionApi::getValid,bean.getValid());
            }
            if(bean.getId() != null){
                wrapper.eq(SysFunctionApi::getId,bean.getId());
            }

            if(bean.getFunctionId() != null){
                wrapper.eq(SysFunctionApi::getFunctionId,bean.getFunctionId());
            }
            if(bean.getApiId() != null){
                wrapper.eq(SysFunctionApi::getApiId,bean.getApiId());
            }

            if(CollectionUtils.isNotEmpty(bean.getFunctionIdList())){
                wrapper.in(SysFunctionApi::getFunctionId, bean.getFunctionIdList());
            }
            if(CollectionUtils.isNotEmpty(bean.getApiIdList())){
                wrapper.in(SysFunctionApi::getApiId, bean.getApiIdList());
            }
        }

        return wrapper;
    }
}
