package com.spz.demo.singleboot.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.spz.demo.singleboot.core.entity.BasicEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 系统字典表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("sys_dict")
public class SysDict extends BasicEntity {

    // 字典类型id
    private Long typeId;

    // 名称
    private String name;

    // 字典值
    private String value;

    // 自定数据
    private String data;

    // 字典描述
    private String notes;

    // 排序
    private Long sort;

}
