package com.spz.demo.singleboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.spz.demo.singleboot.bean.SysDictBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.entity.SysApi;
import com.spz.demo.singleboot.entity.SysDict;

import java.util.HashMap;
import java.util.List;

public interface SysDictService extends IService<SysDict> {

    /**
     * 根据字典类型code获取字典集合
     * @param dictTypeCode 字典类型code
     * @return key: 字典值  value: 字典对象
     */
    HashMap<String, SysDictBean> findAllDictByType(String dictTypeCode);

    /**
     * 根据id获取列表
     * @param ids
     * @return
     */
    List<SysDictBean> findByIds(List<Long> ids);

    /**
     * 查询列表
     * @param bean
     * @return
     */
    List<SysDictBean> findList(SysDictBean bean);

    /**
     * 分页查询
     * @param bean
     * @param pageBean
     * @return
     */
    Page<SysDictBean> findPage(SysDictBean bean, PageBean pageBean);

    /**
     * 添加一条记录
     * @param bean
     * @return
     */
    SysDictBean add(SysDictBean bean);

    /**
     * 根据id更新一条记录
     * @param bean
     * @return
     */
    RestBean update(SysDictBean bean);

    /**
     * 删除多条记录
     * @param bean
     * @return
     */
    RestBean delete(SysDictBean bean);

    /**
     * 详情
     * @param bean
     * @return
     */
    SysDictBean findOne(SysDictBean bean);
}
