package com.spz.demo.singleboot.controller.system;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.spz.demo.singleboot.bean.*;
import com.spz.demo.singleboot.constant.DictTypeCodeConstant;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.service.SysDictService;
import com.spz.demo.singleboot.service.SysFunctionApiService;
import com.spz.demo.singleboot.service.SysFunctionService;
import com.spz.demo.singleboot.service.SysRoleFunctionService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

/**
 * 系统功能 控制器
 */
@RestController
@RequestMapping("/sys/function")
public class SysFunctionController {

    private final SysFunctionService functionService;
    private final SysFunctionApiService functionApiService;
    private final SysRoleFunctionService roleFunctionService;
    private final SysDictService dictService;
    public SysFunctionController(SysFunctionService functionService, SysFunctionApiService functionApiService, SysRoleFunctionService roleFunctionService, SysDictService dictService) {
        this.functionService = functionService;
        this.functionApiService = functionApiService;
        this.roleFunctionService = roleFunctionService;
        this.dictService = dictService;
    }

    /**
     * 下拉框列表
     * @param bean
     * @return
     */
    @RequestMapping("/dropdownList")
    public RestBean dropdownList(SysFunctionBean bean){
        return RestBean.ok(functionService.findList(bean));
    }

    /**
     * 分页查询
     * @param bean
     * @return
     */
    @RequestMapping("/listPage")
    public RestBean listPage(SysFunctionBean bean, PageBean pageBean){
        Page<SysFunctionBean> page = functionService.findPage(bean,pageBean);

        // 所有字典值
        HashMap<String, SysDictBean> allDictMap = dictService.findAllDictByType(DictTypeCodeConstant.SYSTEM_MODULE);

        page.getRecords().forEach(item -> {
            // 设置字典值描述
            if(allDictMap.get(item.getModule()) != null){
                item.setModuleDesc(allDictMap.get(item.getModule()).getName());
            }
        });

        return RestBean.ok(page);
    }

    /**
     * 查看详情
     * @param id
     * @return
     */
    @RequestMapping("/detail")
    public RestBean detail(Long id){
        SysFunctionBean bean = functionService.findOne(SysFunctionBean.builder()
                .id(id).valid(DataValid.VALID)
                .build());
        return RestBean.ok(bean);
    }

    /**
     * 新增一条记录
     * @param bean
     * @return
     */
    @RequestMapping("/add")
    public RestBean add(SysFunctionBean bean){
        if(functionService.repetition(bean)){
            return RestBean.error("记录重复");
        }
        functionService.add(bean);
        return RestBean.ok();
    }

    /**
     * 根据id更新一条记录
     * @param bean
     * @return
     */
    @RequestMapping("/update")
    public RestBean update(SysFunctionBean bean){
        if(bean == null || bean.getId() == null) return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        return RestBean.ok(functionService.update(bean));
    }

    /**
     * 根据id删除记录
     * @param bean 可传入id集合
     * @return
     */
    @RequestMapping("/deleteById")
    public RestBean deleteById(SysFunctionBean bean){
        // 不传入id不允许删除
        if(bean == null || (bean.getId() == null && CollectionUtils.isEmpty(bean.getIds()))){
            return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        }

        // 删除功能
        RestBean delMenuRest = functionService.delete(bean);

        if(delMenuRest.getCode() == RestCode.DEFAULT_SUCCESS.getCode()){
            // 删除功能角色对应记录
            functionApiService.delete(SysFunctionApiBean.builder()
                    .functionId(bean.getId()).functionIdList(bean.getIds())
                    .build());
            // 删除功能接口对应记录
            roleFunctionService.delete(SysRoleFunctionBean.builder()
                    .functionId(bean.getId()).functionIdList(bean.getIds())
                    .build());
        }

        return delMenuRest;
    }
}
