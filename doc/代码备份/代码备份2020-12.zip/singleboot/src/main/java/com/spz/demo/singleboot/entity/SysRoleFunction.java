package com.spz.demo.singleboot.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.spz.demo.singleboot.core.entity.BasicEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 系统角色与功能对应表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("sys_role_function")
public class SysRoleFunction extends BasicEntity {

    // 角色id
    private Long roleId;

    // 功能id
    private Long functionId;

}
