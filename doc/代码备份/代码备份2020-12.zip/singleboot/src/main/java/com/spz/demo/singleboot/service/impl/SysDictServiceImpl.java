package com.spz.demo.singleboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.spz.demo.singleboot.bean.SysDictBean;
import com.spz.demo.singleboot.bean.SysDictTypeBean;
import com.spz.demo.singleboot.constant.DictTypeCodeConstant;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.dao.SysDictMapper;
import com.spz.demo.singleboot.entity.SysDict;
import com.spz.demo.singleboot.entity.SysDictType;
import com.spz.demo.singleboot.service.SysDictService;
import com.spz.demo.singleboot.service.SysDictTypeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SysDictServiceImpl extends ServiceImpl<SysDictMapper, SysDict> implements SysDictService {

    private final SysDictMapper dictMapper;
    private final SysDictTypeService dictTypeService;

    public SysDictServiceImpl(SysDictMapper dictMapper, SysDictTypeService dictTypeService) {
        this.dictMapper = dictMapper;
        this.dictTypeService = dictTypeService;
    }

    @Override
    public HashMap<String, SysDictBean> findAllDictByType(String dictTypeCode){
        if(StringUtils.isBlank(dictTypeCode)) {
            return null;
        }

        // 获取字典值集合
        SysDictTypeBean typeBean = dictTypeService.findOne(SysDictTypeBean.builder()
                .code(dictTypeCode)
                .build());
        if(typeBean == null) {
            return new HashMap<>();
        }

        List<SysDictBean> dictList = findList(SysDictBean.builder()
                .typeId(typeBean.getId())
                .build());
        if(CollectionUtils.isEmpty(dictList)) {
            return new HashMap<>();
        }

        HashMap<String, SysDictBean> restMap = new HashMap<>();
        dictList.forEach(v->{
            restMap.put(v.getValue(), v);
        });
        return restMap;
    }

    @Override
    public List<SysDictBean> findByIds(List<Long> ids){
        if(CollectionUtils.isEmpty(ids)) return Collections.EMPTY_LIST;

        LambdaQueryWrapper<SysDict> wrapper = createWrapper(null);
        wrapper.in(SysDict::getId,ids);
        List<SysDict> roles = dictMapper.selectList(wrapper);

        List<SysDictBean> roleBeans = new ArrayList<>();
        roles.forEach(v->{
            SysDictBean item = new SysDictBean();
            BeanUtils.copyProperties(v,item);
            roleBeans.add(item);
        });
        return roleBeans;
    }

    @Override
    public List<SysDictBean> findList(SysDictBean bean){
        LambdaQueryWrapper<SysDict> wrapper = createWrapper(bean);

        // 分页查询
        List<SysDict> list = dictMapper.selectList(wrapper);
        if(CollectionUtils.isEmpty(list)) return Collections.EMPTY_LIST;

        List<SysDictBean> beanList = list.stream().map(item -> {
            SysDictBean srcBean = new SysDictBean();
            BeanUtils.copyProperties(item,srcBean);
            return srcBean;
        }).collect(Collectors.toList());
        return beanList;
    }

    @Override
    public Page<SysDictBean> findPage(SysDictBean bean, PageBean pageBean){
        LambdaQueryWrapper<SysDict> wrapper = createWrapper(bean);

        // 分页查询
        Page<SysDict> page = new Page<>(pageBean.getCurrent(),pageBean.getSize());
        page = dictMapper.selectPage(page,wrapper);

        if(CollectionUtils.isEmpty(page.getRecords())) return new Page<>();

        Page<SysDictBean> beanPage = new Page<>();
        BeanUtils.copyProperties(page,beanPage,"records");
        beanPage.setRecords(new ArrayList<>());
        page.getRecords().forEach(v->{
            SysDictBean dictBean = new SysDictBean();
            BeanUtils.copyProperties(v, dictBean);
            beanPage.getRecords().add(dictBean);
        });
        return beanPage;
    }

    @Transactional
    @Override
    public SysDictBean add(SysDictBean bean){
        // 根据typeCode获取字典类型信息
        SysDictTypeBean typeBean = dictTypeService.findOne(SysDictTypeBean.builder().code(bean.getTypeCode()).build());
        if(typeBean == null) return null;
        bean.setTypeName(typeBean.getName());
        bean.setTypeCode(typeBean.getCode());
        bean.setTypeId(typeBean.getId());

        SysDict SysDict = new SysDict();
        BeanUtils.copyProperties(bean,SysDict);

        dictMapper.insert(SysDict);
        BeanUtils.copyProperties(SysDict,bean);
        return bean;
    }

    @Transactional
    @Override
    public RestBean update(SysDictBean bean) {

        // 根据typeCode获取字典类型信息
        if(StringUtils.isNotBlank(bean.getTypeCode())){
            SysDictTypeBean typeBean = dictTypeService.findOne(SysDictTypeBean.builder().code(bean.getTypeCode()).build());
            if(typeBean == null) return null;
            bean.setTypeName(typeBean.getName());
            bean.setTypeCode(typeBean.getCode());
            bean.setTypeId(typeBean.getId());
        }

        SysDict source = new SysDict();
        BeanUtils.copyProperties(bean,source);
        return RestBean.ok(dictMapper.updateById(source));
    }

    @Transactional
    @Override
    public RestBean delete(SysDictBean bean) {
        SysDict updateSource = new SysDict();
        updateSource.setValid(DataValid.INVALID);

        LambdaQueryWrapper<SysDict> wrapper = createWrapper(bean);
        return RestBean.ok(dictMapper.update(updateSource, wrapper));
    }

    @Override
    public SysDictBean findOne(SysDictBean bean) {
        List<SysDict> entitys = dictMapper.selectList(createWrapper(bean));
        if(CollectionUtils.isEmpty(entitys)) return null;

        SysDictBean restBean = new SysDictBean();
        BeanUtils.copyProperties(entitys.get(0),restBean);
        return restBean;
    }

    /**
     * 建立查询条件
     * 条件尽量都写在此方法
     * @param bean
     * @return
     */
    private LambdaQueryWrapper createWrapper(SysDictBean bean){
        LambdaQueryWrapper<SysDict> wrapper = Wrappers.lambdaQuery();
        if(bean == null || bean.getValid() == null){
            wrapper.eq(SysDict::getValid,DataValid.VALID);
        }

        // 自定义条件
        if(bean != null) {
            if(bean.getValid() != null){
                wrapper.eq(SysDict::getValid,bean.getValid());
            }
            if(bean.getId() != null){
                wrapper.eq(SysDict::getId,bean.getId());
            }

            if(bean.getTypeId() != null){
                wrapper.eq(SysDict::getTypeId, bean.getTypeId());
            }
            if(StringUtils.isNotBlank(bean.getName())){
                wrapper.like(SysDict::getName, bean.getName());
            }

            if(StringUtils.isNotBlank(bean.getData())){
                wrapper.eq(SysDict::getData,bean.getData());
            }

            if(StringUtils.isNotBlank(bean.getValue())){
                wrapper.eq(SysDict::getValue, bean.getValue());
            }

            if(StringUtils.isNotBlank(bean.getNotes())){
                wrapper.like(SysDict::getNotes, bean.getNotes());
            }

            if(CollectionUtils.isNotEmpty(bean.getTypeIdList())){
                wrapper.in(SysDict::getTypeId, bean.getTypeIdList());
            }
        }

        return wrapper;
    }
}
