package com.spz.demo.singleboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.spz.demo.singleboot.bean.*;
import com.spz.demo.singleboot.bean.SysRoleMenuBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.dao.SysRoleMenuMapper;
import com.spz.demo.singleboot.entity.SysRoleMenu;
import com.spz.demo.singleboot.service.SysMenuService;
import com.spz.demo.singleboot.service.SysRoleMenuService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SysRoleMenuServiceImpl extends ServiceImpl<SysRoleMenuMapper, SysRoleMenu> implements SysRoleMenuService {

    private final SysRoleMenuMapper roleMenuMapper;
    private final SysMenuService menuService;

    public SysRoleMenuServiceImpl(SysRoleMenuMapper roleMenuMapper, SysMenuService menuService) {
        this.roleMenuMapper = roleMenuMapper;
        this.menuService = menuService;
    }

    @Transactional
    @Override
    public RestBean roleMenuTreeUpdate(List<Long> menuIdList, Long roleId){
        // 删除原来的
        delete(SysRoleMenuBean.builder().roleId(roleId).build());
        if(CollectionUtils.isEmpty(menuIdList)) return RestBean.ok();

        // 子菜单所在父菜单也需要加入
//        List<Long> tempList = new ArrayList<>();
//        for (Long menuId : menuIdList) {
//            SysMenuBean menu = menuService.findOne(SysMenuBean.builder().id(menuId).build());
//            if(menu == null || menu.getParentId() == null) continue;
//            if(menu.getParentId() != 0 && !menuIdList.contains(menu.getParentId()) &&
//                !tempList.contains(menu.getParentId())){
//                tempList.add(menu.getParentId());
//            }
//        }
//        menuIdList.addAll(tempList);

        // 插入记录
        menuIdList.forEach(menuId -> {
            add(SysRoleMenuBean.builder()
                .roleId(roleId).menuId(menuId)
                .build()
            );
        });

        return RestBean.ok();
    }

    @Override
    public HashMap findMenuTreeByRole(Long roleId){
        // 获取全部菜单
        List<SysMenuBean> allMenuList = menuService.findList(null);
        if(CollectionUtils.isEmpty(allMenuList)) return null;

        // 构造全部菜单树
        LinkedList<SysMenuBean> allRest = menuService.createTree(allMenuList);

        // 获取指定roleid的菜单树
        List<Long> checkedMenuIdList = new ArrayList<>();
        if(roleId != null && roleId != 0){
            List<SysRoleMenuBean> roleMenuList = findList(SysRoleMenuBean.builder().roleId(roleId).build());
            checkedMenuIdList = roleMenuList.stream().map(v->{
                return v.getMenuId();
            }).collect(Collectors.toList());
        }

        HashMap<String, Object> rest = new HashMap<>();
        rest.put("treeAllData", allRest);
        rest.put("treeData", checkedMenuIdList);
        return rest;
    }

    @Override
    public List<SysRoleMenuBean> findList(SysRoleMenuBean bean) {
        LambdaQueryWrapper<SysRoleMenu> wrapper = createWrapper(bean);
        List<SysRoleMenu> roleMenuList = roleMenuMapper.selectList(wrapper);
        if(CollectionUtils.isEmpty(roleMenuList)) return Collections.EMPTY_LIST;
        List<SysRoleMenuBean> roleMenuBeanList = roleMenuList.stream().map(item -> {
            SysRoleMenuBean srcBean = new SysRoleMenuBean();
            BeanUtils.copyProperties(item,srcBean);
            return srcBean;
        }).collect(Collectors.toList());
        return roleMenuBeanList;
    }

    @Transactional
    @Override
    public SysRoleMenuBean add(SysRoleMenuBean bean){
        SysRoleMenu source = new SysRoleMenu();
        BeanUtils.copyProperties(bean,source);

        roleMenuMapper.insert(source);
        BeanUtils.copyProperties(source,bean);
        return bean;
    }

    @Transactional
    @Override
    public RestBean delete(SysRoleMenuBean bean) {
        LambdaQueryWrapper<SysRoleMenu> wrapper = createWrapper(bean);

        SysRoleMenu updateEntity = new SysRoleMenu();
        updateEntity.setValid(DataValid.INVALID);

        return RestBean.ok(
                roleMenuMapper.update(updateEntity, wrapper)
        );
    }

    /**
     * 建立查询条件
     * 条件尽量都写在此方法
     * @param bean
     * @return
     */
    private LambdaQueryWrapper createWrapper(SysRoleMenuBean bean){
        LambdaQueryWrapper<SysRoleMenu> wrapper = Wrappers.lambdaQuery();
        if(bean == null || bean.getValid() == null){
            wrapper.eq(SysRoleMenu::getValid,DataValid.VALID);
        }

        // 自定义条件
        if(bean != null) {
            if(bean.getValid() != null){
                wrapper.eq(SysRoleMenu::getValid,bean.getValid());
            }
            if(bean.getId() != null){
                wrapper.eq(SysRoleMenu::getId,bean.getId());
            }

            if(bean.getRoleId() != null){
                wrapper.eq(SysRoleMenu::getRoleId,bean.getRoleId());
            }
            if(CollectionUtils.isNotEmpty(bean.getMenuIdList())){
                wrapper.in(SysRoleMenu::getId,bean.getMenuIdList());
            }
            if(bean.getMenuId() != null){
                wrapper.eq(SysRoleMenu::getMenuId, bean.getMenuId());
            }
            if(CollectionUtils.isNotEmpty(bean.getRoleIdList())){
                wrapper.in(SysRoleMenu::getRoleId, bean.getRoleIdList());
            }
            if(CollectionUtils.isNotEmpty(bean.getMenuIdList())){
                wrapper.in(SysRoleMenu::getMenuId, bean.getMenuIdList());
            }
        }

        return wrapper;
    }
}
