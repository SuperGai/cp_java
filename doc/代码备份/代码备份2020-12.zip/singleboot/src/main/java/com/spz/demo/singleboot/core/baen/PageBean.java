package com.spz.demo.singleboot.core.baen;

import lombok.Data;

/**
 * 分页bean
 */
@Data
public class PageBean {

    // 每页显示条数，默认 10
    private long size = 10;

    // 当前页 默认1
    private long current = 1;

}
