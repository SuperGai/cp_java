package com.spz.demo.singleboot.core.exception.custom;

import com.spz.demo.singleboot.core.exception.BasicException;

/**
 * 自定义异常类
 * 权限异常
 * 在登录异常、权限异常时可抛出
 */
public class RoleException extends BasicException {
    public RoleException(String message){
        super(message);
    }
}
