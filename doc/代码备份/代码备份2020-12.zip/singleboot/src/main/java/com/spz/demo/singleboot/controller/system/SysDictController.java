package com.spz.demo.singleboot.controller.system;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.spz.demo.singleboot.bean.SysDictBean;
import com.spz.demo.singleboot.bean.SysDictTypeBean;
import com.spz.demo.singleboot.bean.SysFunctionBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.entity.SysDict;
import com.spz.demo.singleboot.service.SysDictService;
import com.spz.demo.singleboot.service.SysDictTypeService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 系统字典控制器
 */
@RestController
@RequestMapping("/sys/dict")
public class SysDictController {

    private final SysDictService dictService;
    private final SysDictTypeService dictTypeService;

    public SysDictController(SysDictService dictService, SysDictTypeService dictTypeService) {
        this.dictService = dictService;
        this.dictTypeService = dictTypeService;
    }

    /**
     * 下拉框列表
     * @param bean
     * @return
     */
    @RequestMapping("/dropdownList")
    public RestBean dropdownList(SysDictBean bean){
        return RestBean.ok(dictService.findList(bean));
    }

    /**
     * 分页查询
     * @param bean
     * @return
     */
    @RequestMapping("/listPage")
    public RestBean listPage(SysDictBean bean, PageBean pageBean){

        // 字典类型code
        if(bean != null && StringUtils.isNotBlank(bean.getTypeCode())){
            SysDictTypeBean typeBean = dictTypeService.findOne(SysDictTypeBean.builder()
                    .code(bean.getTypeCode())
                    .build());
            if(typeBean != null){
                bean.setTypeId(typeBean.getId());
                bean.setTypeCode(null);
            }else{
                return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
            }
        }

        Page<SysDictBean> page = dictService.findPage(bean,pageBean);
        if(page == null || CollectionUtils.isEmpty(page.getRecords())) return RestBean.ok(new Page<>());

        page.getRecords().stream().map(v->{
            if(v.getTypeId() != null){
                SysDictTypeBean typeBean = dictTypeService.findOne(SysDictTypeBean.builder()
                        .id(v.getTypeId()).valid(DataValid.VALID)
                        .build());
                if(typeBean != null){
                    v.setTypeName(typeBean.getName());
                    v.setTypeCode(typeBean.getCode());
                }else{
                    v.setTypeName("--");
                    v.setTypeCode("--");
                }
            }
            return v;
        }).collect(Collectors.toList());

        return RestBean.ok(page);
    }

    /**
     * 查看详情
     * @param id
     * @return
     */
    @RequestMapping("/detail")
    public RestBean detail(Long id){
        SysDictBean bean = dictService.findOne(SysDictBean.builder()
                .id(id).valid(DataValid.VALID)
                .build());
        if(bean != null && bean.getTypeId() != null){
            SysDictTypeBean typeBean = dictTypeService.findOne(SysDictTypeBean.builder().id(bean.getTypeId()).build());
            bean.setTypeCode(typeBean == null ? "" : typeBean.getCode());
        }
        return RestBean.ok(bean);
    }

    /**
     * 新增一条记录
     * @param bean
     * @return
     */
    @RequestMapping("/add")
    public RestBean add(SysDictBean bean){
        return RestBean.ok(dictService.add(bean));
    }

    /**
     * 根据id更新一条记录
     * @param bean
     * @return
     */
    @RequestMapping("/update")
    public RestBean update(SysDictBean bean){
        if(bean == null || bean.getId() == null) return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        return RestBean.ok(dictService.update(bean));
    }

    /**
     * 根据id删除记录
     * @param bean 可传入id集合
     * @return
     */
    @RequestMapping("/deleteById")
    public RestBean deleteById(SysDictBean bean){
        // 不传入id不允许删除
        if(bean == null || (bean.getId() == null && CollectionUtils.isEmpty(bean.getIds()))){
            return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        }
        return dictService.delete(bean);
    }

}
