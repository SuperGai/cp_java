package com.spz.demo.singleboot.controller.system;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.spz.demo.singleboot.bean.SysFunctionBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.bean.SysUserBean;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.service.SysUserService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 系统用户控制器
 */
@RestController
@RequestMapping("/sys/user")
public class SysUserController {

    private final SysUserService sysUserService;

    public SysUserController(SysUserService sysUserService){
        this.sysUserService = sysUserService;
    }

    /**
     * 分页查询
     * @param bean
     * @return
     */
    @RequestMapping("/listPage")
    public RestBean listPage(SysUserBean bean, PageBean pageBean){
        Page<SysUserBean> userBeanPage = sysUserService.findPage(bean,pageBean);
        return RestBean.ok(userBeanPage);
    }

    /**
     * 添加记录
     * @param bean
     * @return
     */
    @RequestMapping("/add")
    public RestBean add(SysUserBean bean){
        return sysUserService.add(bean);
    }

    /**
     * 更新记录
     * @param bean
     * @return
     */
    @RequestMapping("/update")
    public RestBean update(SysUserBean bean){
        return sysUserService.updateById(bean);
    }

    /**
     * 根据id删除记录
     * @param bean 可传入id集合
     * @return
     */
    @RequestMapping("/deleteById")
    public RestBean deleteById(SysUserBean bean){
        // 不传入id不允许删除
        if(bean == null || (bean.getId() == null && CollectionUtils.isEmpty(bean.getIds()))){
            return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        }
        return sysUserService.delete(bean);
    }

}
