package com.spz.demo.singleboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.spz.demo.singleboot.bean.SysRoleBean;
import com.spz.demo.singleboot.bean.SysUserBean;
import com.spz.demo.singleboot.bean.SysUserRoleBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.dao.SysUserRoleMapper;
import com.spz.demo.singleboot.entity.SysRole;
import com.spz.demo.singleboot.entity.SysUserRole;
import com.spz.demo.singleboot.service.SysRoleService;
import com.spz.demo.singleboot.service.SysUserRoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SysUserRoleServiceImpl extends ServiceImpl<SysUserRoleMapper, SysUserRole> implements SysUserRoleService {

    private final SysUserRoleMapper sysUserRoleMapper;

    public SysUserRoleServiceImpl(SysUserRoleMapper sysUserRoleMapper) {
        this.sysUserRoleMapper = sysUserRoleMapper;
    }

    @Override
    public List<SysUserRoleBean> findAll(SysUserRoleBean bean) {
        LambdaQueryWrapper<SysUserRole> wrapper = createWrapper(bean);
        List<SysUserRole> userRoleList = sysUserRoleMapper.selectList(wrapper);
        List<SysUserRoleBean> userRoleBeanList = userRoleList.stream().map(item -> {
            SysUserRoleBean srcBean = new SysUserRoleBean();
            BeanUtils.copyProperties(item,srcBean);
            return srcBean;
        }).collect(Collectors.toList());
        return userRoleBeanList;
    }

    @Override
    public Integer count(SysUserRoleBean bean) {
        return sysUserRoleMapper.selectCount(createWrapper(bean));
    }

    /**
     * 建立查询条件
     * 条件尽量都写在此方法
     * @param bean
     * @return
     */
    private LambdaQueryWrapper createWrapper(SysUserRoleBean bean){
        LambdaQueryWrapper<SysUserRole> wrapper = Wrappers.lambdaQuery();
        if(bean == null || bean.getValid() == null){
            wrapper.eq(SysUserRole::getValid,DataValid.VALID);
        }

        // 自定义条件
        if(bean != null) {
            if(bean.getValid() != null){
                wrapper.eq(SysUserRole::getValid,bean.getValid());
            }
            if(bean.getId() != null){
                wrapper.eq(SysUserRole::getId,bean.getId());
            }

            if(bean.getUserId() != null){
                wrapper.eq(SysUserRole::getUserId,bean.getUserId());
            }
            if(bean.getRoleId() != null){
                wrapper.eq(SysUserRole::getRoleId,bean.getRoleId());
            }

            if(CollectionUtils.isNotEmpty(bean.getUserIdList())){
                wrapper.in(SysUserRole::getUserId, bean.getUserIdList());
            }
            if(CollectionUtils.isNotEmpty(bean.getRoleIdList())){
                wrapper.in(SysUserRole::getRoleId, bean.getRoleIdList());
            }
        }

        return wrapper;
    }
}
