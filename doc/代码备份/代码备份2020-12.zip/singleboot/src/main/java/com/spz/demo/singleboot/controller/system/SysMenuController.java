package com.spz.demo.singleboot.controller.system;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.spz.demo.singleboot.bean.SysFunctionBean;
import com.spz.demo.singleboot.bean.SysMenuBean;
import com.spz.demo.singleboot.bean.SysRoleMenuBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.service.SysMenuService;
import com.spz.demo.singleboot.service.SysRoleMenuService;
import com.spz.demo.singleboot.service.SysUserService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 系统菜单控制器
 */
@RestController
@RequestMapping("/sys/menu")
public class SysMenuController {

    private final SysMenuService sysMenuService;
    private final SysUserService userService;
    private final SysRoleMenuService roleMenuService;

    public SysMenuController(SysMenuService sysMenuService, SysUserService userService, SysRoleMenuService roleMenuService) {
        this.sysMenuService = sysMenuService;
        this.userService = userService;
        this.roleMenuService = roleMenuService;
    }

    /**
     * 下拉框列表
     * @param bean
     * @return
     */
    @RequestMapping("/dropdownList")
    public RestBean dropdownList(SysMenuBean bean){
        return RestBean.ok(sysMenuService.findList(bean));
    }

    /**
     * 分页查询
     * @param bean
     * @return
     */
    @RequestMapping("/listPage")
    public RestBean listPage(SysMenuBean bean, PageBean pageBean){
        Page<SysMenuBean> page = sysMenuService.findPage(bean,pageBean);
        if(page == null || CollectionUtils.isEmpty(page.getRecords())) return RestBean.ok(new Page<>());

        page.getRecords().forEach(v->{
            if(v.getParentId() != null) {
                SysMenuBean parent = sysMenuService.findOne(SysMenuBean.builder()
                        .id(v.getParentId()).valid(DataValid.VALID)
                        .build());
                if (parent != null) {
                    v.setParentName(parent.getName());
                } else {
                    v.setParentName("--");
                }
            }
        });

        return RestBean.ok(page);
    }

    /**
     * 查看详情
     * @param id
     * @return
     */
    @RequestMapping("/detail")
    public RestBean detail(Long id){
        return RestBean.ok(sysMenuService.findOne(SysMenuBean.builder()
                .id(id).valid(DataValid.VALID)
                .build()));
    }

    /**
     * 新增一条记录
     * @param bean
     * @return
     */
    @RequestMapping("/add")
    public RestBean add(SysMenuBean bean){
        return RestBean.ok(sysMenuService.add(bean));
    }

    /**
     * 根据id更新一条记录
     * @param bean
     * @return
     */
    @RequestMapping("/update")
    public RestBean update(SysMenuBean bean){
        if(bean == null || bean.getId() == null) return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        return RestBean.ok(sysMenuService.update(bean));
    }

    /**
     * 根据id删除记录
     * @param bean 可传入id集合
     * @return
     */
    @RequestMapping("/deleteById")
    public RestBean deleteById(SysMenuBean bean){
        // 不传入id不允许删除
        if(bean == null || (bean.getId() == null && CollectionUtils.isEmpty(bean.getIds()))){
            return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        }

        // 删除菜单
        RestBean delMenuRest = sysMenuService.delete(bean);

        // 删除 角色与菜单对应表记录
        if(delMenuRest.getCode() == RestCode.DEFAULT_SUCCESS.getCode()){
            roleMenuService.delete(SysRoleMenuBean.builder()
                    .menuIdList(bean.getIds()).menuId(bean.getId())
                    .build());
        }

        return delMenuRest;
    }

}
