package com.spz.demo.singleboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.spz.demo.singleboot.bean.SysFunctionBean;
import com.spz.demo.singleboot.bean.SysRoleFunctionBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.entity.SysRoleFunction;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;

public interface SysRoleFunctionService extends IService<SysRoleFunction> {

    /**
     * 角色功能树更新
     * @param funIdList
     * @param roleId
     * @return
     */
    RestBean treeUpdate(List<Long> funIdList,
                        Long roleId);

    /**
     * 获取角色功能树
     * @param roleId
     * @return
     */
    HashMap roleFunctionTree(Long roleId);

    /**
     * 列表查询
     * @param bean
     * @return
     */
    List<SysRoleFunctionBean> findList(SysRoleFunctionBean bean);

    /**
     * 查询功能列表
     * @param bean
     * @return
     */
    List<SysFunctionBean> findFunctionListByRoleFunction(SysRoleFunctionBean bean);

    /**
     * 删除多条记录
     * @param bean
     * @return
     */
    RestBean delete(SysRoleFunctionBean bean);
}
