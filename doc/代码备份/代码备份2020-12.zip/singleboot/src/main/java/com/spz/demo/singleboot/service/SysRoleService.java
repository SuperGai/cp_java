package com.spz.demo.singleboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.spz.demo.singleboot.bean.SysRoleBean;
import com.spz.demo.singleboot.bean.SysUserBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.entity.SysRole;

import java.util.List;

public interface SysRoleService extends IService<SysRole> {

    /**
     * 根据用户查询角色列表
     * @param bean
     * @return
     */
    List<SysRoleBean> findByUser(SysUserBean bean);

    /**
     * 根据id获取角色列表
     * @param roleIds
     * @return
     */
    List<SysRoleBean> findByIds(List<Long> roleIds);

    /**
     * 分页查询
     * @param bean
     * @param pageBean
     * @return
     */
    Page<SysRoleBean> findPage(SysRoleBean bean, PageBean pageBean);

    /**
     * 添加一条记录
     * @param bean
     * @return
     */
    SysRoleBean add(SysRoleBean bean);

    /**
     * 根据id更新一条记录
     * @param bean
     * @return
     */
    RestBean update(SysRoleBean bean);

    /**
     * 删除多条记录
     * @param bean
     * @return
     */
    RestBean delete(SysRoleBean bean);

    /**
     * 查询一条记录
     * @param bean
     * @return
     */
    SysRoleBean findOne(SysRoleBean bean);
}
