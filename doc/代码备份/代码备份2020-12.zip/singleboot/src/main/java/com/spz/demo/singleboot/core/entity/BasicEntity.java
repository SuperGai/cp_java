package com.spz.demo.singleboot.core.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 基础实体类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BasicEntity implements Serializable {

    // 主键id 自动生成
    @TableId(type = IdType.AUTO)
    protected Long id;

    // 数据是否有效
    protected Integer valid;

    // 记录创建时间
    protected Date createTime;

    // 记录更新时间
    protected Date updateTime;
}
