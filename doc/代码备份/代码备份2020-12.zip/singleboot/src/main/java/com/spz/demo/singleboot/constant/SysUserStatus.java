package com.spz.demo.singleboot.constant;

/**
 * 用户状态
 */
public class SysUserStatus {

    // 已启用
    public static final String ENABLE = "1";

    // 已停用
    public static final String DISABLE = "2";

}
