package com.spz.demo.singleboot.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;
import java.util.List;

/**
 * 系统用户与角色对应表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SysUserRoleBean {

    // 用户id
    private Long userId;

    // 角色id
    private Long roleId;

    // 角色名称
    private String roleName;

    // 主键id
    private Long id;

    // 数据是否有效
    private Integer valid;

    // 记录创建时间
    private Date createTime;

    // 记录更新时间
    private Date updateTime;

    // 用户id集合
    private List<Long> userIdList;

    // 角色id集合
    private List<Long> roleIdList;
}
