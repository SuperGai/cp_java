package com.spz.demo.singleboot.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;
import java.util.List;

/**
 * 系统角色与菜单对应表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SysRoleMenuBean {

    // 角色id
    private Long roleId;

    // 菜单id
    private Long menuId;

    // 主键id
    private Long id;

    // 数据是否有效
    private Integer valid;

    // 记录创建时间
    private Date createTime;

    // 记录更新时间
    private Date updateTime;

    // 菜单id集合
    private List<Long> menuIdList;

    // 角色id集合
    private List<Long> roleIdList;
}
