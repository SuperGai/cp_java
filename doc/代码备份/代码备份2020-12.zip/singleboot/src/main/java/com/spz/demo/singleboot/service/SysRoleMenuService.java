package com.spz.demo.singleboot.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.spz.demo.singleboot.bean.SysRoleMenuBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.entity.SysRoleMenu;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;

public interface SysRoleMenuService extends IService<SysRoleMenu> {

    @Transactional
    RestBean roleMenuTreeUpdate(List<Long> menuIdList, Long roleId);

    /**
     * 获取菜单树
     * @param roleId
     * @return 获取全部菜单树，以及指定角色所拥有权限的菜单id集合
     */
    HashMap findMenuTreeByRole(Long roleId);

    /**
     * 查询列表
     * @param bean
     * @return
     */
    List<SysRoleMenuBean> findList(SysRoleMenuBean bean);

    /**
     * 添加记录
     * @param bean
     * @return
     */
    SysRoleMenuBean add(SysRoleMenuBean bean);

    /**
     * 删除多条记录
     * @param bean
     * @return
     */
    RestBean delete(SysRoleMenuBean bean);
}
