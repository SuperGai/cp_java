package com.spz.demo.singleboot.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.spz.demo.singleboot.bean.SysApiBean;
import com.spz.demo.singleboot.bean.SysDictBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.dao.SysApiMapper;
import com.spz.demo.singleboot.entity.SysApi;
import com.spz.demo.singleboot.service.SysApiService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SysApiServiceImpl extends ServiceImpl<SysApiMapper, SysApi> implements SysApiService {

    private final SysApiMapper apiMapper;

    public SysApiServiceImpl(SysApiMapper apiMapper) {
        this.apiMapper = apiMapper;
    }

    @Override
    public List<SysApiBean> findByIds(List<Long> ids){
        if(CollectionUtils.isEmpty(ids)) return Collections.EMPTY_LIST;

        LambdaQueryWrapper<SysApi> wrapper = createWrapper(null);
        wrapper.in(SysApi::getId,ids);
        List<SysApi> roles = apiMapper.selectList(wrapper);

        List<SysApiBean> roleBeans = new ArrayList<>();
        roles.forEach(v->{
            SysApiBean item = new SysApiBean();
            BeanUtils.copyProperties(v,item);
            roleBeans.add(item);
        });
        return roleBeans;
    }

    @Override
    public List<SysApiBean> findList(SysApiBean bean){
        LambdaQueryWrapper<SysApi> wrapper = createWrapper(bean);

        // 分页查询
        List<SysApi> list = apiMapper.selectList(wrapper);
        if(CollectionUtils.isEmpty(list)) return Collections.EMPTY_LIST;

        List<SysApiBean> beanList = list.stream().map(item -> {
            SysApiBean srcBean = new SysApiBean();
            BeanUtils.copyProperties(item,srcBean);
            return srcBean;
        }).collect(Collectors.toList());
        return beanList;
    }

    @Override
    public Page<SysApiBean> findPage(SysApiBean bean, PageBean pageBean){
        LambdaQueryWrapper<SysApi> wrapper = createWrapper(bean);

        // 分页查询
        Page<SysApi> page = new Page<>(pageBean.getCurrent(),pageBean.getSize());
        page = apiMapper.selectPage(page,wrapper);

        if(CollectionUtils.isEmpty(page.getRecords())) return new Page<>();

        Page<SysApiBean> restPage = new Page<>();
        BeanUtils.copyProperties(page,restPage,"records");
        restPage.setRecords(new ArrayList<>());
        page.getRecords().forEach(v->{
            SysApiBean itemBean = new SysApiBean();
            BeanUtils.copyProperties(v, itemBean);
            restPage.getRecords().add(itemBean);
        });
        return restPage;
    }

    @Transactional
    @Override
    public SysApiBean add(SysApiBean bean){
        // 处理斜杠方向，统一为 /
        if(StringUtils.isNotBlank(bean.getUrl())){
            bean.setUrl(bean.getUrl().replace("\\", "/"));
        }

        SysApi source = new SysApi();
        BeanUtils.copyProperties(bean, source);

        apiMapper.insert(source);
        BeanUtils.copyProperties(source, bean);
        return bean;
    }

    @Transactional
    @Override
    public RestBean update(SysApiBean bean) {
        SysApi source = new SysApi();
        BeanUtils.copyProperties(bean,source);
        return RestBean.ok(apiMapper.updateById(source));
    }

    @Transactional
    @Override
    public RestBean delete(SysApiBean bean) {
        SysApi updateSource = new SysApi();
        updateSource.setValid(DataValid.INVALID);

        LambdaQueryWrapper<SysApi> wrapper = createWrapper(bean);
        return RestBean.ok(apiMapper.update(updateSource, wrapper));
    }

    @Override
    public SysApiBean findOne(SysApiBean bean) {
        SysApi entity = apiMapper.selectOne(createWrapper(bean));
        if(entity == null) return null;

        SysApiBean restBean = new SysApiBean();
        BeanUtils.copyProperties(entity,restBean);
        return restBean;
    }

    /**
     * 建立查询条件
     * 条件尽量都写在此方法
     * @param bean
     * @return
     */
    private LambdaQueryWrapper createWrapper(SysApiBean bean){
        LambdaQueryWrapper<SysApi> wrapper = Wrappers.lambdaQuery();
        if(bean == null || bean.getValid() == null){
            wrapper.eq(SysApi::getValid,DataValid.VALID);
        }

        // 自定义条件
        if(bean != null) {
            if(bean.getValid() != null){
                wrapper.eq(SysApi::getValid,bean.getValid());
            }
            if(bean.getId() != null){
                wrapper.eq(SysApi::getId,bean.getId());
            }

            if(StringUtils.isNotBlank(bean.getName())){
                wrapper.like(SysApi::getName,bean.getName());
            }
            if(StringUtils.isNotBlank(bean.getModule())){
                wrapper.eq(SysApi::getModule,bean.getModule());
            }
            if(StringUtils.isNotBlank(bean.getUrl())){
                wrapper.eq(SysApi::getUrl,bean.getUrl());
            }
            if(CollectionUtils.isNotEmpty(bean.getIds())){
                wrapper.in(SysApi::getId,bean.getIds());
            }
        }

        return wrapper;
    }
}
