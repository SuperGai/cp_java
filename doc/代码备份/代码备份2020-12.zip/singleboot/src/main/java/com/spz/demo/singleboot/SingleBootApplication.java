package com.spz.demo.singleboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SingleBootApplication {
    public static void main(String[] args) {
        SpringApplication.run(SingleBootApplication.class, args);
    }
}
