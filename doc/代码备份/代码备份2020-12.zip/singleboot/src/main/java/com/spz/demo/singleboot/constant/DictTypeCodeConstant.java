package com.spz.demo.singleboot.constant;

/**
 * 字典类型标识定义
 *
 * @see com.spz.demo.singleboot.entity.SysDictType
 */
public class DictTypeCodeConstant {

    // 审核状态
    public static final String APPROVE_STATUS = "APPROVE_STATUS";
    // 审核结果
    public static final String APPROVE_RESULT = "APPROVE_RESULT";

    // 系统模块
    public static final String SYSTEM_MODULE = "SYSTEM_MODULE";

}
