package com.spz.demo.singleboot.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;
import java.util.List;

/**
 * 系统接口资源
 * 存放系统所有的接口url资源
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SysApiBean {

    // 接口名称
    private String name;

    // 接口路径
    private String url;

    // 所属模块 从字典表取值
    private String module;

    // 主键id
    private Long id;

    // 数据是否有效
    private Integer valid;

    // 记录创建时间
    private Date createTime;

    // 记录更新时间
    private Date updateTime;

    // id列表
    private List<Long> ids;

    // 所属模块描述
    private String moduleDesc;
}
