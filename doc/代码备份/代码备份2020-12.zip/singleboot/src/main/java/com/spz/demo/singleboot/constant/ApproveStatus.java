package com.spz.demo.singleboot.constant;

/**
 * 用户审核状态
 */
public class ApproveStatus {

    //未审核
    public static final String NO = "1";

    //已审核
    public static final String YES = "2";


}
