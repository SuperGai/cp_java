package com.spz.demo.singleboot.core.exception;

/**
 * 自定义异常基类
 */
public class BasicException extends RuntimeException {
    public BasicException(String message){
        super(message);
    }
}
