package com.spz.demo.singleboot.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * 系统角色表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SysRoleBean {

    // 角色名称
    private String name;

    // 角色备注
    private String notes;

    // 该角色名下是否有员工
    private Boolean hasUser;

    // 主键id
    private Long id;

    // 数据是否有效
    private Integer valid;

    // 记录创建时间
    private Date createTime;

    // 记录更新时间
    private Date updateTime;

    private List<Long> ids;
}
