package com.spz.demo.singleboot.controller.system;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.spz.demo.singleboot.bean.SysApiBean;
import com.spz.demo.singleboot.bean.SysDictBean;
import com.spz.demo.singleboot.bean.SysDictTypeBean;
import com.spz.demo.singleboot.constant.DictTypeCodeConstant;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.service.SysApiService;
import com.spz.demo.singleboot.service.SysDictService;
import com.spz.demo.singleboot.service.SysDictTypeService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import sun.rmi.runtime.Log;

import java.util.HashMap;
import java.util.List;

/**
 * 系统接口 控制器
 */
@RestController
@RequestMapping("/sys/api")
public class SysApiController {

    private final SysApiService apiService;
    private final SysDictService dictService;
    public SysApiController(SysApiService apiService, SysDictService dictService) {
        this.apiService = apiService;
        this.dictService = dictService;
    }
    
    /**
     * 分页查询
     * @param bean
     * @return
     */
    @RequestMapping("/listPage")
    public RestBean listPage(SysApiBean bean, PageBean pageBean){
        Page<SysApiBean> page = apiService.findPage(bean,pageBean);
        if(page == null || CollectionUtils.isEmpty(page.getRecords())) return RestBean.ok(new Page<>());

        // 所有字典值
        HashMap<String, SysDictBean> allDictMap = dictService.findAllDictByType(DictTypeCodeConstant.SYSTEM_MODULE);

        page.getRecords().forEach(item -> {
            // 设置字典值描述
            if(allDictMap.get(item.getModule()) != null){
                item.setModuleDesc(allDictMap.get(item.getModule()).getName());
            }
        });

        return RestBean.ok(page);
    }

    /**
     * 查看详情
     * @param id
     * @return
     */
    @RequestMapping("/detail")
    public RestBean detail(Long id){
        SysApiBean bean = apiService.findOne(SysApiBean.builder()
                .id(id).valid(DataValid.VALID)
                .build());
        return RestBean.ok(bean);
    }

    /**
     * 新增一条记录
     * @param bean
     * @return
     */
    @RequestMapping("/add")
    public RestBean add(SysApiBean bean){
        return RestBean.ok(apiService.add(bean));
    }

    /**
     * 根据id更新一条记录
     * @param bean
     * @return
     */
    @RequestMapping("/update")
    public RestBean update(SysApiBean bean){
        if(bean == null || bean.getId() == null) return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        return RestBean.ok(apiService.update(bean));
    }

    /**
     * 根据id删除记录
     * @param bean 可传入id集合
     * @return
     */
    @RequestMapping("/deleteById")
    public RestBean deleteById(SysApiBean bean){
        // 不传入id不允许删除
        if(bean == null || (bean.getId() == null && CollectionUtils.isEmpty(bean.getIds()))){
            return RestBean.error(RestCode.DEFAULT_PARAMS_ERROR);
        }
        return apiService.delete(bean);
    }
}
