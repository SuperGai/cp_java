package com.spz.demo.singleboot.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.spz.demo.singleboot.entity.SysUser;
import com.spz.demo.singleboot.entity.SysUserRole;
import org.springframework.stereotype.Repository;

@Repository
public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {
}
