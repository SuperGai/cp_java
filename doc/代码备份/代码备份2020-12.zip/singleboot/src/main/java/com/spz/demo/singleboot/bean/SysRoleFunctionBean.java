package com.spz.demo.singleboot.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * 系统角色与功能对应表
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SysRoleFunctionBean {

    // 角色id
    private Long roleId;

    // 功能id
    private Long functionId;

    // 主键id
    private Long id;

    // 数据是否有效
    private Integer valid;

    // 记录创建时间
    private Date createTime;

    // 记录更新时间
    private Date updateTime;

    // 角色id集合
    private List<Long> roleIdList;

    // 功能id集合
    private List<Long> functionIdList;
}
