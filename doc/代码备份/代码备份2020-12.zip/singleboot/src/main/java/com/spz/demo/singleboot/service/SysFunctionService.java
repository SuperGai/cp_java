package com.spz.demo.singleboot.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.spz.demo.singleboot.bean.SysFunctionBean;
import com.spz.demo.singleboot.core.baen.PageBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.entity.SysFunction;
import java.util.List;

public interface SysFunctionService extends IService<SysFunction> {

    /**
     * 根据id获取列表
     * @param ids
     * @return
     */
    List<SysFunctionBean> findByIds(List<Long> ids);

    /**
     * 查询列表
     * @param bean
     * @return
     */
    List<SysFunctionBean> findList(SysFunctionBean bean);

    /**
     * 分页查询
     * @param bean
     * @param pageBean
     * @return
     */
    Page<SysFunctionBean> findPage(SysFunctionBean bean, PageBean pageBean);

    /**
     * 检查是否有重复记录
     * @param bean
     * @return
     */
    Boolean repetition(SysFunctionBean bean);

    /**
     * 添加一条记录
     * @param bean
     * @return
     */
    SysFunctionBean add(SysFunctionBean bean);

    /**
     * 根据id更新一条记录
     * @param bean
     * @return
     */
    RestBean update(SysFunctionBean bean);

    /**
     * 删除多条记录
     * @param bean
     * @return
     */
    RestBean delete(SysFunctionBean bean);

    /**
     * 详情
     * @param bean
     * @return
     */
    SysFunctionBean findOne(SysFunctionBean bean);
}
