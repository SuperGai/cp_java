package com.spz.demo.singleboot.core.controller;

import com.spz.demo.singleboot.bean.SysUserBean;
import com.spz.demo.singleboot.core.baen.JwtTokenBean;
import com.spz.demo.singleboot.core.baen.RestBean;
import com.spz.demo.singleboot.core.constant.DataValid;
import com.spz.demo.singleboot.core.constant.RestCode;
import com.spz.demo.singleboot.core.jwt.JwtService;
import com.spz.demo.singleboot.service.SysUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 控制层基类
 */
@Slf4j
@Component
public class BasicController {

    private final JwtService jwtService;
    private final SysUserService sysUserService;

    public BasicController(JwtService jwtService, SysUserService sysUserService) {
        this.jwtService = jwtService;
        this.sysUserService = sysUserService;
    }

    /**
     * 获取登录用户信息
     * 解析token
     * @return
     */
    public SysUserBean getLoginUser(String token){
        RestBean parseJwtRestBean = jwtService.parseJwt(token);
        if(parseJwtRestBean.getCode() != RestCode.DEFAULT_SUCCESS.getCode()){
            log.error("获取登录用户信息失败，token解析失败：" + parseJwtRestBean);
            return null;
        }
        JwtTokenBean jwtTokenBean = (JwtTokenBean) parseJwtRestBean.getData();
        if(jwtTokenBean == null) return null;

        Long userId = Long.valueOf(jwtTokenBean.getId());

        SysUserBean userBean = sysUserService.findOne(SysUserBean.builder()
                .id(userId).valid(DataValid.VALID)
                .build());
        if(userBean != null) userBean.setPassword("");

        return userBean;
    }

}
