package com.spz.demo.singleboot.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.spz.demo.singleboot.entity.SysDict;
import com.spz.demo.singleboot.entity.SysUser;
import org.springframework.stereotype.Repository;

@Repository
public interface SysDictMapper extends BaseMapper<SysDict> {
}
