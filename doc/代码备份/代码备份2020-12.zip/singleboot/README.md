


* 权限管理
  * 不使用Shiro
  * 数据结构：
    - 用户 - 角色 - 功能 - 接口api
      - 功能、接口均携带模块字段（从字典表里获取），模块字段主要用于方便查看，分类
      - 每个功能里包含多条接口api记录
    - 用户 - 角色 - 菜单
    
  * 根据权限显示隐藏按钮
    前端使用v-if以及isUrlPermit方法实现此功能
  * 后台对权限的校验
    对需要进行权限校验的控制层方法，使用@Permission注解来标注，AOP将对有此注解的方法进行登录校验和权限校验
    AOP登录校验和权限校验时，会从token里解析出该用户有权限的接口url集合，然后在里面查找是否包含了当前请求url，不包含则说明没有权限
  * 如何配置权限
    * 开发者
      - 在字典表里配置模块类型（方便增加接口url时配置模块名称）
      - 配置接口url列表
      - 在前端代码里对相应按钮添加v-if根据权限显示隐藏
    * 使用者
      - 增加角色
      - 在字典表里配置模块类型（方便增加功能时配置模块名称）
      - 增加功能
      - 配置该角色所拥有的功能列表
      - 配置该功能所拥有的url接口列表
   
## 技术点
### 权限相关(shiro、jwt token)
* 登录成功下发jwt token给前端
* 前端每次请求均携带token，后端会自行实现token刷新逻辑
* 前端登录成功后，会请求有权限的菜单树数据和接口url列表数据，通过接口url列表可以控制对应按钮的显示
* 后台Auth拦截器负责token合法性、刷新token和权限校验

### 控制层
* 按模块分包，如com.spz.demo.singleboot.controller.system对应系统设置菜单模块

## 指南
### 权限相关
#### 菜单权限
在 "角色管理 - 菜单权限" 里配置即可
#### 根据接口权限隐藏按钮等标签
本demo拥有此功能但没有用上，如果需要此功能按下列步骤开发即可
* 在"权限管理"菜单里，将需要校验权限的接口信息添加上
* 配置不进行权限校验的接口
  com.spz.demo.singleboot.constant.AllowUrlConstant.getUrlMap
* 在shiro拦截器，取消注释以下代码，使之在每次请求时均校验是否具有权限访问
```java
// 此处取消注释，位置: com.spz.demo.singleboot.core.filter.ShiroLoginFilter.onAccessDenied
// ========== 检查角色&权限 ==========
if(!jwtToken.hasUrl(((HttpServletRequest) request).getRequestURI())){
    ControllerUtil.writeJSONToResponse((HttpServletResponse) response,JSON.toJSONString(
            RestBean.error(RestCode.ROLE_ERROR)
    ));
    log.debug("权限验证未通过");
    return false;
}else{//登录验证通过
    log.debug("权限验证通过");
}
```
* 在需要进行接口权限校验的按钮所在标签，使用以下代码实现按钮根据权限显示隐藏
```vue
<el-button :v-if="this.$GLOBAL.isUrlPermit('api接口url')">编辑</el-button>
```
