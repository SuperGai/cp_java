/*
 Navicat Premium Data Transfer

 Source Server         : 本机
 Source Server Type    : MySQL
 Source Server Version : 50727
 Source Host           : localhost:3306
 Source Schema         : singleboot

 Target Server Type    : MySQL
 Target Server Version : 50727
 File Encoding         : 65001

 Date: 24/09/2020 15:43:20
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sys_api
-- ----------------------------
DROP TABLE IF EXISTS `sys_api`;
CREATE TABLE `sys_api`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '接口名称',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '接口路径',
  `module` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '所属模块key 取自字典表',
  `module_desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '所属模块名称 取自字典表',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统API接口' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_api
-- ----------------------------
INSERT INTO `sys_api` VALUES (1, 1, '2020-08-20 16:39:27', '2020-08-20 17:53:32', '下拉框菜单列表', '/sys/menu/dropdownList', 'PUBLIC', '公用');
INSERT INTO `sys_api` VALUES (2, 1, '2020-08-20 16:44:52', '2020-08-20 16:46:15', '分页查询菜单', '/sys/menu/listPage', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_api` VALUES (3, 1, '2020-08-20 16:45:30', '2020-08-20 16:46:23', '获取菜单详情', '/sys/menu/detail', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_api` VALUES (4, 1, '2020-08-20 16:46:03', '2020-08-20 16:46:52', '添加菜单记录', '/sys/menu/add', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_api` VALUES (5, 1, '2020-08-20 16:47:09', '2020-08-20 16:47:21', '更新菜单记录', '/sys/menu/update', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_api` VALUES (6, 1, '2020-08-20 16:47:35', '2020-08-20 16:47:58', '删除菜单记录', '/sys/menu/delete', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_api` VALUES (8, 1, '2020-08-25 17:58:03', '2020-08-25 17:58:43', '添加字典记录', '/sys/dict/add', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_api` VALUES (9, 1, '2020-08-25 17:59:12', '2020-08-25 17:59:12', '更新字典记录', '/sys/dict/update', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_api` VALUES (10, 1, '2020-08-25 17:59:34', '2020-08-25 18:00:06', '删除字典记录', '/sys/dict/delete', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_api` VALUES (12, 1, '2020-08-25 18:00:26', '2020-08-25 18:00:29', '获取字典详情', '/sys/dict/detail', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_api` VALUES (13, 1, '2020-08-25 18:00:58', '2020-08-25 18:01:13', '分页查询字典', '/sys/dict/listPage', 'DICT_MANAGE', '字典管理');

-- ----------------------------
-- Table structure for sys_dict
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict`;
CREATE TABLE `sys_dict`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `type_id` bigint(20) NULL DEFAULT NULL COMMENT '字典类型id',
  `keynum` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '字典标识',
  `data` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '字典值',
  `sort` bigint(20) NULL DEFAULT NULL COMMENT '排序',
  `notes` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统字典表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_dict
-- ----------------------------
INSERT INTO `sys_dict` VALUES (1, 1, '2020-08-20 16:43:30', '2020-08-20 16:43:42', 1, 'PUBLIC', '公用', 1, NULL);
INSERT INTO `sys_dict` VALUES (2, 1, '2020-08-20 16:30:57', '2020-08-20 16:43:41', 1, 'MENU_MANAGE', '菜单管理', 2, NULL);
INSERT INTO `sys_dict` VALUES (3, 1, '2020-08-25 17:56:44', '2020-08-25 17:56:56', 1, 'DICT_MANAGE', '字典管理', 3, NULL);
INSERT INTO `sys_dict` VALUES (4, 1, '2020-08-25 17:57:18', '2020-08-25 17:57:18', 1, 'DICT_TYPE_MANAGE', '字典类型管理', 4, NULL);

-- ----------------------------
-- Table structure for sys_dict_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_type`;
CREATE TABLE `sys_dict_type`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '字典类型名称',
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '字典类型标识符',
  `notes` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`, `code`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统字典类型表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_dict_type
-- ----------------------------
INSERT INTO `sys_dict_type` VALUES (1, 1, '2020-08-20 16:30:08', '2020-08-20 16:30:08', '系统模块', 'SYSTEM_MODULE', '用于功能信息和接口信息');

-- ----------------------------
-- Table structure for sys_function
-- ----------------------------
DROP TABLE IF EXISTS `sys_function`;
CREATE TABLE `sys_function`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '接口名称',
  `module` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '所属模块key  取自字典表',
  `module_desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '所属模块名称 取自字典表',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统功能表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_function
-- ----------------------------
INSERT INTO `sys_function` VALUES (1, 1, '2020-08-20 15:35:45', '2020-08-20 16:34:22', '添加记录', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_function` VALUES (2, 1, '2020-08-20 16:34:16', '2020-08-25 18:02:22', '分页查询', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_function` VALUES (3, 1, '2020-08-20 16:34:28', '2020-08-20 16:35:04', '删除记录', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_function` VALUES (4, 1, '2020-08-20 16:34:33', '2020-08-20 16:35:05', '编辑记录', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_function` VALUES (5, 1, '2020-08-20 16:34:56', '2020-08-20 16:35:05', '查看记录', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_function` VALUES (6, 1, '2020-08-25 18:02:11', '2020-08-25 18:02:11', '添加记录', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_function` VALUES (7, 1, '2020-08-25 18:02:18', '2020-08-25 18:02:28', '分页查询', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_function` VALUES (8, 1, '2020-08-25 18:02:36', '2020-08-25 18:02:41', '删除记录', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_function` VALUES (9, 1, '2020-08-25 18:02:52', '2020-08-25 18:02:55', '编辑记录', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_function` VALUES (10, 1, '2020-08-25 18:03:19', '2020-08-25 18:03:23', '查看记录', 'DICT_MANAGE', '字典管理');

-- ----------------------------
-- Table structure for sys_function_api
-- ----------------------------
DROP TABLE IF EXISTS `sys_function_api`;
CREATE TABLE `sys_function_api`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT NULL COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `function_id` bigint(20) NULL DEFAULT NULL COMMENT '系统功能id',
  `api_id` bigint(20) NULL DEFAULT NULL COMMENT '系统接口url id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 25 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统功能与接口url对应表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_function_api
-- ----------------------------
INSERT INTO `sys_function_api` VALUES (1, 1, '2020-08-20 16:44:11', '2020-08-20 16:48:56', 1, 1);
INSERT INTO `sys_function_api` VALUES (2, 1, '2020-08-20 16:48:45', '2020-08-20 17:21:20', 2, 2);
INSERT INTO `sys_function_api` VALUES (3, 1, '2020-08-20 16:48:50', '2020-08-20 17:21:54', 5, 3);
INSERT INTO `sys_function_api` VALUES (4, 1, '2020-08-20 16:48:52', '2020-08-20 17:19:27', 1, 4);
INSERT INTO `sys_function_api` VALUES (5, 1, '2020-08-20 16:49:02', '2020-08-20 17:21:50', 4, 5);
INSERT INTO `sys_function_api` VALUES (6, 1, '2020-08-20 16:49:09', '2020-08-20 17:28:51', 3, 6);
INSERT INTO `sys_function_api` VALUES (7, 1, '2020-08-20 16:49:12', '2020-08-20 17:21:40', 3, 7);
INSERT INTO `sys_function_api` VALUES (9, 1, '2020-08-20 17:27:58', '2020-08-20 17:28:48', 1, 2);
INSERT INTO `sys_function_api` VALUES (10, 1, '2020-08-20 17:28:00', '2020-08-20 17:28:49', 1, 3);
INSERT INTO `sys_function_api` VALUES (11, 1, '2020-08-20 17:53:41', '2020-08-20 17:53:41', 2, 1);
INSERT INTO `sys_function_api` VALUES (12, 1, '2020-08-20 17:53:49', '2020-08-20 17:54:01', 3, 1);
INSERT INTO `sys_function_api` VALUES (13, 1, '2020-08-20 17:53:52', '2020-08-20 17:54:02', 4, 1);
INSERT INTO `sys_function_api` VALUES (14, 1, '2020-08-20 17:53:54', '2020-08-20 17:54:03', 5, 1);
INSERT INTO `sys_function_api` VALUES (15, NULL, '2020-08-25 18:04:51', '2020-08-25 18:04:51', 6, 8);
INSERT INTO `sys_function_api` VALUES (16, NULL, '2020-08-25 18:04:54', '2020-08-25 18:04:54', 6, 13);
INSERT INTO `sys_function_api` VALUES (17, NULL, '2020-08-25 18:05:54', '2020-08-25 18:05:54', 7, 13);
INSERT INTO `sys_function_api` VALUES (18, NULL, '2020-08-25 18:06:19', '2020-08-25 18:06:19', 8, 10);
INSERT INTO `sys_function_api` VALUES (19, NULL, '2020-08-25 18:06:23', '2020-08-25 18:06:23', 8, 13);
INSERT INTO `sys_function_api` VALUES (20, NULL, '2020-08-25 18:06:43', '2020-08-25 18:06:43', 9, 9);
INSERT INTO `sys_function_api` VALUES (21, NULL, '2020-08-25 18:06:45', '2020-08-25 18:06:45', 9, 12);
INSERT INTO `sys_function_api` VALUES (22, NULL, '2020-08-25 18:06:49', '2020-08-25 18:06:49', 9, 13);
INSERT INTO `sys_function_api` VALUES (23, NULL, '2020-08-25 18:07:16', '2020-08-25 18:07:16', 10, 12);
INSERT INTO `sys_function_api` VALUES (24, NULL, '2020-08-25 18:07:20', '2020-08-25 18:07:20', 10, 13);

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '图标',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '访问路径',
  `parent_id` bigint(20) NOT NULL DEFAULT 0 COMMENT '父菜单id',
  `sort` bigint(20) NULL DEFAULT NULL COMMENT '排序',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '菜单名称',
  `notes` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统菜单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES (1, 'el-icon-user', '/system-user/list', 2, 1, '系统用户管理', '系统内置', 1, '2020-07-22 10:14:36', '2020-08-20 17:20:19');
INSERT INTO `sys_menu` VALUES (2, 'el-icon-setting', '/system', 0, 2, '系统设置', '系统内置', 1, '2020-07-22 10:15:33', '2020-08-20 17:20:20');
INSERT INTO `sys_menu` VALUES (3, 'el-icon-collection', '/system-dict/list', 2, 3, '字典管理', '系统内置', 1, '2020-07-22 10:16:11', '2020-08-20 17:20:21');
INSERT INTO `sys_menu` VALUES (4, 'el-icon-s-home', '/home', 0, 1, '首页', '系统内置', 1, '2020-07-22 17:06:40', '2020-08-20 17:20:22');
INSERT INTO `sys_menu` VALUES (5, 'el-icon-info', '/about', 0, 3, '关于', '系统内置', 1, '2020-07-22 17:08:54', '2020-08-20 17:20:23');
INSERT INTO `sys_menu` VALUES (6, 'el-icon-lock', '/system-role/list', 2, 2, '角色管理', '系统内置', 1, '2020-07-30 11:32:33', '2020-08-20 17:20:24');
INSERT INTO `sys_menu` VALUES (7, 'el-icon-menu', '/system-menu/list', 2, 4, '菜单管理', '系统内置', 1, '2020-08-04 09:35:05', '2020-08-20 17:20:26');

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '角色名称',
  `notes` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '角色备注',
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统角色表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, '超级管理员', '备注123', 1, '2020-07-24 16:28:24', '2020-08-03 17:22:26');

-- ----------------------------
-- Table structure for sys_role_function
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_function`;
CREATE TABLE `sys_role_function`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `function_id` bigint(20) NULL DEFAULT NULL COMMENT '系统功能id',
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统角色与功能对应表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role_function
-- ----------------------------
INSERT INTO `sys_role_function` VALUES (3, 1, '2020-08-26 17:28:30', '2020-08-26 17:28:48', 6, 1);
INSERT INTO `sys_role_function` VALUES (4, 1, '2020-08-26 17:28:52', '2020-08-26 17:28:52', 7, 1);
INSERT INTO `sys_role_function` VALUES (5, 1, '2020-08-26 17:28:58', '2020-08-26 17:28:58', 8, 1);
INSERT INTO `sys_role_function` VALUES (6, 1, '2020-08-26 17:29:02', '2020-08-26 17:29:02', 9, 1);
INSERT INTO `sys_role_function` VALUES (7, 1, '2020-08-26 17:29:10', '2020-08-26 17:29:10', 10, 1);

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `menu_id` bigint(20) NULL DEFAULT NULL COMMENT '菜单id',
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统角色与菜单对应表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES (1, 0, '2020-08-20 14:50:35', '2020-08-20 17:14:51', 7, 1);
INSERT INTO `sys_role_menu` VALUES (2, 0, '2020-08-20 15:18:49', '2020-08-20 17:14:51', 6, 1);
INSERT INTO `sys_role_menu` VALUES (3, 0, '2020-08-20 15:18:57', '2020-08-20 17:14:51', 5, 1);
INSERT INTO `sys_role_menu` VALUES (4, 0, '2020-08-20 15:19:16', '2020-08-20 17:14:51', 4, 1);
INSERT INTO `sys_role_menu` VALUES (5, 0, '2020-08-20 15:19:20', '2020-08-20 17:14:51', 3, 1);
INSERT INTO `sys_role_menu` VALUES (6, 0, '2020-08-20 15:19:23', '2020-08-20 17:14:51', 2, 1);
INSERT INTO `sys_role_menu` VALUES (7, 0, '2020-08-20 15:19:25', '2020-08-20 17:14:51', 1, 1);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `id` bigint(20) NOT NULL,
  `valid` tinyint(1) NOT NULL COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '记录创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '记录更新时间',
  `account` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '账号',
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '密码',
  `salt` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '用于加密密码的盐',
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '手机号',
  `status` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '状态',
  `approve_status` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '审核状态',
  `approve_result` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '审核结果',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '' COMMENT '用户名',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 1, '2020-07-24 09:11:06', '2020-08-03 16:27:35', 'zhangsan', 'E10ADC3949BA59ABBE56E057F20F883E', 'zcuwe', '13000989890', '1', '2', '2', '张三');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT NULL COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `user_id` bigint(20) NOT NULL COMMENT '用户id',
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统用户与角色对应表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES (1, 1, '2020-07-24 16:28:56', '2020-07-24 16:28:56', 1, 1);

SET FOREIGN_KEY_CHECKS = 1;
