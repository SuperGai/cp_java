/*
 Navicat Premium Data Transfer

 Source Server         : 本机
 Source Server Type    : MySQL
 Source Server Version : 50727
 Source Host           : localhost:3306
 Source Schema         : singleboot

 Target Server Type    : MySQL
 Target Server Version : 50727
 File Encoding         : 65001

 Date: 10/10/2020 18:17:12
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sys_api
-- ----------------------------
DROP TABLE IF EXISTS `sys_api`;
CREATE TABLE `sys_api`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '接口名称',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '接口路径',
  `module` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '所属模块key 取自字典表',
  `module_desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '所属模块名称 取自字典表',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 53 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统API接口' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_api
-- ----------------------------
INSERT INTO `sys_api` VALUES (1, 1, '2020-08-20 16:39:27', '2020-10-10 15:20:03', '菜单下拉框列表', '/sys/menu/dropdownList', 'PUBLIC', '公用');
INSERT INTO `sys_api` VALUES (2, 1, '2020-08-20 16:44:52', '2020-08-20 16:46:15', '分页查询菜单', '/sys/menu/listPage', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_api` VALUES (3, 1, '2020-08-20 16:45:30', '2020-08-20 16:46:23', '获取菜单详情', '/sys/menu/detail', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_api` VALUES (4, 1, '2020-08-20 16:46:03', '2020-08-20 16:46:52', '添加菜单记录', '/sys/menu/add', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_api` VALUES (5, 1, '2020-08-20 16:47:09', '2020-08-20 16:47:21', '更新菜单记录', '/sys/menu/update', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_api` VALUES (6, 1, '2020-08-20 16:47:35', '2020-10-10 14:45:46', '根据id删除菜单记录', '/sys/menu/deleteById', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_api` VALUES (8, 1, '2020-08-25 17:58:03', '2020-08-25 17:58:43', '添加字典记录', '/sys/dict/add', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_api` VALUES (9, 1, '2020-08-25 17:59:12', '2020-08-25 17:59:12', '更新字典记录', '/sys/dict/update', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_api` VALUES (10, 1, '2020-08-25 17:59:34', '2020-10-10 14:45:58', '根据id删除字典记录', '/sys/dict/deleteById', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_api` VALUES (12, 1, '2020-08-25 18:00:26', '2020-08-25 18:00:29', '获取字典详情', '/sys/dict/detail', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_api` VALUES (13, 1, '2020-08-25 18:00:58', '2020-08-25 18:01:13', '分页查询字典', '/sys/dict/listPage', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_api` VALUES (14, 0, '2020-09-27 17:29:37', '2020-09-27 17:30:07', '123', '1232222', 'PUBLIC', '22');
INSERT INTO `sys_api` VALUES (15, 0, '2020-09-27 17:30:11', '2020-09-27 17:30:31', '1', '1', 'MENU_MANAGE', '1');
INSERT INTO `sys_api` VALUES (16, 0, '2020-09-27 17:30:16', '2020-09-27 17:30:31', '2', '2', 'DICT_TYPE_MANAGE', '3');
INSERT INTO `sys_api` VALUES (17, 1, '2020-10-10 10:02:09', '2020-10-10 10:02:09', '分页查询字典类型', '/sys/dict/type/listPage', 'DICT_TYPE_MANAGE', '字典类型管理');
INSERT INTO `sys_api` VALUES (18, 1, '2020-10-10 10:03:53', '2020-10-10 10:04:05', '字典类型下拉框列表', '/sys/dict/type/dropdownList', 'PUBLIC', '公用');
INSERT INTO `sys_api` VALUES (19, 1, '2020-10-10 10:04:58', '2020-10-10 10:04:58', '获取字典类型详情', '/sys/dict/type/detail', 'DICT_TYPE_MANAGE', '字典类型管理');
INSERT INTO `sys_api` VALUES (20, 1, '2020-10-10 10:05:46', '2020-10-10 10:05:46', '添加字典类型记录', '/sys/dict/type/add', 'DICT_TYPE_MANAGE', '字典类型管理');
INSERT INTO `sys_api` VALUES (21, 1, '2020-10-10 10:06:39', '2020-10-10 10:06:39', '更新字典类型记录', '/sys/dict/type/update', 'DICT_TYPE_MANAGE', '字典类型管理');
INSERT INTO `sys_api` VALUES (22, 1, '2020-10-10 10:08:07', '2020-10-10 14:46:12', '根据id删除字典类型记录', '/sys/dict/type/deleteById', 'DICT_TYPE_MANAGE', '字典类型管理');
INSERT INTO `sys_api` VALUES (23, 0, '2020-10-10 11:16:15', '2020-10-10 11:21:29', '1', '1', 'PUBLIC', '1');
INSERT INTO `sys_api` VALUES (24, 0, '2020-10-10 11:16:20', '2020-10-10 11:21:12', '2', '2', 'PUBLIC', '2');
INSERT INTO `sys_api` VALUES (25, 1, '2020-10-10 14:44:31', '2020-10-10 14:44:31', '添加角色', '/sys/role/add', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_api` VALUES (26, 1, '2020-10-10 14:44:51', '2020-10-10 14:44:51', '更新角色', '/sys/role/update', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_api` VALUES (27, 1, '2020-10-10 14:45:28', '2020-10-10 14:45:28', '根据id删除角色', '/sys/role/deleteById', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_api` VALUES (28, 1, '2020-10-10 15:15:50', '2020-10-10 15:15:50', '分页查询角色', '/sys/role/listPage', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_api` VALUES (29, 1, '2020-10-10 15:16:37', '2020-10-10 15:16:37', '查看角色详情', '/sys/role/detail', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_api` VALUES (30, 1, '2020-10-10 15:17:30', '2020-10-10 15:17:30', '添加功能', '/sys/function/add', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_api` VALUES (31, 1, '2020-10-10 15:17:47', '2020-10-10 15:17:47', '更新功能', '/sys/function/update', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_api` VALUES (32, 1, '2020-10-10 15:18:07', '2020-10-10 15:18:07', '查看功能详情', '/sys/function/detail', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_api` VALUES (33, 1, '2020-10-10 15:18:49', '2020-10-10 15:18:58', '根据id删除功能', '/sys/function/deleteById', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_api` VALUES (34, 1, '2020-10-10 15:19:29', '2020-10-10 15:19:29', '分页查询功能', '/sys/function/listPage', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_api` VALUES (35, 1, '2020-10-10 15:20:35', '2020-10-10 15:20:35', '功能下拉框列表', '/sys/function/dropdownList', 'PUBLIC', '公用');
INSERT INTO `sys_api` VALUES (36, 1, '2020-10-10 15:22:31', '2020-10-10 15:22:31', '分页查询接口', '/sys/api/listPage', 'API_MANAGE', '接口管理');
INSERT INTO `sys_api` VALUES (37, 1, '2020-10-10 15:22:58', '2020-10-10 15:22:58', '添加接口', '/sys/api/add', 'API_MANAGE', '接口管理');
INSERT INTO `sys_api` VALUES (38, 1, '2020-10-10 15:23:16', '2020-10-10 15:23:16', '更新接口', '/sys/api/update', 'API_MANAGE', '接口管理');
INSERT INTO `sys_api` VALUES (39, 1, '2020-10-10 15:23:36', '2020-10-10 15:25:13', '根据id删除接口', '/sys/api/deleteById', 'API_MANAGE', '接口管理');
INSERT INTO `sys_api` VALUES (40, 1, '2020-10-10 15:24:51', '2020-10-10 15:24:51', '查看接口详情', '/sys/api/detail', 'API_MANAGE', '接口管理');
INSERT INTO `sys_api` VALUES (41, 1, '2020-10-10 15:26:08', '2020-10-10 15:26:08', '添加用户', '/sys/user/add', 'USER_MANAGE', '用户管理');
INSERT INTO `sys_api` VALUES (42, 1, '2020-10-10 15:26:33', '2020-10-10 15:26:33', '根据id删除用户', '/sys/user/deleteById', 'USER_MANAGE', '用户管理');
INSERT INTO `sys_api` VALUES (43, 1, '2020-10-10 15:27:51', '2020-10-10 15:27:51', '更新用户', '/sys/user/update', 'USER_MANAGE', '用户管理');
INSERT INTO `sys_api` VALUES (44, 1, '2020-10-10 15:28:45', '2020-10-10 15:28:45', '分页查询用户', '/sys/user/listPage', 'USER_MANAGE', '用户管理');
INSERT INTO `sys_api` VALUES (45, 1, '2020-10-10 16:55:26', '2020-10-10 16:55:43', '获取用户详情', '/sys/user/detail', 'USER_MANAGE', '用户管理');
INSERT INTO `sys_api` VALUES (46, 1, '2020-10-10 17:03:44', '2020-10-10 17:03:44', '获取功能接口树', '/sys/function/api/tree', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_api` VALUES (47, 1, '2020-10-10 17:04:16', '2020-10-10 17:04:16', '更新功能接口树', '/sys/function/api/tree/update', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_api` VALUES (48, 1, '2020-10-10 17:27:42', '2020-10-10 17:27:42', '字典下拉框', '/sys/dict/dropdownList', 'PUBLIC', '公用');
INSERT INTO `sys_api` VALUES (49, 1, '2020-10-10 17:34:55', '2020-10-10 17:34:55', '更新角色菜单树', '/sys/role/menu/tree/update', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_api` VALUES (50, 1, '2020-10-10 17:35:21', '2020-10-10 17:35:21', '更新角色功能树', '/sys/role/function/tree/update', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_api` VALUES (51, 1, '2020-10-10 18:05:29', '2020-10-10 18:05:29', '获取角色菜单树', '/sys/role/menu/tree', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_api` VALUES (52, 1, '2020-10-10 18:06:14', '2020-10-10 18:08:55', '获取角色功能树', '/sys/role/function/tree', 'ROLE_MANAGE', '角色管理');

-- ----------------------------
-- Table structure for sys_dict
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict`;
CREATE TABLE `sys_dict`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `type_id` bigint(20) NULL DEFAULT NULL COMMENT '字典类型id',
  `keynum` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '字典标识',
  `data` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '字典值',
  `sort` bigint(20) NULL DEFAULT NULL COMMENT '排序',
  `notes` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统字典表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_dict
-- ----------------------------
INSERT INTO `sys_dict` VALUES (1, 1, '2020-08-20 16:43:30', '2020-09-27 10:46:00', 1, 'PUBLIC', '1', 1, '公用');
INSERT INTO `sys_dict` VALUES (2, 1, '2020-08-20 16:30:57', '2020-09-27 10:46:01', 1, 'MENU_MANAGE', '2', 2, '菜单管理');
INSERT INTO `sys_dict` VALUES (3, 1, '2020-08-25 17:56:44', '2020-09-27 10:46:02', 1, 'DICT_MANAGE', '3', 3, '字典管理');
INSERT INTO `sys_dict` VALUES (4, 1, '2020-08-25 17:57:18', '2020-09-27 10:46:06', 1, 'DICT_TYPE_MANAGE', '4', 4, '字典类型管理');
INSERT INTO `sys_dict` VALUES (5, 1, '2020-10-10 09:55:53', '2020-10-10 09:55:53', 1, 'USER_MANAGE', '5', 5, '用户管理');
INSERT INTO `sys_dict` VALUES (6, 1, '2020-10-10 09:56:11', '2020-10-10 09:56:11', 1, 'ROLE_MANAGE', '6', 6, '角色管理');
INSERT INTO `sys_dict` VALUES (7, 1, '2020-10-10 09:56:37', '2020-10-10 09:56:37', 1, 'FUNCTION_MANAGE', '7', 7, '功能管理');
INSERT INTO `sys_dict` VALUES (8, 1, '2020-10-10 09:57:05', '2020-10-10 09:57:05', 1, 'API_MANAGE', '8', 8, '接口管理');

-- ----------------------------
-- Table structure for sys_dict_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_type`;
CREATE TABLE `sys_dict_type`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '字典类型名称',
  `code` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '字典类型标识符',
  `notes` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`, `code`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统字典类型表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_dict_type
-- ----------------------------
INSERT INTO `sys_dict_type` VALUES (1, 1, '2020-08-20 16:30:08', '2020-08-20 16:30:08', '系统模块', 'SYSTEM_MODULE', '用于功能信息和接口信息');

-- ----------------------------
-- Table structure for sys_function
-- ----------------------------
DROP TABLE IF EXISTS `sys_function`;
CREATE TABLE `sys_function`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '接口名称',
  `module` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '所属模块key  取自字典表',
  `module_desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '所属模块名称 取自字典表',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 50 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统功能表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_function
-- ----------------------------
INSERT INTO `sys_function` VALUES (1, 1, '2020-08-20 15:35:45', '2020-10-10 17:51:44', '添加记录', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_function` VALUES (2, 1, '2020-08-20 16:34:16', '2020-08-25 18:02:22', '分页查询', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_function` VALUES (3, 1, '2020-08-20 16:34:28', '2020-08-20 16:35:04', '删除记录', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_function` VALUES (4, 1, '2020-08-20 16:34:33', '2020-08-20 16:35:05', '编辑记录', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_function` VALUES (5, 1, '2020-08-20 16:34:56', '2020-08-20 16:35:05', '查看记录', 'MENU_MANAGE', '菜单管理');
INSERT INTO `sys_function` VALUES (6, 1, '2020-08-25 18:02:11', '2020-08-25 18:02:11', '添加记录', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_function` VALUES (7, 1, '2020-08-25 18:02:18', '2020-08-25 18:02:28', '分页查询', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_function` VALUES (8, 1, '2020-08-25 18:02:36', '2020-08-25 18:02:41', '删除记录', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_function` VALUES (9, 1, '2020-08-25 18:02:52', '2020-08-25 18:02:55', '编辑记录', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_function` VALUES (10, 1, '2020-08-25 18:03:19', '2020-08-25 18:03:23', '查看记录', 'DICT_MANAGE', '字典管理');
INSERT INTO `sys_function` VALUES (11, 0, '2020-09-27 14:44:39', '2020-09-27 14:44:43', '1', 'PUBLIC', '12');
INSERT INTO `sys_function` VALUES (12, 0, '2020-09-27 14:44:47', '2020-09-27 14:44:50', '1', 'PUBLIC', '1');
INSERT INTO `sys_function` VALUES (13, 0, '2020-09-27 14:44:54', '2020-09-27 14:45:02', '1', 'PUBLIC', '1');
INSERT INTO `sys_function` VALUES (14, 0, '2020-09-27 14:44:57', '2020-09-27 14:45:02', '2', 'PUBLIC', '3');
INSERT INTO `sys_function` VALUES (15, 0, '2020-09-27 14:50:14', '2020-09-27 14:50:23', '1', 'PUBLIC', '1');
INSERT INTO `sys_function` VALUES (16, 0, '2020-09-27 14:50:19', '2020-09-27 14:50:23', '2', 'PUBLIC', '1');
INSERT INTO `sys_function` VALUES (17, 0, '2020-09-27 14:51:21', '2020-09-27 14:51:38', '2', 'MENU_MANAGE', '1');
INSERT INTO `sys_function` VALUES (18, 0, '2020-09-28 10:12:21', '2020-10-10 10:09:37', '1', 'DICT_MANAGE', '1');
INSERT INTO `sys_function` VALUES (19, 0, '2020-10-10 10:08:27', '2020-10-10 10:09:37', '2', 'MENU_MANAGE', '12');
INSERT INTO `sys_function` VALUES (20, 0, '2020-10-10 11:16:25', '2020-10-10 11:19:14', '1', 'PUBLIC', '1');
INSERT INTO `sys_function` VALUES (21, 0, '2020-10-10 11:21:02', '2020-10-10 11:21:47', '1', 'PUBLIC', '1');
INSERT INTO `sys_function` VALUES (22, 1, '2020-10-10 16:49:54', '2020-10-10 16:49:54', '添加记录', 'DICT_TYPE_MANAGE', '字典类型管理');
INSERT INTO `sys_function` VALUES (23, 1, '2020-10-10 16:50:14', '2020-10-10 16:50:14', '分页查询', 'DICT_TYPE_MANAGE', '字典类型管理');
INSERT INTO `sys_function` VALUES (24, 1, '2020-10-10 16:50:28', '2020-10-10 16:50:28', '删除记录', 'DICT_TYPE_MANAGE', '字典类型管理');
INSERT INTO `sys_function` VALUES (25, 1, '2020-10-10 16:50:52', '2020-10-10 16:50:52', '编辑记录', 'DICT_TYPE_MANAGE', '字典类型管理');
INSERT INTO `sys_function` VALUES (26, 1, '2020-10-10 16:51:07', '2020-10-10 16:51:07', '查看记录', 'DICT_TYPE_MANAGE', '字典类型管理');
INSERT INTO `sys_function` VALUES (27, 1, '2020-10-10 16:53:03', '2020-10-10 16:53:03', '分页查询', 'USER_MANAGE', '用户管理');
INSERT INTO `sys_function` VALUES (28, 1, '2020-10-10 16:53:13', '2020-10-10 16:53:13', '添加记录', 'USER_MANAGE', '用户管理');
INSERT INTO `sys_function` VALUES (29, 1, '2020-10-10 16:53:30', '2020-10-10 16:53:30', '删除记录', 'USER_MANAGE', '用户管理');
INSERT INTO `sys_function` VALUES (30, 1, '2020-10-10 16:53:41', '2020-10-10 16:53:41', '编辑记录', 'USER_MANAGE', '用户管理');
INSERT INTO `sys_function` VALUES (31, 1, '2020-10-10 16:53:55', '2020-10-10 16:53:55', '查看记录', 'USER_MANAGE', '用户管理');
INSERT INTO `sys_function` VALUES (32, 1, '2020-10-10 16:56:45', '2020-10-10 16:56:45', '添加记录', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_function` VALUES (33, 1, '2020-10-10 16:56:56', '2020-10-10 16:56:56', '删除记录', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_function` VALUES (34, 1, '2020-10-10 16:57:32', '2020-10-10 16:57:32', '编辑记录', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_function` VALUES (35, 1, '2020-10-10 16:57:50', '2020-10-10 16:57:50', '查看记录', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_function` VALUES (36, 1, '2020-10-10 16:58:01', '2020-10-10 16:58:01', '分页查询', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_function` VALUES (37, 1, '2020-10-10 16:59:23', '2020-10-10 16:59:23', '分页查询', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_function` VALUES (38, 1, '2020-10-10 16:59:36', '2020-10-10 16:59:36', '添加记录', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_function` VALUES (39, 1, '2020-10-10 16:59:53', '2020-10-10 16:59:53', '删除记录', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_function` VALUES (40, 1, '2020-10-10 17:00:08', '2020-10-10 17:00:08', '编辑记录', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_function` VALUES (41, 1, '2020-10-10 17:00:26', '2020-10-10 17:00:26', '查看记录', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_function` VALUES (42, 1, '2020-10-10 17:07:08', '2020-10-10 17:07:08', '接口配置', 'FUNCTION_MANAGE', '功能管理');
INSERT INTO `sys_function` VALUES (43, 1, '2020-10-10 17:09:32', '2020-10-10 17:09:32', '添加记录', 'API_MANAGE', '接口管理');
INSERT INTO `sys_function` VALUES (44, 1, '2020-10-10 17:09:41', '2020-10-10 17:09:41', '删除记录', 'API_MANAGE', '接口管理');
INSERT INTO `sys_function` VALUES (45, 1, '2020-10-10 17:09:50', '2020-10-10 17:09:50', '编辑记录', 'API_MANAGE', '接口管理');
INSERT INTO `sys_function` VALUES (46, 1, '2020-10-10 17:10:03', '2020-10-10 17:10:03', '查看记录', 'API_MANAGE', '接口管理');
INSERT INTO `sys_function` VALUES (47, 1, '2020-10-10 17:10:26', '2020-10-10 17:10:26', '分页查询', 'API_MANAGE', '接口管理');
INSERT INTO `sys_function` VALUES (48, 1, '2020-10-10 17:32:27', '2020-10-10 17:32:27', '角色功能配置', 'ROLE_MANAGE', '角色管理');
INSERT INTO `sys_function` VALUES (49, 1, '2020-10-10 17:32:46', '2020-10-10 17:32:46', '角色菜单配置', 'ROLE_MANAGE', '角色管理');

-- ----------------------------
-- Table structure for sys_function_api
-- ----------------------------
DROP TABLE IF EXISTS `sys_function_api`;
CREATE TABLE `sys_function_api`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `function_id` bigint(20) NULL DEFAULT NULL COMMENT '系统功能id',
  `api_id` bigint(20) NULL DEFAULT NULL COMMENT '系统接口url id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 164 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统功能与接口url对应表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_function_api
-- ----------------------------
INSERT INTO `sys_function_api` VALUES (31, 0, '2020-09-28 11:45:12', '2020-09-28 11:49:41', 18, 2);
INSERT INTO `sys_function_api` VALUES (32, 0, '2020-09-28 11:45:12', '2020-09-28 11:49:41', 18, 8);
INSERT INTO `sys_function_api` VALUES (33, 0, '2020-09-28 11:45:12', '2020-09-28 11:49:41', 18, 13);
INSERT INTO `sys_function_api` VALUES (34, 0, '2020-09-28 11:45:12', '2020-09-28 11:49:41', 18, 10);
INSERT INTO `sys_function_api` VALUES (35, 0, '2020-09-28 11:45:12', '2020-09-28 11:49:41', 18, 9);
INSERT INTO `sys_function_api` VALUES (36, 0, '2020-09-28 11:45:12', '2020-09-28 11:49:41', 18, 12);
INSERT INTO `sys_function_api` VALUES (37, 0, '2020-09-28 11:49:41', '2020-09-28 15:03:48', 18, 2);
INSERT INTO `sys_function_api` VALUES (38, 0, '2020-09-28 11:49:41', '2020-09-28 15:03:48', 18, 5);
INSERT INTO `sys_function_api` VALUES (39, 0, '2020-09-28 11:49:41', '2020-09-28 15:03:48', 18, 6);
INSERT INTO `sys_function_api` VALUES (40, 0, '2020-09-28 11:49:41', '2020-09-28 15:03:48', 18, 8);
INSERT INTO `sys_function_api` VALUES (41, 0, '2020-09-28 11:49:41', '2020-09-28 15:03:48', 18, 9);
INSERT INTO `sys_function_api` VALUES (42, 0, '2020-09-28 11:49:41', '2020-09-28 15:03:48', 18, 10);
INSERT INTO `sys_function_api` VALUES (43, 0, '2020-09-28 15:03:48', '2020-09-28 15:03:56', 18, 1);
INSERT INTO `sys_function_api` VALUES (44, 0, '2020-09-28 15:03:48', '2020-09-28 15:03:56', 18, 2);
INSERT INTO `sys_function_api` VALUES (45, 0, '2020-09-28 15:03:48', '2020-09-28 15:03:56', 18, 3);
INSERT INTO `sys_function_api` VALUES (46, 0, '2020-09-28 15:03:48', '2020-09-28 15:03:56', 18, 4);
INSERT INTO `sys_function_api` VALUES (47, 0, '2020-09-28 15:03:48', '2020-09-28 15:03:56', 18, 5);
INSERT INTO `sys_function_api` VALUES (48, 0, '2020-09-28 15:03:48', '2020-09-28 15:03:56', 18, 6);
INSERT INTO `sys_function_api` VALUES (49, 0, '2020-09-28 15:03:48', '2020-09-28 15:03:56', 18, 8);
INSERT INTO `sys_function_api` VALUES (50, 0, '2020-09-28 15:03:48', '2020-09-28 15:03:56', 18, 9);
INSERT INTO `sys_function_api` VALUES (51, 0, '2020-09-28 15:03:48', '2020-09-28 15:03:56', 18, 10);
INSERT INTO `sys_function_api` VALUES (52, 0, '2020-09-28 15:03:48', '2020-09-28 15:03:56', 18, 12);
INSERT INTO `sys_function_api` VALUES (53, 0, '2020-09-28 15:03:48', '2020-09-28 15:03:56', 18, 13);
INSERT INTO `sys_function_api` VALUES (54, 0, '2020-09-28 15:04:46', '2020-09-28 15:04:53', 18, 2);
INSERT INTO `sys_function_api` VALUES (55, 0, '2020-09-28 15:04:46', '2020-09-28 15:04:53', 18, 9);
INSERT INTO `sys_function_api` VALUES (56, 0, '2020-09-28 15:04:46', '2020-09-28 15:04:53', 18, 10);
INSERT INTO `sys_function_api` VALUES (57, 0, '2020-09-28 15:04:46', '2020-09-28 15:04:53', 18, 12);
INSERT INTO `sys_function_api` VALUES (58, 1, '2020-10-09 16:46:40', '2020-10-09 16:46:40', 18, 1);
INSERT INTO `sys_function_api` VALUES (59, 0, '2020-10-10 11:16:32', '2020-10-10 11:19:14', 20, 23);
INSERT INTO `sys_function_api` VALUES (60, 0, '2020-10-10 11:16:32', '2020-10-10 11:19:14', 20, 24);
INSERT INTO `sys_function_api` VALUES (61, 0, '2020-10-10 11:21:07', '2020-10-10 11:21:47', 21, 23);
INSERT INTO `sys_function_api` VALUES (62, 0, '2020-10-10 11:21:07', '2020-10-10 11:21:47', 21, 24);
INSERT INTO `sys_function_api` VALUES (63, 0, '2020-10-10 15:31:13', '2020-10-10 16:44:00', 1, 4);
INSERT INTO `sys_function_api` VALUES (64, 0, '2020-10-10 15:31:49', '2020-10-10 16:05:08', 2, 1);
INSERT INTO `sys_function_api` VALUES (65, 1, '2020-10-10 15:32:05', '2020-10-10 15:32:05', 3, 1);
INSERT INTO `sys_function_api` VALUES (66, 1, '2020-10-10 15:32:05', '2020-10-10 15:32:05', 3, 6);
INSERT INTO `sys_function_api` VALUES (67, 1, '2020-10-10 15:32:35', '2020-10-10 15:32:35', 4, 1);
INSERT INTO `sys_function_api` VALUES (68, 1, '2020-10-10 15:32:35', '2020-10-10 15:32:35', 4, 3);
INSERT INTO `sys_function_api` VALUES (69, 1, '2020-10-10 15:32:35', '2020-10-10 15:32:35', 4, 5);
INSERT INTO `sys_function_api` VALUES (70, 1, '2020-10-10 15:33:11', '2020-10-10 15:33:11', 5, 1);
INSERT INTO `sys_function_api` VALUES (71, 1, '2020-10-10 15:33:11', '2020-10-10 15:33:11', 5, 3);
INSERT INTO `sys_function_api` VALUES (72, 0, '2020-10-10 16:05:08', '2020-10-10 16:44:31', 2, 1);
INSERT INTO `sys_function_api` VALUES (73, 0, '2020-10-10 16:05:08', '2020-10-10 16:44:31', 2, 2);
INSERT INTO `sys_function_api` VALUES (74, 1, '2020-10-10 16:42:39', '2020-10-10 16:42:39', 6, 18);
INSERT INTO `sys_function_api` VALUES (75, 1, '2020-10-10 16:42:39', '2020-10-10 16:42:39', 6, 8);
INSERT INTO `sys_function_api` VALUES (76, 1, '2020-10-10 16:42:56', '2020-10-10 16:42:56', 7, 18);
INSERT INTO `sys_function_api` VALUES (77, 1, '2020-10-10 16:42:56', '2020-10-10 16:42:56', 7, 13);
INSERT INTO `sys_function_api` VALUES (78, 1, '2020-10-10 16:43:09', '2020-10-10 16:43:09', 8, 18);
INSERT INTO `sys_function_api` VALUES (79, 1, '2020-10-10 16:43:09', '2020-10-10 16:43:09', 8, 10);
INSERT INTO `sys_function_api` VALUES (80, 0, '2020-10-10 16:43:22', '2020-10-10 16:43:41', 9, 9);
INSERT INTO `sys_function_api` VALUES (81, 0, '2020-10-10 16:43:22', '2020-10-10 16:43:41', 9, 12);
INSERT INTO `sys_function_api` VALUES (82, 1, '2020-10-10 16:43:32', '2020-10-10 16:43:32', 10, 12);
INSERT INTO `sys_function_api` VALUES (83, 1, '2020-10-10 16:43:41', '2020-10-10 16:43:41', 9, 18);
INSERT INTO `sys_function_api` VALUES (84, 1, '2020-10-10 16:43:41', '2020-10-10 16:43:41', 9, 9);
INSERT INTO `sys_function_api` VALUES (85, 1, '2020-10-10 16:43:41', '2020-10-10 16:43:41', 9, 12);
INSERT INTO `sys_function_api` VALUES (86, 0, '2020-10-10 16:46:43', '2020-10-10 16:47:25', 1, 1);
INSERT INTO `sys_function_api` VALUES (87, 0, '2020-10-10 16:46:43', '2020-10-10 16:47:25', 1, 4);
INSERT INTO `sys_function_api` VALUES (88, 1, '2020-10-10 16:47:03', '2020-10-10 16:47:03', 2, 1);
INSERT INTO `sys_function_api` VALUES (89, 1, '2020-10-10 16:47:03', '2020-10-10 16:47:03', 2, 2);
INSERT INTO `sys_function_api` VALUES (90, 0, '2020-10-10 16:47:25', '2020-10-10 16:47:40', 1, 17);
INSERT INTO `sys_function_api` VALUES (91, 0, '2020-10-10 16:47:25', '2020-10-10 16:47:40', 1, 19);
INSERT INTO `sys_function_api` VALUES (92, 0, '2020-10-10 16:47:25', '2020-10-10 16:47:40', 1, 20);
INSERT INTO `sys_function_api` VALUES (93, 0, '2020-10-10 16:47:25', '2020-10-10 16:47:40', 1, 21);
INSERT INTO `sys_function_api` VALUES (94, 0, '2020-10-10 16:47:25', '2020-10-10 16:47:40', 1, 22);
INSERT INTO `sys_function_api` VALUES (95, 0, '2020-10-10 16:47:25', '2020-10-10 16:47:40', 1, 1);
INSERT INTO `sys_function_api` VALUES (96, 0, '2020-10-10 16:47:25', '2020-10-10 16:47:40', 1, 4);
INSERT INTO `sys_function_api` VALUES (97, 1, '2020-10-10 16:47:40', '2020-10-10 16:47:40', 1, 1);
INSERT INTO `sys_function_api` VALUES (98, 1, '2020-10-10 16:47:40', '2020-10-10 16:47:40', 1, 4);
INSERT INTO `sys_function_api` VALUES (99, 1, '2020-10-10 16:51:39', '2020-10-10 16:51:39', 22, 20);
INSERT INTO `sys_function_api` VALUES (100, 1, '2020-10-10 16:51:39', '2020-10-10 16:51:39', 22, 18);
INSERT INTO `sys_function_api` VALUES (101, 1, '2020-10-10 16:52:02', '2020-10-10 16:52:02', 23, 17);
INSERT INTO `sys_function_api` VALUES (102, 1, '2020-10-10 16:52:02', '2020-10-10 16:52:02', 23, 18);
INSERT INTO `sys_function_api` VALUES (103, 1, '2020-10-10 16:52:14', '2020-10-10 16:52:14', 24, 22);
INSERT INTO `sys_function_api` VALUES (104, 1, '2020-10-10 16:52:33', '2020-10-10 16:52:33', 25, 19);
INSERT INTO `sys_function_api` VALUES (105, 1, '2020-10-10 16:52:33', '2020-10-10 16:52:33', 25, 21);
INSERT INTO `sys_function_api` VALUES (106, 1, '2020-10-10 16:52:33', '2020-10-10 16:52:33', 25, 18);
INSERT INTO `sys_function_api` VALUES (107, 1, '2020-10-10 16:52:43', '2020-10-10 16:52:43', 26, 19);
INSERT INTO `sys_function_api` VALUES (108, 1, '2020-10-10 16:52:43', '2020-10-10 16:52:43', 26, 18);
INSERT INTO `sys_function_api` VALUES (109, 1, '2020-10-10 16:54:10', '2020-10-10 16:54:10', 27, 44);
INSERT INTO `sys_function_api` VALUES (110, 1, '2020-10-10 16:54:22', '2020-10-10 16:54:22', 28, 41);
INSERT INTO `sys_function_api` VALUES (111, 1, '2020-10-10 16:54:32', '2020-10-10 16:54:32', 29, 42);
INSERT INTO `sys_function_api` VALUES (112, 0, '2020-10-10 16:54:58', '2020-10-10 16:56:08', 30, 43);
INSERT INTO `sys_function_api` VALUES (113, 1, '2020-10-10 16:56:08', '2020-10-10 16:56:08', 30, 43);
INSERT INTO `sys_function_api` VALUES (114, 1, '2020-10-10 16:56:08', '2020-10-10 16:56:08', 30, 45);
INSERT INTO `sys_function_api` VALUES (115, 1, '2020-10-10 16:56:19', '2020-10-10 16:56:19', 31, 45);
INSERT INTO `sys_function_api` VALUES (116, 1, '2020-10-10 16:58:30', '2020-10-10 16:58:30', 32, 25);
INSERT INTO `sys_function_api` VALUES (117, 1, '2020-10-10 16:58:37', '2020-10-10 16:58:37', 33, 27);
INSERT INTO `sys_function_api` VALUES (118, 1, '2020-10-10 16:58:44', '2020-10-10 16:58:44', 34, 26);
INSERT INTO `sys_function_api` VALUES (119, 1, '2020-10-10 16:58:44', '2020-10-10 16:58:44', 34, 29);
INSERT INTO `sys_function_api` VALUES (120, 1, '2020-10-10 16:58:49', '2020-10-10 16:58:49', 35, 29);
INSERT INTO `sys_function_api` VALUES (121, 1, '2020-10-10 16:58:57', '2020-10-10 16:58:57', 36, 28);
INSERT INTO `sys_function_api` VALUES (122, 0, '2020-10-10 17:00:47', '2020-10-10 17:07:34', 37, 34);
INSERT INTO `sys_function_api` VALUES (123, 0, '2020-10-10 17:07:34', '2020-10-10 17:28:48', 37, 18);
INSERT INTO `sys_function_api` VALUES (124, 0, '2020-10-10 17:07:34', '2020-10-10 17:28:48', 37, 34);
INSERT INTO `sys_function_api` VALUES (125, 0, '2020-10-10 17:08:00', '2020-10-10 17:29:23', 38, 30);
INSERT INTO `sys_function_api` VALUES (126, 1, '2020-10-10 17:08:16', '2020-10-10 17:08:16', 39, 33);
INSERT INTO `sys_function_api` VALUES (127, 0, '2020-10-10 17:08:29', '2020-10-10 17:29:37', 40, 31);
INSERT INTO `sys_function_api` VALUES (128, 0, '2020-10-10 17:08:29', '2020-10-10 17:29:37', 40, 32);
INSERT INTO `sys_function_api` VALUES (129, 0, '2020-10-10 17:08:40', '2020-10-10 17:29:46', 41, 32);
INSERT INTO `sys_function_api` VALUES (130, 1, '2020-10-10 17:09:04', '2020-10-10 17:09:04', 42, 46);
INSERT INTO `sys_function_api` VALUES (131, 1, '2020-10-10 17:09:04', '2020-10-10 17:09:04', 42, 47);
INSERT INTO `sys_function_api` VALUES (132, 0, '2020-10-10 17:10:59', '2020-10-10 17:30:09', 43, 18);
INSERT INTO `sys_function_api` VALUES (133, 0, '2020-10-10 17:10:59', '2020-10-10 17:30:09', 43, 37);
INSERT INTO `sys_function_api` VALUES (134, 1, '2020-10-10 17:11:07', '2020-10-10 17:11:07', 44, 39);
INSERT INTO `sys_function_api` VALUES (135, 0, '2020-10-10 17:11:25', '2020-10-10 17:30:16', 45, 38);
INSERT INTO `sys_function_api` VALUES (136, 0, '2020-10-10 17:11:25', '2020-10-10 17:30:16', 45, 40);
INSERT INTO `sys_function_api` VALUES (137, 0, '2020-10-10 17:11:33', '2020-10-10 17:30:27', 46, 40);
INSERT INTO `sys_function_api` VALUES (138, 0, '2020-10-10 17:11:43', '2020-10-10 17:30:37', 47, 18);
INSERT INTO `sys_function_api` VALUES (139, 0, '2020-10-10 17:11:43', '2020-10-10 17:30:37', 47, 36);
INSERT INTO `sys_function_api` VALUES (140, 1, '2020-10-10 17:28:48', '2020-10-10 17:28:48', 37, 48);
INSERT INTO `sys_function_api` VALUES (141, 1, '2020-10-10 17:28:48', '2020-10-10 17:28:48', 37, 34);
INSERT INTO `sys_function_api` VALUES (142, 1, '2020-10-10 17:29:23', '2020-10-10 17:29:23', 38, 48);
INSERT INTO `sys_function_api` VALUES (143, 1, '2020-10-10 17:29:23', '2020-10-10 17:29:23', 38, 30);
INSERT INTO `sys_function_api` VALUES (144, 1, '2020-10-10 17:29:37', '2020-10-10 17:29:37', 40, 48);
INSERT INTO `sys_function_api` VALUES (145, 1, '2020-10-10 17:29:37', '2020-10-10 17:29:37', 40, 31);
INSERT INTO `sys_function_api` VALUES (146, 1, '2020-10-10 17:29:37', '2020-10-10 17:29:37', 40, 32);
INSERT INTO `sys_function_api` VALUES (147, 1, '2020-10-10 17:29:46', '2020-10-10 17:29:46', 41, 48);
INSERT INTO `sys_function_api` VALUES (148, 1, '2020-10-10 17:29:46', '2020-10-10 17:29:46', 41, 32);
INSERT INTO `sys_function_api` VALUES (149, 1, '2020-10-10 17:30:09', '2020-10-10 17:30:09', 43, 48);
INSERT INTO `sys_function_api` VALUES (150, 1, '2020-10-10 17:30:09', '2020-10-10 17:30:09', 43, 37);
INSERT INTO `sys_function_api` VALUES (151, 1, '2020-10-10 17:30:16', '2020-10-10 17:30:16', 45, 48);
INSERT INTO `sys_function_api` VALUES (152, 1, '2020-10-10 17:30:16', '2020-10-10 17:30:16', 45, 38);
INSERT INTO `sys_function_api` VALUES (153, 1, '2020-10-10 17:30:16', '2020-10-10 17:30:16', 45, 40);
INSERT INTO `sys_function_api` VALUES (154, 1, '2020-10-10 17:30:27', '2020-10-10 17:30:27', 46, 48);
INSERT INTO `sys_function_api` VALUES (155, 1, '2020-10-10 17:30:27', '2020-10-10 17:30:27', 46, 40);
INSERT INTO `sys_function_api` VALUES (156, 1, '2020-10-10 17:30:37', '2020-10-10 17:30:37', 47, 48);
INSERT INTO `sys_function_api` VALUES (157, 1, '2020-10-10 17:30:37', '2020-10-10 17:30:37', 47, 36);
INSERT INTO `sys_function_api` VALUES (158, 0, '2020-10-10 17:35:39', '2020-10-10 18:07:05', 48, 50);
INSERT INTO `sys_function_api` VALUES (159, 0, '2020-10-10 17:35:48', '2020-10-10 18:07:18', 49, 49);
INSERT INTO `sys_function_api` VALUES (160, 1, '2020-10-10 18:07:05', '2020-10-10 18:07:05', 48, 50);
INSERT INTO `sys_function_api` VALUES (161, 1, '2020-10-10 18:07:05', '2020-10-10 18:07:05', 48, 52);
INSERT INTO `sys_function_api` VALUES (162, 1, '2020-10-10 18:07:18', '2020-10-10 18:07:18', 49, 49);
INSERT INTO `sys_function_api` VALUES (163, 1, '2020-10-10 18:07:18', '2020-10-10 18:07:18', 49, 51);

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `icon` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '图标',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '访问路径',
  `parent_id` bigint(20) NOT NULL DEFAULT 0 COMMENT '父菜单id',
  `sort` bigint(20) NULL DEFAULT NULL COMMENT '排序',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '菜单名称',
  `notes` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '备注',
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统菜单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
INSERT INTO `sys_menu` VALUES (1, 'el-icon-user', '/system-user/list', 2, 1, '用户管理', '系统内置', 1, '2020-07-22 10:14:36', '2020-10-10 17:53:42');
INSERT INTO `sys_menu` VALUES (2, 'el-icon-setting', '/system', 0, 2, '系统设置', '系统内置', 1, '2020-07-22 10:15:33', '2020-08-20 17:20:20');
INSERT INTO `sys_menu` VALUES (3, 'el-icon-collection', '/system-dict/list', 2, 3, '字典管理', '系统内置', 1, '2020-07-22 10:16:11', '2020-08-20 17:20:21');
INSERT INTO `sys_menu` VALUES (4, 'el-icon-s-home', '/home', 0, 1, '首页', '系统内置', 1, '2020-07-22 17:06:40', '2020-08-20 17:20:22');
INSERT INTO `sys_menu` VALUES (5, 'el-icon-info', '/about', 0, 3, '关于', '系统内置', 1, '2020-07-22 17:08:54', '2020-08-20 17:20:23');
INSERT INTO `sys_menu` VALUES (6, 'el-icon-lock', '/system-role/list', 2, 2, '角色管理', '系统内置', 1, '2020-07-30 11:32:33', '2020-08-20 17:20:24');
INSERT INTO `sys_menu` VALUES (7, 'el-icon-menu', '/system-menu/list', 2, 4, '菜单管理', '系统内置', 1, '2020-08-04 09:35:05', '2020-08-20 17:20:26');
INSERT INTO `sys_menu` VALUES (8, NULL, '/system-function/list', 2, 5, '功能管理', '系统内置', 1, '2020-09-27 10:18:44', '2020-09-27 10:18:47');
INSERT INTO `sys_menu` VALUES (9, NULL, '/system-api/list', 2, 6, '接口管理', '系统内置', 1, '2020-09-27 17:27:40', '2020-09-27 17:29:08');
INSERT INTO `sys_menu` VALUES (10, '1', '1', 2, 1, '1', '1', 0, '2020-10-10 16:03:07', '2020-10-10 16:11:31');
INSERT INTO `sys_menu` VALUES (11, '2', '2', 4, 2, '2', '2', 0, '2020-10-10 16:04:12', '2020-10-10 16:17:43');
INSERT INTO `sys_menu` VALUES (12, '5', '3', 0, 1, '3', '6', 0, '2020-10-10 16:21:24', '2020-10-10 16:29:00');

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '角色名称',
  `notes` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '角色备注',
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统角色表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role
-- ----------------------------
INSERT INTO `sys_role` VALUES (1, '超级管理员', '备注123', 1, '2020-07-24 16:28:24', '2020-08-03 17:22:26');

-- ----------------------------
-- Table structure for sys_role_function
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_function`;
CREATE TABLE `sys_role_function`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `function_id` bigint(20) NULL DEFAULT NULL COMMENT '系统功能id',
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 175 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统角色与功能对应表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role_function
-- ----------------------------
INSERT INTO `sys_role_function` VALUES (8, 0, '2020-09-28 15:02:18', '2020-09-28 15:02:28', 1, 1);
INSERT INTO `sys_role_function` VALUES (9, 0, '2020-09-28 15:02:18', '2020-09-28 15:02:28', 3, 1);
INSERT INTO `sys_role_function` VALUES (10, 0, '2020-09-28 15:02:18', '2020-09-28 15:02:28', 8, 1);
INSERT INTO `sys_role_function` VALUES (11, 0, '2020-09-28 15:02:28', '2020-09-28 15:02:32', 1, 1);
INSERT INTO `sys_role_function` VALUES (12, 0, '2020-09-28 15:02:28', '2020-09-28 15:02:32', 3, 1);
INSERT INTO `sys_role_function` VALUES (13, 0, '2020-09-28 15:02:28', '2020-09-28 15:02:32', 8, 1);
INSERT INTO `sys_role_function` VALUES (14, 0, '2020-09-28 15:02:28', '2020-09-28 15:02:32', 18, 1);
INSERT INTO `sys_role_function` VALUES (15, 0, '2020-09-28 15:02:32', '2020-09-28 15:02:34', 1, 1);
INSERT INTO `sys_role_function` VALUES (16, 0, '2020-09-28 15:02:32', '2020-09-28 15:02:34', 3, 1);
INSERT INTO `sys_role_function` VALUES (17, 0, '2020-09-28 15:02:32', '2020-09-28 15:02:34', 6, 1);
INSERT INTO `sys_role_function` VALUES (18, 0, '2020-09-28 15:02:32', '2020-09-28 15:02:34', 7, 1);
INSERT INTO `sys_role_function` VALUES (19, 0, '2020-09-28 15:02:32', '2020-09-28 15:02:34', 8, 1);
INSERT INTO `sys_role_function` VALUES (20, 0, '2020-09-28 15:02:32', '2020-09-28 15:02:34', 9, 1);
INSERT INTO `sys_role_function` VALUES (21, 0, '2020-09-28 15:02:32', '2020-09-28 15:02:34', 10, 1);
INSERT INTO `sys_role_function` VALUES (22, 0, '2020-09-28 15:02:32', '2020-09-28 15:02:34', 18, 1);
INSERT INTO `sys_role_function` VALUES (23, 0, '2020-09-28 15:02:34', '2020-09-28 15:03:32', 1, 1);
INSERT INTO `sys_role_function` VALUES (24, 0, '2020-09-28 15:02:34', '2020-09-28 15:03:32', 2, 1);
INSERT INTO `sys_role_function` VALUES (25, 0, '2020-09-28 15:02:34', '2020-09-28 15:03:32', 3, 1);
INSERT INTO `sys_role_function` VALUES (26, 0, '2020-09-28 15:02:34', '2020-09-28 15:03:32', 4, 1);
INSERT INTO `sys_role_function` VALUES (27, 0, '2020-09-28 15:02:34', '2020-09-28 15:03:32', 5, 1);
INSERT INTO `sys_role_function` VALUES (28, 0, '2020-09-28 15:02:34', '2020-09-28 15:03:32', 6, 1);
INSERT INTO `sys_role_function` VALUES (29, 0, '2020-09-28 15:02:34', '2020-09-28 15:03:32', 7, 1);
INSERT INTO `sys_role_function` VALUES (30, 0, '2020-09-28 15:02:34', '2020-09-28 15:03:32', 8, 1);
INSERT INTO `sys_role_function` VALUES (31, 0, '2020-09-28 15:02:34', '2020-09-28 15:03:32', 9, 1);
INSERT INTO `sys_role_function` VALUES (32, 0, '2020-09-28 15:02:34', '2020-09-28 15:03:32', 10, 1);
INSERT INTO `sys_role_function` VALUES (33, 0, '2020-09-28 15:02:34', '2020-09-28 15:03:32', 18, 1);
INSERT INTO `sys_role_function` VALUES (34, 0, '2020-10-09 16:50:05', '2020-10-09 16:52:19', 1, 1);
INSERT INTO `sys_role_function` VALUES (35, 0, '2020-10-09 16:50:05', '2020-10-09 16:52:19', 2, 1);
INSERT INTO `sys_role_function` VALUES (36, 0, '2020-10-09 16:50:05', '2020-10-09 16:52:19', 3, 1);
INSERT INTO `sys_role_function` VALUES (37, 0, '2020-10-09 16:50:05', '2020-10-09 16:52:19', 4, 1);
INSERT INTO `sys_role_function` VALUES (38, 0, '2020-10-09 16:50:05', '2020-10-09 16:52:19', 5, 1);
INSERT INTO `sys_role_function` VALUES (39, 0, '2020-10-10 09:46:47', '2020-10-10 09:46:50', 1, 1);
INSERT INTO `sys_role_function` VALUES (40, 0, '2020-10-10 09:46:47', '2020-10-10 09:46:50', 6, 1);
INSERT INTO `sys_role_function` VALUES (41, 0, '2020-10-10 09:46:50', '2020-10-10 09:47:49', 1, 1);
INSERT INTO `sys_role_function` VALUES (42, 0, '2020-10-10 09:46:50', '2020-10-10 09:47:49', 6, 1);
INSERT INTO `sys_role_function` VALUES (43, 0, '2020-10-10 09:46:50', '2020-10-10 09:47:49', 18, 1);
INSERT INTO `sys_role_function` VALUES (44, 0, '2020-10-10 09:47:49', '2020-10-10 11:15:11', 6, 1);
INSERT INTO `sys_role_function` VALUES (45, 0, '2020-10-10 09:47:49', '2020-10-10 11:15:11', 7, 1);
INSERT INTO `sys_role_function` VALUES (46, 0, '2020-10-10 09:47:49', '2020-10-10 11:15:11', 8, 1);
INSERT INTO `sys_role_function` VALUES (47, 0, '2020-10-10 09:47:49', '2020-10-10 11:15:11', 9, 1);
INSERT INTO `sys_role_function` VALUES (48, 0, '2020-10-10 09:47:49', '2020-10-10 11:15:11', 10, 1);
INSERT INTO `sys_role_function` VALUES (49, 0, '2020-10-10 09:47:49', '2020-10-10 11:15:11', 18, 1);
INSERT INTO `sys_role_function` VALUES (50, 0, '2020-10-10 11:15:11', '2020-10-10 11:21:40', 1, 1);
INSERT INTO `sys_role_function` VALUES (51, 0, '2020-10-10 11:15:11', '2020-10-10 11:21:40', 2, 1);
INSERT INTO `sys_role_function` VALUES (52, 0, '2020-10-10 11:15:11', '2020-10-10 11:21:40', 3, 1);
INSERT INTO `sys_role_function` VALUES (53, 0, '2020-10-10 11:15:11', '2020-10-10 11:21:40', 4, 1);
INSERT INTO `sys_role_function` VALUES (54, 0, '2020-10-10 11:15:11', '2020-10-10 11:21:40', 5, 1);
INSERT INTO `sys_role_function` VALUES (55, 0, '2020-10-10 11:15:11', '2020-10-10 11:21:40', 6, 1);
INSERT INTO `sys_role_function` VALUES (56, 0, '2020-10-10 11:15:11', '2020-10-10 11:21:40', 7, 1);
INSERT INTO `sys_role_function` VALUES (57, 0, '2020-10-10 11:15:11', '2020-10-10 11:21:40', 8, 1);
INSERT INTO `sys_role_function` VALUES (58, 0, '2020-10-10 11:15:11', '2020-10-10 11:21:40', 9, 1);
INSERT INTO `sys_role_function` VALUES (59, 0, '2020-10-10 11:15:11', '2020-10-10 11:21:40', 10, 1);
INSERT INTO `sys_role_function` VALUES (60, 0, '2020-10-10 11:21:40', '2020-10-10 11:21:47', 21, 1);
INSERT INTO `sys_role_function` VALUES (61, 0, '2020-10-10 11:21:40', '2020-10-10 17:01:10', 1, 1);
INSERT INTO `sys_role_function` VALUES (62, 0, '2020-10-10 11:21:40', '2020-10-10 17:01:10', 2, 1);
INSERT INTO `sys_role_function` VALUES (63, 0, '2020-10-10 11:21:40', '2020-10-10 17:01:10', 3, 1);
INSERT INTO `sys_role_function` VALUES (64, 0, '2020-10-10 11:21:40', '2020-10-10 17:01:10', 4, 1);
INSERT INTO `sys_role_function` VALUES (65, 0, '2020-10-10 11:21:40', '2020-10-10 17:01:10', 5, 1);
INSERT INTO `sys_role_function` VALUES (66, 0, '2020-10-10 11:21:40', '2020-10-10 17:01:10', 6, 1);
INSERT INTO `sys_role_function` VALUES (67, 0, '2020-10-10 11:21:40', '2020-10-10 17:01:10', 7, 1);
INSERT INTO `sys_role_function` VALUES (68, 0, '2020-10-10 11:21:40', '2020-10-10 17:01:10', 8, 1);
INSERT INTO `sys_role_function` VALUES (69, 0, '2020-10-10 11:21:40', '2020-10-10 17:01:10', 9, 1);
INSERT INTO `sys_role_function` VALUES (70, 0, '2020-10-10 11:21:40', '2020-10-10 17:01:10', 10, 1);
INSERT INTO `sys_role_function` VALUES (71, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 22, 1);
INSERT INTO `sys_role_function` VALUES (72, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 23, 1);
INSERT INTO `sys_role_function` VALUES (73, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 24, 1);
INSERT INTO `sys_role_function` VALUES (74, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 25, 1);
INSERT INTO `sys_role_function` VALUES (75, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 26, 1);
INSERT INTO `sys_role_function` VALUES (76, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 27, 1);
INSERT INTO `sys_role_function` VALUES (77, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 28, 1);
INSERT INTO `sys_role_function` VALUES (78, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 29, 1);
INSERT INTO `sys_role_function` VALUES (79, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 30, 1);
INSERT INTO `sys_role_function` VALUES (80, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 31, 1);
INSERT INTO `sys_role_function` VALUES (81, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 37, 1);
INSERT INTO `sys_role_function` VALUES (82, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 38, 1);
INSERT INTO `sys_role_function` VALUES (83, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 39, 1);
INSERT INTO `sys_role_function` VALUES (84, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 40, 1);
INSERT INTO `sys_role_function` VALUES (85, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 41, 1);
INSERT INTO `sys_role_function` VALUES (86, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 1, 1);
INSERT INTO `sys_role_function` VALUES (87, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 2, 1);
INSERT INTO `sys_role_function` VALUES (88, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 3, 1);
INSERT INTO `sys_role_function` VALUES (89, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 4, 1);
INSERT INTO `sys_role_function` VALUES (90, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 5, 1);
INSERT INTO `sys_role_function` VALUES (91, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 6, 1);
INSERT INTO `sys_role_function` VALUES (92, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 7, 1);
INSERT INTO `sys_role_function` VALUES (93, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 8, 1);
INSERT INTO `sys_role_function` VALUES (94, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 9, 1);
INSERT INTO `sys_role_function` VALUES (95, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 10, 1);
INSERT INTO `sys_role_function` VALUES (96, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 32, 1);
INSERT INTO `sys_role_function` VALUES (97, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 33, 1);
INSERT INTO `sys_role_function` VALUES (98, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 34, 1);
INSERT INTO `sys_role_function` VALUES (99, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 35, 1);
INSERT INTO `sys_role_function` VALUES (100, 0, '2020-10-10 17:01:10', '2020-10-10 17:12:32', 36, 1);
INSERT INTO `sys_role_function` VALUES (101, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 22, 1);
INSERT INTO `sys_role_function` VALUES (102, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 23, 1);
INSERT INTO `sys_role_function` VALUES (103, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 24, 1);
INSERT INTO `sys_role_function` VALUES (104, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 25, 1);
INSERT INTO `sys_role_function` VALUES (105, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 26, 1);
INSERT INTO `sys_role_function` VALUES (106, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 43, 1);
INSERT INTO `sys_role_function` VALUES (107, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 44, 1);
INSERT INTO `sys_role_function` VALUES (108, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 45, 1);
INSERT INTO `sys_role_function` VALUES (109, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 46, 1);
INSERT INTO `sys_role_function` VALUES (110, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 47, 1);
INSERT INTO `sys_role_function` VALUES (111, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 27, 1);
INSERT INTO `sys_role_function` VALUES (112, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 28, 1);
INSERT INTO `sys_role_function` VALUES (113, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 29, 1);
INSERT INTO `sys_role_function` VALUES (114, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 30, 1);
INSERT INTO `sys_role_function` VALUES (115, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 31, 1);
INSERT INTO `sys_role_function` VALUES (116, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 37, 1);
INSERT INTO `sys_role_function` VALUES (117, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 38, 1);
INSERT INTO `sys_role_function` VALUES (118, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 39, 1);
INSERT INTO `sys_role_function` VALUES (119, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 40, 1);
INSERT INTO `sys_role_function` VALUES (120, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 41, 1);
INSERT INTO `sys_role_function` VALUES (121, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 42, 1);
INSERT INTO `sys_role_function` VALUES (122, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 1, 1);
INSERT INTO `sys_role_function` VALUES (123, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 2, 1);
INSERT INTO `sys_role_function` VALUES (124, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 3, 1);
INSERT INTO `sys_role_function` VALUES (125, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 4, 1);
INSERT INTO `sys_role_function` VALUES (126, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 5, 1);
INSERT INTO `sys_role_function` VALUES (127, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 6, 1);
INSERT INTO `sys_role_function` VALUES (128, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 7, 1);
INSERT INTO `sys_role_function` VALUES (129, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 8, 1);
INSERT INTO `sys_role_function` VALUES (130, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 9, 1);
INSERT INTO `sys_role_function` VALUES (131, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 10, 1);
INSERT INTO `sys_role_function` VALUES (132, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 32, 1);
INSERT INTO `sys_role_function` VALUES (133, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 33, 1);
INSERT INTO `sys_role_function` VALUES (134, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 34, 1);
INSERT INTO `sys_role_function` VALUES (135, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 35, 1);
INSERT INTO `sys_role_function` VALUES (136, 0, '2020-10-10 17:12:32', '2020-10-10 17:41:15', 36, 1);
INSERT INTO `sys_role_function` VALUES (137, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 22, 1);
INSERT INTO `sys_role_function` VALUES (138, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 23, 1);
INSERT INTO `sys_role_function` VALUES (139, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 24, 1);
INSERT INTO `sys_role_function` VALUES (140, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 25, 1);
INSERT INTO `sys_role_function` VALUES (141, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 26, 1);
INSERT INTO `sys_role_function` VALUES (142, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 43, 1);
INSERT INTO `sys_role_function` VALUES (143, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 44, 1);
INSERT INTO `sys_role_function` VALUES (144, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 45, 1);
INSERT INTO `sys_role_function` VALUES (145, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 46, 1);
INSERT INTO `sys_role_function` VALUES (146, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 47, 1);
INSERT INTO `sys_role_function` VALUES (147, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 27, 1);
INSERT INTO `sys_role_function` VALUES (148, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 28, 1);
INSERT INTO `sys_role_function` VALUES (149, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 29, 1);
INSERT INTO `sys_role_function` VALUES (150, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 30, 1);
INSERT INTO `sys_role_function` VALUES (151, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 31, 1);
INSERT INTO `sys_role_function` VALUES (152, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 37, 1);
INSERT INTO `sys_role_function` VALUES (153, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 38, 1);
INSERT INTO `sys_role_function` VALUES (154, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 39, 1);
INSERT INTO `sys_role_function` VALUES (155, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 40, 1);
INSERT INTO `sys_role_function` VALUES (156, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 41, 1);
INSERT INTO `sys_role_function` VALUES (157, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 42, 1);
INSERT INTO `sys_role_function` VALUES (158, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 1, 1);
INSERT INTO `sys_role_function` VALUES (159, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 2, 1);
INSERT INTO `sys_role_function` VALUES (160, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 3, 1);
INSERT INTO `sys_role_function` VALUES (161, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 4, 1);
INSERT INTO `sys_role_function` VALUES (162, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 5, 1);
INSERT INTO `sys_role_function` VALUES (163, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 6, 1);
INSERT INTO `sys_role_function` VALUES (164, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 7, 1);
INSERT INTO `sys_role_function` VALUES (165, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 8, 1);
INSERT INTO `sys_role_function` VALUES (166, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 9, 1);
INSERT INTO `sys_role_function` VALUES (167, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 10, 1);
INSERT INTO `sys_role_function` VALUES (168, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 32, 1);
INSERT INTO `sys_role_function` VALUES (169, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 33, 1);
INSERT INTO `sys_role_function` VALUES (170, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 34, 1);
INSERT INTO `sys_role_function` VALUES (171, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 35, 1);
INSERT INTO `sys_role_function` VALUES (172, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 36, 1);
INSERT INTO `sys_role_function` VALUES (173, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 48, 1);
INSERT INTO `sys_role_function` VALUES (174, 1, '2020-10-10 17:41:15', '2020-10-10 17:41:15', 49, 1);

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT 1 COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `menu_id` bigint(20) NULL DEFAULT NULL COMMENT '菜单id',
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 188 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统角色与菜单对应表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
INSERT INTO `sys_role_menu` VALUES (76, 0, '2020-10-09 18:13:42', '2020-10-10 09:41:50', 4, 1);
INSERT INTO `sys_role_menu` VALUES (77, 0, '2020-10-09 18:13:42', '2020-10-10 09:41:50', 1, 1);
INSERT INTO `sys_role_menu` VALUES (78, 0, '2020-10-09 18:13:42', '2020-10-10 09:41:50', 6, 1);
INSERT INTO `sys_role_menu` VALUES (79, 0, '2020-10-09 18:13:42', '2020-10-10 09:41:50', 2, 1);
INSERT INTO `sys_role_menu` VALUES (99, 0, '2020-10-09 18:26:04', '2020-10-09 18:26:06', 4, 1);
INSERT INTO `sys_role_menu` VALUES (100, 0, '2020-10-09 18:26:04', '2020-10-09 18:26:06', 2, 1);
INSERT INTO `sys_role_menu` VALUES (101, 0, '2020-10-09 18:26:04', '2020-10-09 18:26:06', 1, 1);
INSERT INTO `sys_role_menu` VALUES (102, 0, '2020-10-09 18:26:04', '2020-10-09 18:26:06', 6, 1);
INSERT INTO `sys_role_menu` VALUES (103, 0, '2020-10-09 18:26:04', '2020-10-09 18:26:06', 3, 1);
INSERT INTO `sys_role_menu` VALUES (104, 0, '2020-10-09 18:26:04', '2020-10-09 18:26:06', 7, 1);
INSERT INTO `sys_role_menu` VALUES (105, 0, '2020-10-09 18:26:04', '2020-10-09 18:26:06', 8, 1);
INSERT INTO `sys_role_menu` VALUES (106, 0, '2020-10-09 18:26:04', '2020-10-09 18:26:06', 9, 1);
INSERT INTO `sys_role_menu` VALUES (107, 0, '2020-10-09 18:26:04', '2020-10-09 18:26:06', 5, 1);
INSERT INTO `sys_role_menu` VALUES (108, 0, '2020-10-09 18:26:06', '2020-10-09 18:26:10', 4, 1);
INSERT INTO `sys_role_menu` VALUES (109, 0, '2020-10-09 18:26:06', '2020-10-09 18:26:10', 6, 1);
INSERT INTO `sys_role_menu` VALUES (110, 0, '2020-10-09 18:26:06', '2020-10-09 18:26:10', 3, 1);
INSERT INTO `sys_role_menu` VALUES (111, 0, '2020-10-09 18:26:06', '2020-10-09 18:26:10', 7, 1);
INSERT INTO `sys_role_menu` VALUES (112, 0, '2020-10-09 18:26:06', '2020-10-09 18:26:10', 8, 1);
INSERT INTO `sys_role_menu` VALUES (113, 0, '2020-10-09 18:26:06', '2020-10-09 18:26:10', 9, 1);
INSERT INTO `sys_role_menu` VALUES (114, 0, '2020-10-09 18:26:06', '2020-10-09 18:26:10', 5, 1);
INSERT INTO `sys_role_menu` VALUES (115, 0, '2020-10-09 18:26:10', '2020-10-09 18:26:14', 6, 1);
INSERT INTO `sys_role_menu` VALUES (116, 0, '2020-10-09 18:26:10', '2020-10-09 18:26:14', 3, 1);
INSERT INTO `sys_role_menu` VALUES (117, 0, '2020-10-09 18:26:10', '2020-10-09 18:26:14', 7, 1);
INSERT INTO `sys_role_menu` VALUES (118, 0, '2020-10-09 18:26:10', '2020-10-09 18:26:14', 8, 1);
INSERT INTO `sys_role_menu` VALUES (119, 0, '2020-10-09 18:26:10', '2020-10-09 18:26:14', 9, 1);
INSERT INTO `sys_role_menu` VALUES (120, 0, '2020-10-09 18:26:14', '2020-10-09 18:26:25', 4, 1);
INSERT INTO `sys_role_menu` VALUES (121, 0, '2020-10-09 18:26:14', '2020-10-09 18:26:25', 6, 1);
INSERT INTO `sys_role_menu` VALUES (122, 0, '2020-10-09 18:26:14', '2020-10-09 18:26:25', 3, 1);
INSERT INTO `sys_role_menu` VALUES (123, 0, '2020-10-09 18:26:14', '2020-10-09 18:26:25', 7, 1);
INSERT INTO `sys_role_menu` VALUES (124, 0, '2020-10-09 18:26:14', '2020-10-09 18:26:25', 8, 1);
INSERT INTO `sys_role_menu` VALUES (125, 0, '2020-10-09 18:26:14', '2020-10-09 18:26:25', 9, 1);
INSERT INTO `sys_role_menu` VALUES (126, 0, '2020-10-09 18:26:14', '2020-10-09 18:26:25', 5, 1);
INSERT INTO `sys_role_menu` VALUES (127, 0, '2020-10-09 18:26:25', '2020-10-10 09:40:25', 6, 1);
INSERT INTO `sys_role_menu` VALUES (128, 0, '2020-10-09 18:26:25', '2020-10-10 09:40:25', 5, 1);
INSERT INTO `sys_role_menu` VALUES (129, 0, '2020-10-10 09:40:25', '2020-10-10 09:40:31', 4, 1);
INSERT INTO `sys_role_menu` VALUES (130, 0, '2020-10-10 09:40:25', '2020-10-10 09:40:31', 6, 1);
INSERT INTO `sys_role_menu` VALUES (131, 0, '2020-10-10 09:40:31', '2020-10-10 09:40:34', 4, 1);
INSERT INTO `sys_role_menu` VALUES (132, 0, '2020-10-10 09:40:34', '2020-10-10 09:40:42', 4, 1);
INSERT INTO `sys_role_menu` VALUES (133, 0, '2020-10-10 09:40:34', '2020-10-10 09:40:42', 6, 1);
INSERT INTO `sys_role_menu` VALUES (134, 0, '2020-10-10 09:40:42', '2020-10-10 09:40:47', 4, 1);
INSERT INTO `sys_role_menu` VALUES (135, 0, '2020-10-10 09:40:47', '2020-10-10 09:41:34', 4, 1);
INSERT INTO `sys_role_menu` VALUES (136, 0, '2020-10-10 09:41:50', '2020-10-10 09:41:58', 4, 1);
INSERT INTO `sys_role_menu` VALUES (137, 0, '2020-10-10 09:41:50', '2020-10-10 09:41:58', 1, 1);
INSERT INTO `sys_role_menu` VALUES (138, 0, '2020-10-10 09:41:50', '2020-10-10 09:41:58', 3, 1);
INSERT INTO `sys_role_menu` VALUES (139, 0, '2020-10-10 09:41:50', '2020-10-10 09:41:58', 8, 1);
INSERT INTO `sys_role_menu` VALUES (140, 0, '2020-10-10 09:41:50', '2020-10-10 09:41:58', 9, 1);
INSERT INTO `sys_role_menu` VALUES (141, 0, '2020-10-10 09:41:58', '2020-10-10 09:45:00', 6, 1);
INSERT INTO `sys_role_menu` VALUES (142, 0, '2020-10-10 09:41:58', '2020-10-10 09:45:00', 3, 1);
INSERT INTO `sys_role_menu` VALUES (143, 0, '2020-10-10 09:41:58', '2020-10-10 09:45:00', 8, 1);
INSERT INTO `sys_role_menu` VALUES (144, 0, '2020-10-10 09:41:58', '2020-10-10 09:45:00', 9, 1);
INSERT INTO `sys_role_menu` VALUES (145, 0, '2020-10-10 09:45:00', '2020-10-10 18:07:53', 4, 1);
INSERT INTO `sys_role_menu` VALUES (146, 0, '2020-10-10 09:45:00', '2020-10-10 18:07:53', 2, 1);
INSERT INTO `sys_role_menu` VALUES (147, 0, '2020-10-10 09:45:00', '2020-10-10 18:07:53', 1, 1);
INSERT INTO `sys_role_menu` VALUES (148, 0, '2020-10-10 09:45:00', '2020-10-10 18:07:53', 6, 1);
INSERT INTO `sys_role_menu` VALUES (149, 0, '2020-10-10 09:45:00', '2020-10-10 18:07:53', 3, 1);
INSERT INTO `sys_role_menu` VALUES (150, 0, '2020-10-10 09:45:00', '2020-10-10 18:07:53', 7, 1);
INSERT INTO `sys_role_menu` VALUES (151, 0, '2020-10-10 09:45:00', '2020-10-10 18:07:53', 8, 1);
INSERT INTO `sys_role_menu` VALUES (152, 0, '2020-10-10 09:45:00', '2020-10-10 18:07:53', 9, 1);
INSERT INTO `sys_role_menu` VALUES (153, 0, '2020-10-10 09:45:00', '2020-10-10 18:07:53', 5, 1);
INSERT INTO `sys_role_menu` VALUES (154, 0, '2020-10-10 18:07:53', '2020-10-10 18:07:55', 4, 1);
INSERT INTO `sys_role_menu` VALUES (155, 0, '2020-10-10 18:07:53', '2020-10-10 18:07:55', 2, 1);
INSERT INTO `sys_role_menu` VALUES (156, 0, '2020-10-10 18:07:53', '2020-10-10 18:07:55', 1, 1);
INSERT INTO `sys_role_menu` VALUES (157, 0, '2020-10-10 18:07:53', '2020-10-10 18:07:55', 6, 1);
INSERT INTO `sys_role_menu` VALUES (158, 0, '2020-10-10 18:07:53', '2020-10-10 18:07:55', 3, 1);
INSERT INTO `sys_role_menu` VALUES (159, 0, '2020-10-10 18:07:53', '2020-10-10 18:07:55', 7, 1);
INSERT INTO `sys_role_menu` VALUES (160, 0, '2020-10-10 18:07:53', '2020-10-10 18:07:55', 8, 1);
INSERT INTO `sys_role_menu` VALUES (161, 0, '2020-10-10 18:07:53', '2020-10-10 18:07:55', 9, 1);
INSERT INTO `sys_role_menu` VALUES (162, 0, '2020-10-10 18:07:55', '2020-10-10 18:07:59', 4, 1);
INSERT INTO `sys_role_menu` VALUES (163, 0, '2020-10-10 18:07:55', '2020-10-10 18:07:59', 2, 1);
INSERT INTO `sys_role_menu` VALUES (164, 0, '2020-10-10 18:07:55', '2020-10-10 18:07:59', 1, 1);
INSERT INTO `sys_role_menu` VALUES (165, 0, '2020-10-10 18:07:55', '2020-10-10 18:07:59', 6, 1);
INSERT INTO `sys_role_menu` VALUES (166, 0, '2020-10-10 18:07:55', '2020-10-10 18:07:59', 3, 1);
INSERT INTO `sys_role_menu` VALUES (167, 0, '2020-10-10 18:07:55', '2020-10-10 18:07:59', 7, 1);
INSERT INTO `sys_role_menu` VALUES (168, 0, '2020-10-10 18:07:55', '2020-10-10 18:07:59', 8, 1);
INSERT INTO `sys_role_menu` VALUES (169, 0, '2020-10-10 18:07:55', '2020-10-10 18:07:59', 9, 1);
INSERT INTO `sys_role_menu` VALUES (170, 0, '2020-10-10 18:07:55', '2020-10-10 18:07:59', 5, 1);
INSERT INTO `sys_role_menu` VALUES (171, 0, '2020-10-10 18:07:59', '2020-10-10 18:08:11', 4, 1);
INSERT INTO `sys_role_menu` VALUES (172, 0, '2020-10-10 18:07:59', '2020-10-10 18:08:11', 2, 1);
INSERT INTO `sys_role_menu` VALUES (173, 0, '2020-10-10 18:07:59', '2020-10-10 18:08:11', 1, 1);
INSERT INTO `sys_role_menu` VALUES (174, 0, '2020-10-10 18:07:59', '2020-10-10 18:08:11', 6, 1);
INSERT INTO `sys_role_menu` VALUES (175, 0, '2020-10-10 18:07:59', '2020-10-10 18:08:11', 3, 1);
INSERT INTO `sys_role_menu` VALUES (176, 0, '2020-10-10 18:07:59', '2020-10-10 18:08:11', 7, 1);
INSERT INTO `sys_role_menu` VALUES (177, 0, '2020-10-10 18:07:59', '2020-10-10 18:08:11', 8, 1);
INSERT INTO `sys_role_menu` VALUES (178, 0, '2020-10-10 18:07:59', '2020-10-10 18:08:11', 9, 1);
INSERT INTO `sys_role_menu` VALUES (179, 1, '2020-10-10 18:08:11', '2020-10-10 18:08:11', 4, 1);
INSERT INTO `sys_role_menu` VALUES (180, 1, '2020-10-10 18:08:11', '2020-10-10 18:08:11', 2, 1);
INSERT INTO `sys_role_menu` VALUES (181, 1, '2020-10-10 18:08:11', '2020-10-10 18:08:11', 1, 1);
INSERT INTO `sys_role_menu` VALUES (182, 1, '2020-10-10 18:08:11', '2020-10-10 18:08:11', 6, 1);
INSERT INTO `sys_role_menu` VALUES (183, 1, '2020-10-10 18:08:11', '2020-10-10 18:08:11', 3, 1);
INSERT INTO `sys_role_menu` VALUES (184, 1, '2020-10-10 18:08:11', '2020-10-10 18:08:11', 7, 1);
INSERT INTO `sys_role_menu` VALUES (185, 1, '2020-10-10 18:08:11', '2020-10-10 18:08:11', 8, 1);
INSERT INTO `sys_role_menu` VALUES (186, 1, '2020-10-10 18:08:11', '2020-10-10 18:08:11', 9, 1);
INSERT INTO `sys_role_menu` VALUES (187, 1, '2020-10-10 18:08:11', '2020-10-10 18:08:11', 5, 1);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `id` bigint(20) NOT NULL,
  `valid` tinyint(1) NOT NULL COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) COMMENT '记录创建时间',
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0) COMMENT '记录更新时间',
  `account` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '账号',
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '密码',
  `salt` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '用于加密密码的盐',
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '手机号',
  `status` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '状态',
  `approve_status` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '审核状态',
  `approve_result` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL COMMENT '审核结果',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT '' COMMENT '用户名',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 1, '2020-07-24 09:11:06', '2020-08-03 16:27:35', 'zhangsan', 'E10ADC3949BA59ABBE56E057F20F883E', 'zcuwe', '13000989890', '1', '2', '2', '张三');

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role`  (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `valid` tinyint(1) NULL DEFAULT NULL COMMENT '数据是否删除',
  `create_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0),
  `update_time` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `user_id` bigint(20) NOT NULL COMMENT '用户id',
  `role_id` bigint(20) NULL DEFAULT NULL COMMENT '角色id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci COMMENT = '系统用户与角色对应表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
INSERT INTO `sys_user_role` VALUES (1, 1, '2020-07-24 16:28:56', '2020-07-24 16:28:56', 1, 1);

SET FOREIGN_KEY_CHECKS = 1;
