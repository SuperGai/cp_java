package com.spz.demo.singleboot.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.spz.demo.singleboot.entity.Permission;
import com.spz.demo.singleboot.mapper.PermissionMapper;
import com.spz.demo.singleboot.service.PermissionService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 权限表 服务实现类
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
@Service
public class PermissionServiceImpl extends ServiceImpl<PermissionMapper, Permission> implements PermissionService {

    @Autowired
    private PermissionMapper permissionMapper;

    @Override
    public List<String> getPermissionsByRoleId(long roleId) {
        // 查询角色所拥有权限
        List<Permission> permissions = permissionMapper.selectList(
                new EntityWrapper<Permission>().eq("role_id",roleId)
        );
        if(permissions == null || permissions.size() == 0){
            return new ArrayList<>();
        }

        //返回
        List<String> rest = new ArrayList<>();
        for(Permission permission : permissions){
            rest.add(permission.getName());
        }

        return rest;
    }
}
