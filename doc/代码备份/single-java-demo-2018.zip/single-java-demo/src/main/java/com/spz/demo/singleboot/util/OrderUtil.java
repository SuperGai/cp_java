package com.spz.demo.singleboot.util;

import org.apache.commons.lang.RandomStringUtils;

import java.util.Date;

/**
 * 订单相关工具
 */
public class OrderUtil {
    /**
     * 生成订票的订单号
     * 日均千万级别不重复
     * @return
     */
    public static String getOrderId(){
        String time = TimeUtils.DATE_FORMAT_DATE_SS.format(new Date());
        return time + RandomStringUtils.randomNumeric(8);
    }
}
