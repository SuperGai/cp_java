package com.spz.demo.singleboot.common;

/**
 * 部分请求mapping的url
 * 用于controller层方法的RequestMapping注解
 */
public interface RequestMappingConst {

    static final String BASIC_URL_PUBLIC = "/pub/";//公用接口的url
    static final String BASIC_URL_USER = "/user/";//用户接口的url
}
