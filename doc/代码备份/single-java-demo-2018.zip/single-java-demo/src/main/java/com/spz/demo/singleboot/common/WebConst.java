package com.spz.demo.singleboot.common;

/**
 * 请求或响应参数名称常量
 */
public interface WebConst {
    // 用于token，存储在header
    static final String TOKEN = "token";

    // 用于刷新token，存储在header
    static final String REFLUSH_TOKEN = "reflushToken";
}
