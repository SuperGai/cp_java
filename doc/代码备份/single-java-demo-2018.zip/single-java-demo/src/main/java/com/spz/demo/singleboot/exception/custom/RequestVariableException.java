package com.spz.demo.singleboot.exception.custom;

import com.spz.demo.singleboot.exception.BasicException;

/**
 * 自定义异常类
 * 请求参数异常
 * 在请求时缺少某些请求参数
 */
public class RequestVariableException extends BasicException {
    /**
     *
     * @param errorVal 出错的参数名称
     * @param detail 详情，可不传
     */
    public RequestVariableException(String errorVal,String detail){
        super("[" + errorVal + "]参数异常 " + detail);
    }
}
