package com.spz.demo.singleboot.shiro.token;


import lombok.Data;
import org.apache.shiro.authc.AuthenticationToken;

/**
 * 用于登录
 * 登录时给此类的account和password(明文)赋值
 * 然后在UserRealm里将查询到的userId赋值给此类里的userId。controller层需要id
 */
@Data
public class UserAuthenticationToken implements AuthenticationToken {

    private Long userId;//用户在数据库中的id
    private String account;
    private String password;

    public UserAuthenticationToken(String account, String password){
        this.account = account;
        this.password = password;
    }

    /**
     * 返回 account
     * @return
     */
    @Override
    public Object getPrincipal() {
        return this.account;
    }

    /**
     * 返回 password
     * @return
     */
    @Override
    public Object getCredentials() {
        return this.password;
    }
}
