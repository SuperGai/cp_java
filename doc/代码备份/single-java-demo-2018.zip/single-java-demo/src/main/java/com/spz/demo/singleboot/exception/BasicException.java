package com.spz.demo.singleboot.exception;

/**
 * 自定义异常基类
 */
public class BasicException extends Exception {
    public BasicException(String message){
        super(message);
    }
}
