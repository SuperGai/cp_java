package com.spz.demo.singleboot.entity;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.spz.demo.singleboot.common.verify.PoAddVerifyGroup;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * <p>
 * 用户表
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
public class User extends Model<User>{

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    /**
     * 账号，唯一
     */
    @NotEmpty(message = "账号不能为空",groups = {PoAddVerifyGroup.class})
    private String account;
    /**
     * 密码
     */
    @NotEmpty(message = "密码不能为空",groups = {PoAddVerifyGroup.class})
    private String password;
    /**
     * 昵称
     */
    @NotEmpty(message = "昵称不能为空",groups = {PoAddVerifyGroup.class})
    private String name;
    /**
     * 所属角色id
     */
    @NotNull(message = "所属角色id不能为空",groups = {PoAddVerifyGroup.class})
    private Long roleId;
    /**
     * 是否启用
     */
    private Integer status;
    /**
     * 是否删除
     */
    @TableField("is_deleted")
    private Integer isDeleted;
    /**
     * 版本
     */
    private Long version;
    /**
     * 创建时间
     */
    @TableField("gmt_create")
    private Date gmtCreate;
    /**
     * 更新时间
     */
    @TableField("gmt_modified")
    private Date gmtModified;


    public Long getId() {
        return id;
    }

    public User setId(Long id) {
        this.id = id;
        return this;
    }

    public String getAccount() {
        return account;
    }

    public User setAccount(String account) {
        this.account = account;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public User setPassword(String password) {
        this.password = password;
        return this;
    }

    public String getName() {
        return name;
    }

    public User setName(String name) {
        this.name = name;
        return this;
    }

    public Integer getStatus() {
        return status;
    }

    public User setStatus(Integer status) {
        this.status = status;
        return this;
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public User setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
        return this;
    }

    public Long getVersion() {
        return version;
    }

    public User setVersion(Long version) {
        this.version = version;
        return this;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public User setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
        return this;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public User setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
        return this;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    @Override
    protected Serializable pkVal() {
        return this.id;
    }

    @Override
    public String toString() {
        return "User{" +
        "id=" + id +
        ", account=" + account +
        ", password=" + password +
        ", name=" + name +
        ", status=" + status +
        ", isDeleted=" + isDeleted +
        ", version=" + version +
        ", gmtCreate=" + gmtCreate +
        ", gmtModified=" + gmtModified +
        "}";
    }
}
