package com.spz.demo.singleboot.util;

import com.spz.demo.singleboot.common.RequestMappingConst;

import javax.servlet.http.HttpServletRequest;

/**
 * 业务使用工具类
 */
public class BusinessUtil {
    /**
     * 检查请求是否为公共请求
     * @param request
     * @return
     */
    public static boolean isPublicRequest(HttpServletRequest request) {
        if(request.getRequestURI().indexOf(RequestMappingConst.BASIC_URL_PUBLIC) >= 0){
            return true;
        }
        return false;
    }
}
