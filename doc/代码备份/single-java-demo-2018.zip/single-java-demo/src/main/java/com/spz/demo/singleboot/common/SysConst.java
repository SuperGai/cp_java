package com.spz.demo.singleboot.common;

/**
 * 系统常量
 */
public interface SysConst {

    // 是否删除
    static final int DEL_YES = 1;
    static final int DEL_NO = 0;

    // 是否启用
    static final int ENABLE_YES = 1;
    static final int ENABLE_NO = 0;
}
