package com.spz.demo.singleboot.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * 配置文件工具
 */
public class PropertiesUtil {

    /**
     * 获取配置文件
     * @param fileNamePath
     * @param key
     * @return
     * @throws IOException
     */
    public static String getValue(String fileNamePath, String key)throws IOException {
        Properties props = new Properties();
        InputStream in = null;
        try {
            in = new FileInputStream(fileNamePath);
            // 如果将in改为下面的方法，必须要将.Properties文件和此class类文件放在同一个包中
            //in = propertiesTools.class.getResourceAsStream(fileNamePath);
            props.load(in);
            //String value = props.getProperty(key);
            // 有乱码时要进行重新编码
            String value = new String(props.getProperty(key).getBytes("ISO-8859-1"), "GBK");
            return value;

        } catch (IOException e) {
            e.printStackTrace();
            return null;

        } finally {
            if (null != in)
                in.close();
        }
    }

}
