package com.spz.demo.singleboot.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 接口返回值格式定义.
 * <p>
 * 接口返回均为JSON格式, 形式为: {code: XXX, Message:, YYY, data: ZZZ}
 * 其中code为错误码, message为简单的错误描述, data为请求成功时返回的所需数据.
 * 注意: message不能作为前端显示错误的凭据, 该值仅为开发调试使用.
 * <p>
 * Created by xingfinal on 15/11/27.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Response<T> {
    // 错误码
    private long code;
    // 错误信息
    private String message;
    // 数据
    private T data;

    // 再次封装的函数 - start

    public static <T> Response<T> paramError(String message) {
        return error(Code.DEFAULT_PARAMS_ERROR,message);
    }

    public static <T> Response<T> error(String msg) {
        return error(Code.DEFAULT_ERROR,msg);
    }

    public static <T> Response<T> error(String msg,T data) {
        return new Response<T>(Code.DEFAULT_ERROR.getCode(),msg,data);
    }

    public static <T> Response<T> error(Code code,T data) {
        return new Response<T>(code.getCode(),code.getMessage(),data);
    }

    // 再次封装的函数 - end

    public static <T> Response<T> ok() {
        return ok(Code.DEFAULT_SUCCESS);
    }

    public static <T> Response<T> ok(Code code) {
        return ok(code, null);
    }

    public static <T> Response<T> ok(T data) {
        return ok(Code.DEFAULT_SUCCESS, data);
    }

    public static <T> Response<T> ok(Code code, T data) {
        return new Response<>(code, data);
    }

    public static <T> Response<T> error(Code code) {
        return ok(code);
    }

    public static <T> Response<T> error(Code code, String message) {
        code.setMessage(message);
        return ok(code);
    }

    public static <T> Response<T> error(Long code, String message) {
        return new Response<>(code,message,null);
    }

    public Response() {
    }

    public Response(Long code,String message,T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public Response(T data) {
        this(Code.DEFAULT_SUCCESS, data);
    }

    public Response(Code code) {
        this(code.getCode(), code.getMessage(), null);
    }

    public Response(Code code, T data) {
        this(code.getCode(), code.getMessage(), data);
    }

    public Response(long code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public long getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public T getData() {
        return data;
    }
}
