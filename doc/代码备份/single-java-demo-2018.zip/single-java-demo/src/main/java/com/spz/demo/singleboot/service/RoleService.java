package com.spz.demo.singleboot.service;

import com.spz.demo.singleboot.entity.Role;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 角色表 服务类
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
public interface RoleService extends IService<Role> {

}
