package com.spz.demo.singleboot.task;

import com.spz.demo.singleboot.util.EhcacheUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 项目启动时执行的方法
 */
@Slf4j
@Component
@Order(1)
public class StartupRunner implements CommandLineRunner {

    @Autowired
    @Lazy
    private EhcacheUtil ehcacheUtil;

    @Override
    public void run(String... args) throws Exception {
        ehcacheUtil.deleteAll();
        log.info("清空项目缓存.....");
        log.info("项目开始运行.....");
    }
}

