package com.spz.demo.singleboot.mapper;

import com.spz.demo.singleboot.entity.Permission;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 * 权限表 Mapper 接口
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
public interface PermissionMapper extends BaseMapper<Permission> {

}
