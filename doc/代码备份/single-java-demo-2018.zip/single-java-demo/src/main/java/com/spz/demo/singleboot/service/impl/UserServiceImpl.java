package com.spz.demo.singleboot.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.spz.demo.singleboot.entity.Permission;
import com.spz.demo.singleboot.entity.User;
import com.spz.demo.singleboot.mapper.PermissionMapper;
import com.spz.demo.singleboot.mapper.UserMapper;
import com.spz.demo.singleboot.service.UserService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.spz.demo.singleboot.vo.Response;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
@Slf4j//(topic = "SYS_LOG")
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>  implements UserService{//

    @Autowired
    private PermissionMapper permissionMapper;
    @Autowired
    private UserMapper userMapper;

    public User getUserByAccount(String account, int status, int isDeleted) {

        // 从数据库中查询数据
        User param = new User();
        param.setAccount(account);
        param.setStatus(status);
        param.setIsDeleted(isDeleted);
        User user = userMapper.selectOne(param);
        if(user == null){
            return null;
        }
        log.info("从数据库中查询用户数据");

        return user;
    }

    public List<String> getUserPermissions(long userId) {
        //获取用户所属角色
        User user = userMapper.selectById(userId);
        if(user == null){
            return new ArrayList<>();
        }

        // 查询角色所拥有权限
        List<Permission> permissions = permissionMapper.selectList(
                new EntityWrapper<Permission>().eq("role_id",user.getRoleId())
        );
        if(permissions == null || permissions.size() == 0){
            return new ArrayList<>();
        }

        //返回
        List<String> rest = new ArrayList<>();
        for(Permission permission : permissions){
            rest.add(permission.getUrl());
        }

        return rest;
    }

    @Override
    public Response addUser(User user) {
        return null;
    }

}
