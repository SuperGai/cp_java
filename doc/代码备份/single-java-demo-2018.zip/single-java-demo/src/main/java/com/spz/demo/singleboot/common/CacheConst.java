package com.spz.demo.singleboot.common;

/**
 * 缓存 key 常量
 */
public interface CacheConst {

    // ---- 全局 ----
    static final String SPILT = "="; //分隔符
    static final String PROJECT = "singleDemo" + SPILT; // 本项目名称

    // 系统相关
    static final String IMAGE_CODE = PROJECT + "imageCode" + SPILT;// 验证码

}
