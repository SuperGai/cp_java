package com.spz.demo.singleboot.service.impl;

import com.spz.demo.singleboot.entity.Role;
import com.spz.demo.singleboot.mapper.RoleMapper;
import com.spz.demo.singleboot.service.RoleService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 角色表 服务实现类
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements RoleService {

}
