package com.spz.demo.singleboot.service;

import com.spz.demo.singleboot.entity.User;
import com.baomidou.mybatisplus.service.IService;
import com.spz.demo.singleboot.vo.Response;

import java.util.List;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author zp
 * @since 2018-08-29
 */
public interface UserService extends IService<User> {//
    /**
     * 根据account获取用户信息
     * @param account
     * @return
     */
    User getUserByAccount(String account,int status,int isDeleted);


    /**
     * 获取用户所拥有的权限
     * @param userId
     * @return
     */
    List<String> getUserPermissions(long userId);

    /**
     * 添加用户
     * @param user
     * @return
     */
    Response addUser(User user);
}
