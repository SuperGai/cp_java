package com.spz.demo.singleboot.common.verify;

/**
 * 校验分组
 *
 * 实体类添加时的校验
 */
public interface PoAddVerifyGroup {
}
