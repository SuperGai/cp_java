### SpringBoot 单应用快速开发框架

#### 特点
* 适用于前后端分离的 Spring Boot 单应用的快速搭建与开发
* 不适用于大型项目或分布式项目
* 包含了用户登录模块及权限模块（shiro）、Controller层参数校验、异常处理、ehcache缓存和其他一些小工具
* 控制层请求交互全部使用JSON方式

#### 环境
* IntelliJ IDEA 2018.3（需要安装 lombok 插件）  
* MySQL 5.7

#### 相关配置参考

* 使用 Mybatis-plus 代码生成器 

代码生成器类在 util 包里的 MpGenerator.java ，可根据数据库的表结构生成entity、Service、ServiceImpl、mapper、mapper-xml和controller类。
生成的文件存放在项目目录的temp文件夹下。

* web层拦截器 

由ShiroLoginFilter.java拦截所有请求。 

不需要拦截的请求url，请使用 RequestMappingConst.BASIC_URL_PUBLIC 前缀 

建议：特殊的请求url配置在 RequestMappingConst 中 

* 项目部署到外部Tomcat

[spring-boot项目在外部tomcat环境下部署](https://blog.csdn.net/james_wade63/article/details/51009423) 

推荐使用maven的package命令打包war 

* 项目打包jar 

在idea控制台进入项目根目录，使用*mvn clean package*指令打包

#### 登录流程
1. 用户登录，系统验证用户成功后，签发JWT token，存入response里的Header 
2. 前端从response里取出 Header 里的token 
3. 在下一次请求中，前端将token存入request里的header。服务器接收到请求，在拦截器(ShiroLoginFilter.java)里检查token是否合法，并检查是否过期 
    
    注意：
    如果token超过有效期，服务器会负责刷新token，并设置到response的Header里
    如果token超过两倍有效期，则需要重新登录 
    
4. 前端接收到服务器请求返回后，检查header里有没有token，有则说明服务器刷新了token，前端需要将新token放在request的header里进行下一次请求
5. 用户点击注销后，前端删除token即可

#### 数据库
用户登录和权限需要3个数据表： *user* 、 *permission* 和 *role* 。 
_user表存储用户基本信息，permission 表存储权限信息(即请求url)，role存储角色信息，校验权限时，是通过请求url来校验的。
比如用户尝试请求携带/index的url接口，后台拿到用户id后，找到user表里的用户信息，得到用户角色，再去permission表里获取该角色拥有的url列表，检查里面是否有/index，有则说明该用户有访问权限  

#### 关于此Demo的解析
* [Shiro和SpringBoot简单集成](https://www.jianshu.com/p/96a7b509706f)
* [Spring boot 和 mybatis-plus基础整合](https://www.jianshu.com/p/9d5e035054e6)
* [EhCache集成Springboot](https://www.jianshu.com/p/c5bfc1b2cd27)
* [Controller 层参数校验方案](https://www.jianshu.com/p/aa8b3163b30a)

#### 完成此Demo参考了以下文章
* [签发的用户认证token超时刷新策略](https://segmentfault.com/a/1190000014545422)
* [Mybatis-Plus](http://mp.baomidou.com/#/quick-start)
* [Mybatis-Plus代码生成器](https://blog.csdn.net/qq_26641781/article/details/80352150)
* [shiro实现手机验证码登录](https://blog.csdn.net/modjie/article/details/79221774)
* [SpringBoot 集成无状态的 Shiro](http://412887952-qq-com.iteye.com/blog/2359097)

#### 有问题请联系我
* 邮箱：1802226517@qq.com
* [简书博客](https://www.jianshu.com/u/efb71669e3f4)